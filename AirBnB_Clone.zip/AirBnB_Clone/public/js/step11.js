function click1(){
    const first=document.getElementById("first");
    const second=document.getElementById("second");
    first.style.border="4px solid black";
    first.style.backgroundColor="rgb(247, 247, 247)";
    second.style.border="";
    second.style.backgroundColor="";
}
function click2(){
    const first=document.getElementById("first");
    const second=document.getElementById("second");
    first.style.border="";
    first.style.backgroundColor="";
    second.style.border="4px solid black";
    second.style.backgroundColor="rgb(247, 247, 247)";
}
function backbutton(event){
    event.preventDefault();
    fetch('/back11',{
        method:"get",
        headers:{
            "Content-Type":"application/json"
        }
    })
    .then(response=>{
        if(response.redirected){
            window.location.href=response.url;
        }
        else{
            throw new Error
        }
    })
    .then(data=>console.log(data))
    .catch(error=>console.log(error))
}
function nextbutton(event){
    event.preventDefault();
    fetch('/next8',{
        method:"get",
        headers:{
            "Content-Type":"application/json"
        }
    })
    .then(response=>{
        if(response.redirected){
            window.location.href=response.url;
        }
        else{
            throw new Error
        }
    })
    .then(data=>console.log(data))
    .catch(error=>console.log(error))
}