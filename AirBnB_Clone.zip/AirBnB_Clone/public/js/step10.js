function backbutton(event){
    event.preventDefault();
    fetch('/back10',{
        method:"get",
        headers:{
            "Content-Type":"application/json"
        }
    })
    .then(response=>{
        if(response.redirected){
            window.location.href=response.url;
        }
        else{
            throw new Error;
         }
    })
    .then(data=>console.log(data))
    .catch(error=>console.error(error))
}
function nextbutton(event){
    event.preventDefault();
    fetch('/next7',{
        method:"get",
        headers:{
            "Content-Type":"application/json"
        }
    })
    .then(response=>{
        if(response.redirected){
            window.location.href=response.url;
        }
        else{
            throw new Error;
         }
    })
    .then(data=>console.log(data))
    .catch(error=>console.error(error))
}