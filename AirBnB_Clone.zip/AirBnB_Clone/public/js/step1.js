function backpage(event){
    event.preventDefault();
    function execute(){
        fetch('/back',{
            method:"get",
            headers:{
                'Content-Type':"application/json"
            }
        })
        .then(response=>{
            if(response.redirected){
                window.location.href=response.url;
            }
            else{
                throw new Error;
            }
        })
        .then(data=>console.log(data))
        .catch(error=>console.error(error));
    }
    execute()
}
function next(event){
    event.preventDefault();
    fetch('/nextone',{
        method:"get",
        headers:{
            'Content-Type':"application/json"
        }
    })
    .then(response=>{
        if(response.redirected){
            window.location.href=response.url;
        }
        else{
            throw new Error;
        }
    })
    .then(data=>console.log(data))
    .catch(error=>console.error(error));
}