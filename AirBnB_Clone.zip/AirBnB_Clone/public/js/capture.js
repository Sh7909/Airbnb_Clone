function backbutton(event) {
    event.preventDefault();
    fetch('/back7', {
        method: "get",
        headers: {
            'Content-Type': "application/json"
        }
    })
        .then(response => {
            if (response.redirected) {
                window.location.href = response.url;
            }
            else {
                throw new Error
            }
        })
        .then(data => console.log(data))
        .catch(error => console.error(error))
}
function nextbutton(event) {
    const section16 = document.getElementsByClassName("section16")[0];
    const images = section16.querySelectorAll('img');
    event.preventDefault();
    if (images.length > 1) {
        fetch('/next3', {
            method: "get",
            headers: {
                'Content-Type': "application/json"
            }
        })
            .then(response => {
                if (response.redirected) {
                    window.location.href = response.url;
                }
                else {
                    throw new Error
                }
            })
            .then(data => console.log(data))
            .catch(error => console.error(error))
    }
    else {
        alert("Please select at least 5 images and refresh the page")
        return;
    }
}
function OpenNow() {
    const format = document.getElementById("format");
    const section2img = document.querySelector(".section2 img");
    const section16 = document.getElementsByClassName("section16")[0];
    const camera = document.getElementById("camera");
    const section17 = document.getElementsByClassName("section17")[0];
    const section18 = document.getElementsByClassName("section18")[0];
    const section23 = document.getElementsByClassName("section23")[0];
    const section25 = document.getElementById("section25");
    const uploadbutton = document.getElementById("uploadbutton");
    const previewContainer1 = document.getElementById("previewContainer1");
    const previewContainer2 = document.getElementById("previewContainer2");
    const multipleInput = document.getElementById("multiple_input");
    camera.style.filter = "brightness(0.5)";
    format.style.backgroundColor = "rgb(123, 123, 123)";
    section2img.style.filter = "brightness(0.5)";
    section16.style.backgroundColor = "rgb(123, 123, 123)";
    section17.style.backgroundColor = "rgb(123, 123, 123)";
    section18.style.display = "block";
    section23.style.marginTop = "5rem";
    uploadbutton.style.marginTop = "7rem";
    section25.style.backgroundColor = "rgb(123, 123, 123)";
    document.body.addEventListener('click', (event) => {
        if (!section17.contains(event.target)) {
            closeDialog();
        }
    });
    function closeDialog() {
        camera.style.filter = "";
        format.style.backgroundColor = "";
        section2img.style.filter = "";
        section16.style.backgroundColor = "";
        section17.style.backgroundColor = "";
        section18.style.display = "none";
        section18.style.height = "53rem";
        section23.style.display = "block";
        section23.style.marginTop = "9rem";
        section25.style.backgroundColor = "";
        previewContainer1.style.display = "none";
        previewContainer2.style.display = "none";
        uploadbutton.style.marginTop = "11rem";
        multipleInput.value = "";  // Clear file input
        previewContainer2.innerHTML = "";  // Clear previous images
    }
}
const section18 = document.getElementsByClassName("section18")[0];
section18.addEventListener('click', (event) => {
    let MultipleInput = document.getElementById("multiple_input");
    event.stopPropagation();
    if (!section18.contains(event.target)) {
        MultipleInput.value = "";
    }
});
function closeDialog() {
    const format = document.getElementById("format");
    const section2img = document.querySelector(".section2 img");
    const section16 = document.getElementsByClassName("section16")[0];
    const camera = document.getElementById("camera");
    const section17 = document.getElementsByClassName("section17")[0];
    const section18 = document.getElementsByClassName("section18")[0];
    const section23 = document.getElementsByClassName("section23")[0];
    const section25 = document.getElementById("section25");
    const uploadbutton = document.getElementById("uploadbutton");
    const previewContainer1 = document.getElementById("previewContainer1");
    const previewContainer2 = document.getElementById("previewContainer2");
    const multipleInput = document.getElementById("multiple_input");
    camera.style.filter = "";
    format.style.backgroundColor = "";
    section2img.style.filter = "";
    section16.style.backgroundColor = "";
    section17.style.backgroundColor = "";
    section18.style.display = "none";
    section18.style.height = "53rem";
    section23.style.display = "block";
    section23.style.marginTop = "9rem";
    section25.style.backgroundColor = "";
    previewContainer1.style.display = "none";
    previewContainer2.style.display = "none";
    uploadbutton.style.marginTop = "11rem";
    multipleInput.value = "";  // Clear file input
    previewContainer2.innerHTML = "";  // Clear previous images
}
function opendialogue(inputdata) {
    document.getElementById(inputdata).click();
    const section23 = document.getElementsByClassName("section23")[0];
    const section26 = document.getElementsByClassName("section26")[0];
    const previewContainer1 = document.getElementById("previewContainer1");
    const previewContainer2 = document.getElementById("previewContainer2");
    if (inputdata !== "") {
        section26.style.backgroundColor = "black";
    }
    section23.style.marginTop = "-23rem";
    previewContainer1.style.display = "grid";
    previewContainer2.style.display = "grid";
}
function previewImage() {
    const input = document.getElementById('multiple_input');
    const files = input.files;
    const previewContainer1 = document.getElementById('previewContainer1');
    const previewContainer2 = document.getElementById('previewContainer2');
    const section18 = document.getElementsByClassName('section18')[0];
    const section23 = document.getElementsByClassName('section23')[0];
    const section25one = document.getElementById('section25one');
    const section27 = document.getElementsByClassName('section27')[0];
    const section28 = document.getElementsByClassName('section28')[0];
    const uploadbutton = document.getElementById('uploadbutton');
    previewContainer1.style.display = "grid";
    section18.style.height = "60rem";
    section23.style.display = "none";
    section25one.style.display = "block";
    section27.style.display = "none";
    section28.style.marginTop = "5rem";
    uploadbutton.style.marginTop = "1rem";
    previewContainer2.innerHTML = "";
    Array.from(files).forEach(file => {
        const reader = new FileReader();
        reader.onload = function (e) {
            const img = document.createElement('img');
            img.src = e.target.result;
            previewContainer2.appendChild(img);
        };
        reader.readAsDataURL(file);
    });
}
function close1(event) {
    if (event && typeof event.preventDefault === 'function') {
        event.preventDefault();
    }
    const section2img = document.querySelector('.section2 img');
    const section16 = document.getElementsByClassName('section16')[0];
    const section17 = document.getElementsByClassName('section17')[0];
    const section18 = document.getElementsByClassName('section18')[0];
    const section23 = document.getElementsByClassName('section23')[0];
    const section25 = document.getElementById('section25');
    const section25one = document.getElementById('section25one');
    const section27 = document.getElementsByClassName('section27')[0];
    const section28 = document.getElementsByClassName('section28')[0];
    const uploadbutton = document.getElementById('uploadbutton');
    const previewContainer1 = document.getElementById('previewContainer1');
    const previewContainer2 = document.getElementById('previewContainer2');
    const multipleInput = document.getElementById('multiple_input');
    const format = document.getElementById('format');
    const camera = document.getElementById('camera');
    format.style.backgroundColor = "";
    section16.style.backgroundColor = "";
    section17.style.backgroundColor = "";
    camera.style.filter = "";
    section2img.style.filter = "";
    section18.style.display = "none";
    section18.style.height = "53rem";
    section23.style.display = "block";
    section27.style.display = "block";
    section25.style.backgroundColor = "";
    section25one.style.display = "block";
    section28.style.marginTop = "2rem";
    uploadbutton.style.marginTop = "7rem";
    previewContainer1.style.display = "none";
    previewContainer2.innerHTML = ""; // Clear preview images
    multipleInput.value = ""; // Clear file input
}
document.getElementById('myForm').addEventListener('submit', function (event) {
    event.preventDefault();
    const form = event.target; // Get the form element
    const formData = new FormData(form); // Create a FormData object
    fetch('/upload', {
        method: 'POST',
        body: formData
    })
        .then(response => {
            if (!response.ok) {
                alert("Please Upload Only 20 images");
                throw new Error('Network response was not ok');
            }
            return response.json();
        })
        .then(data => {
            if (data.error) {
                console.error('Error:', data.error);
                return;
            }
            const imageDiv = document.querySelector('.section16');
            imageDiv.innerHTML = '';
            data.images.forEach(image => {
                const img = document.createElement('img');
                img.src = `/images/${image}`;
                img.style.width = '19rem';
                img.style.height = '15rem';
                img.style.margin = '1rem';
                imageDiv.appendChild(img);
            });
        })
        .catch(error => console.error('Error:', error));
});
document.addEventListener('DOMContentLoaded', function () {
    const form = document.querySelector('form');
    const section18 = document.getElementsByClassName("section18")[0];
    const section26 = document.getElementById("section26");
    const imageDiv = document.querySelector('.section16');
    form.addEventListener('submit', function (event) {
        event.preventDefault();
        imageDiv.style.overflowY = "scroll";
        imageDiv.style.overflowX = "hidden";
        closeDialog();
        section26.style.backgroundColor = "black";
        section26.style.cursor="pointer";
        const formData = new FormData(form);
        fetch('/upload', {
            method: 'POST',
            body: formData,
        })
            .then(response => {
                if (!response.ok) {
                    alert("Please Upload Only 20 images");
                    throw new Error('Network response was not ok');
                }
                return response.json();
            })
            .then(data => {
                const imageDiv = document.querySelector('.section16');
                imageDiv.innerHTML = ''; // Clear previous content
                data.images.forEach(image => {
                    const img = document.createElement('img');
                    img.src = `/images/${image}`;
                    img.style.width = '19rem';
                    img.style.height = '15rem';
                    img.style.margin = '1rem';
                    imageDiv.appendChild(img);
                    section18.style.display = "none";
                });

            })
            .catch(error => console.error('Error:', error));
    });
});