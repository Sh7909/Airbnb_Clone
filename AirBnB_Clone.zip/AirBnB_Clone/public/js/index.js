function fun1() {
    const st = document.getElementById("st");
    const exp = document.getElementById("exp");
    const online = document.getElementById("online");
    st.style.fontWeight = 500;
    st.style.color = "black";
    exp.style.fontWeight = "normal";
    exp.style.color = "gray";
    online.style.fontWeight = "normal";
    online.style.color = "gray";
}
function fun2() {
    const exp = document.getElementById("exp");
    const st = document.getElementById("st");
    const online = document.getElementById("online");
    exp.style.fontWeight = 500;
    exp.style.color = "black";
    st.style.fontWeight = "normal";
    st.style.color = "gray";
    online.style.fontWeight = "normal";
    online.style.color = "gray"
}

function call1() {
    const langdivcont = document.getElementById("langdivcont");
    langdivcont.style.display = "none";
}
function fun3() {
    const profilepopup = document.getElementById("profilepopup");
    const langdivcont = document.getElementById("langdivcont");
    langdivcont.style.display = "none";
    if (profilepopup.style.display === "none" || profilepopup.style.display === "") {
        profilepopup.style.display = "block";
        document.body.addEventListener('click', closeProfilePopupOnClickOutside);
    } else {
        profilepopup.style.display = "none";
    }
}

function closeProfilePopupOnClickOutside(event) {
    const profilepopup = document.getElementById("profilepopup");
    const loginicon = document.querySelector(".loginicon");
    // Check if the clicked element is outside the profilepopup or the loginicon
    if (!profilepopup.contains(event.target) && !loginicon.contains(event.target)) {
        profilepopup.style.display = "none";

    }
}


const user = document.getElementsByClassName("user")[0];
user.addEventListener("click", () => {
    fun3();
})

document.addEventListener('DOMContentLoaded', function () {
    function fun3() {
        const langdivcont = document.getElementById("langdivcont");
        const profilepopup = document.getElementById("profilepopup");
        langdivcont.style.display = "none";

        if (profilepopup.style.display === "none" || profilepopup.style.display === "") {
            profilepopup.style.display = "block";
            document.body.addEventListener('click', closeProfilePopupOnClickOutside);
        } else {
            profilepopup.style.display = "none";
        }
    }

    function closeProfilePopupOnClickOutside(event) {
        const profilepopup = document.getElementById("profilepopup");
        const loginicon = document.querySelector(".loginicon");

        // Check if the clicked element is outside the profilepopup or the loginicon
        if (!profilepopup.contains(event.target) && !loginicon.contains(event.target)) {
            profilepopup.style.display = "none";

        }
    }


    const user = document.getElementsByClassName("user")[0];
    user.addEventListener("click", () => {
        fun3();
    });

});

function fun4() {
    const profilepopup = document.getElementById("profilepopup");
    profilepopup.style.display = "none";
}
function fun5() {
    const sc1 = document.getElementById("sc1");
    const sc2 = document.getElementById("sc2");
    const sc3 = document.getElementById("sc3");
    const sc4 = document.getElementById("sc4");
    const change = document.getElementById("change");
    const v2 = document.getElementById("v2");
    const u = document.getElementById("u");
    const texthere = document.getElementById("texthere");
    const searchlg = document.getElementById("searchlg");
    const f1 = document.getElementById("f1");
    const f2 = document.getElementById("f2");
    const f3 = document.getElementById("f3");
    const d1 = document.getElementById("d1");
    const d2 = document.getElementById("d2");
    const d3 = document.getElementById("d3");
    const u1 = document.getElementById("u1");
    sc1.classList.add("changecolor2");
    u.classList.add("changecolor2");
    sc1.classList.add("applyboxshadow");
    sc2.classList.remove("applyboxshadow");
    sc3.classList.remove("applyboxshadow");
    sc4.classList.remove("applyboxshadow");
    sc2.classList.remove("changecolor2");
    sc3.classList.remove("changecolor2");
    sc4.classList.remove("changecolor2");
    sc4.classList.remove("applyboxshadow");
    f1.classList.remove("changecolor2");
    f2.classList.remove("changecolor2");
    f3.classList.remove("changecolor2");
    u1.classList.add("changecolor");
    sc2.classList.add('changecolor');
    sc3.classList.add('changecolor');
    sc4.classList.add("changecolor");
    f1.classList.add("changecolor");
    f2.classList.add("changecolor");
    f3.classList.add("changecolor");
    change.style.marginLeft = "-39%";
    change.style.width = "6.9rem";
    change.style.height = "4rem";
    change.style.borderRadius = "2rem";
    searchlg.style.marginTop = "-50%";
    searchlg.style.marginLeft = "-150%";
    texthere.style.display = "block";
    d1.style.borderLeft = "2px solid rgb(172, 173, 172)";
    d2.style.borderLeft = "2px solid rgb(172, 173, 172)";
    d3.style.display = "none";
    d1.style.display = "block";
    d2.style.display = "block";
    v2.style.backgroundImage = "linear-gradient(to right,rgb(226, 63, 93),rgb(210, 64, 91))";
    change.style.backgroundImage = "linear-gradient(to right,rgb(246, 60, 94),rgb(200, 65, 90))"
    document.body.addEventListener('click', function (event) {
        var isClickedInsideSearch = event.target.closest('.searchcontainer');
        if (!isClickedInsideSearch) {
            change.style.width = '';
            texthere.style.display = "none";
            searchlg.style.marginTop = "";
            searchlg.style.marginLeft = "";
            change.style.marginLeft = "";
            change.style.height = "";
            change.style.backgroundColor = "rgb(255, 56, 92)";
            change.style.backgroundImage = ""
            v2.style.backgroundImage = ""
            sc1.classList.remove("changecolor2");
            u.classList.remove("changecolor2");
            u1.classList.remove("changecolor");
            sc2.classList.remove('changecolor');
            sc3.classList.remove('changecolor');
            sc4.classList.remove("changecolor");
            f1.classList.remove("changecolor");
            f2.classList.remove("changecolor");
            f3.classList.remove("changecolor");
            sc1.classList.remove("applyboxshadow");
            d3.style.display = "";
            d1.style.display = "";
            d2.style.display = "";
        }
    });
}
function fun6() {
    const sc1 = document.getElementById("sc1");
    const u1 = document.getElementById("u1")
    const sc2 = document.getElementById("sc2");
    const sc3 = document.getElementById("sc3");
    const sc4 = document.getElementById("sc4");
    const change = document.getElementById("change");
    const v2 = document.getElementById("v2");
    const texthere = document.getElementById("texthere");
    const searchlg = document.getElementById("searchlg");
    const f1 = document.getElementById("f1");
    const u = document.getElementById("u");
    const f2 = document.getElementById("f2");
    const f3 = document.getElementById("f3");
    const d2 = document.getElementById("d2");
    const d1 = document.getElementById("d1");
    const d3 = document.getElementById("d3");
    sc2.classList.add("changecolor2");
    f1.classList.add("changecolor2");
    sc1.classList.remove("changecolor2");
    u.classList.remove("changecolor2");
    sc3.classList.remove("changecolor2");
    sc4.classList.remove("changecolor2");
    f2.classList.remove("changecolor2");
    f3.classList.remove("changecolor2");
    sc1.classList.remove("applyboxshadow");
    sc2.classList.add("applyboxshadow");
    sc3.classList.remove("applyboxshadow");
    sc4.classList.remove("applyboxshadow");
    u1.classList.add("changecolor");
    sc1.classList.add("changecolor");
    sc3.classList.add("changecolor");
    sc4.classList.add("changecolor");
    u.classList.add("changecolor");
    f2.classList.add("changecolor");
    f3.classList.add("changecolor");
    searchlg.style.marginTop = "-50%";
    searchlg.style.marginLeft = "-150%";
    texthere.style.display = "block";
    change.style.width = "8rem";
    change.style.height = "4rem";
    change.style.borderRadius = "2rem";
    change.style.marginLeft = "-39%";
    change.style.width = "6.9rem";
    v2.style.display = "block";
    d2.style.borderLeft = "2px solid rgb(172, 173, 172)";
    d2.style.display = "block";
    d1.style.display = "none";
    d3.style.display = "none";
    v2.style.backgroundImage = "linear-gradient(to right,rgb(226, 63, 93),rgb(210, 64, 91))";
    change.style.backgroundImage = "linear-gradient(to right,rgb(246, 60, 94),rgb(200, 65, 90))";
    document.body.addEventListener('click', function (event) {
        var isClickedInsideSearch = event.target.closest('.searchcontainer');
        if (!isClickedInsideSearch) {
            change.style.width = '';
            texthere.style.display = "none";
            searchlg.style.marginTop = "";
            searchlg.style.marginLeft = "";
            change.style.marginLeft = "";
            change.style.height = "";
            change.style.backgroundColor = "rgb(255, 56, 92)";
            change.style.backgroundImage = ""
            v2.style.backgroundImage = ""
            sc2.classList.remove("changecolor2");
            f1.classList.remove("changecolor2");
            u1.classList.remove("changecolor");
            sc1.classList.remove("changecolor");
            sc3.classList.remove("changecolor");
            sc4.classList.remove("changecolor");
            u.classList.remove("changecolor");
            f2.classList.remove("changecolor");
            f3.classList.remove("changecolor");
            sc2.classList.remove("applyboxshadow");
            d2.style.display = "";
            d1.style.display = "";
            d3.style.display = "";
        }
    });
}

const f1 = document.getElementById("f1");
f1.addEventListener('click', () => {
    fun6();
})
function fun7() {
    const sc1 = document.getElementById("sc1");
    const sc2 = document.getElementById("sc2");
    const u1 = document.getElementById("u1")
    const sc3 = document.getElementById("sc3");
    const sc4 = document.getElementById("sc4");
    const change = document.getElementById("change");
    const texthere = document.getElementById("texthere");
    const searchlg = document.getElementById("searchlg");
    const f2 = document.getElementById("f2");
    const f1 = document.getElementById("f1");
    const u = document.getElementById("u");
    const v2 = document.getElementById("v2");
    const d3 = document.getElementById("d3");
    const d2 = document.getElementById("d2");
    const f3 = document.getElementById("f3");
    const d1 = document.getElementById("d1");
    sc3.classList.add("changecolor2");
    f2.classList.add("changecolor2");
    sc3.classList.add("applyboxshadow");
    sc1.classList.remove("changecolor2");
    sc1.classList.remove("applyboxshadow")
    sc2.classList.remove("applyboxshadow");
    sc4.classList.remove("applyboxshadow");
    u.classList.remove("changecolor2");
    sc2.classList.remove("changecolor2");
    f1.classList.remove("changecolor2");
    sc4.classList.remove("changecolor2");
    f3.classList.remove("changecolor2");
    sc2.classList.remove("applyboxshadow");
    u1.classList.add("changecolor");
    sc1.classList.add("changecolor");
    sc2.classList.add("changecolor");
    sc4.classList.add("changecolor");
    u.classList.add("changecolor");
    f1.classList.add("changecolor");
    f3.classList.add("changecolor");
    searchlg.style.marginTop = "-50%";
    searchlg.style.marginLeft = "-150%";
    texthere.style.display = "block";
    change.style.width = "8rem";
    change.style.height = "4rem";
    change.style.borderRadius = "2rem";
    change.style.marginLeft = "-39%";
    change.style.width = "6.9rem";
    v2.style.display = "block";
    d3.style.display = "block";
    d1.style.display = "none";
    d2.style.display = "none";
    d3.style.borderLeft = "2px solid rgb(172, 173, 172)";
    v2.style.backgroundImage = "linear-gradient(to right,rgb(226, 63, 93),rgb(210, 64, 91))";
    change.style.backgroundImage = "linear-gradient(to right,rgb(246, 60, 94),rgb(200, 65, 90))";
    document.body.addEventListener('click', function (event) {
        var isClickedInsideSearch = event.target.closest('.searchcontainer');
        if (!isClickedInsideSearch) {
            change.style.width = '';
            texthere.style.display = "none";
            searchlg.style.marginTop = "";
            searchlg.style.marginLeft = "";
            change.style.marginLeft = "";
            change.style.height = "";
            change.style.backgroundColor = "rgb(255, 56, 92)";
            change.style.backgroundImage = ""
            v2.style.backgroundImage = ""
            sc3.classList.remove("changecolor2");
            f2.classList.remove("changecolor2");
            u1.classList.remove("changecolor");
            sc1.classList.remove("changecolor");
            sc2.classList.remove("changecolor");
            sc4.classList.remove("changecolor");
            u.classList.remove("changecolor");
            f1.classList.remove("changecolor");
            f3.classList.remove("changecolor");
            sc3.classList.remove("applyboxshadow");
            d3.style.display = "";
            d1.style.display = "";
            d2.style.display = "";
        }
    });
}
const f2 = document.getElementById("f2");
f2.addEventListener('click', () => {
    fun7();
})
function fun8() {
    const sc1 = document.getElementById("sc1");
    const sc2 = document.getElementById("sc2");
    const sc3 = document.getElementById("sc3");
    const u1 = document.getElementById("u1")
    const sc4 = document.getElementById("sc4");
    const change = document.getElementById("change");
    const texthere = document.getElementById("texthere");
    const searchlg = document.getElementById("searchlg");
    const f3 = document.getElementById("f3");
    const u = document.getElementById("u");
    const f1 = document.getElementById("f1");
    const f2 = document.getElementById("f2");
    const v2 = document.getElementById("v2");
    const d1 = document.getElementById("d1");
    const d3 = document.getElementById("d3");
    const d2 = document.getElementById("d2");
    sc4.classList.add("changecolor2");
    f3.classList.add("changecolor2");
    sc4.classList.add("applyboxshadow");
    sc1.classList.remove("changecolor2");
    sc2.classList.remove("changecolor2");
    sc3.classList.remove("changecolor2");
    u.classList.remove("changecolor2");
    f1.classList.remove("changecolor2");
    f2.classList.remove("changecolor2");
    sc1.classList.remove("applyboxshadow");
    sc2.classList.remove("applyboxshadow");
    sc3.classList.remove("applyboxshadow");
    searchlg.style.marginTop = "-50%";
    searchlg.style.marginLeft = "-150%";
    texthere.style.display = "block";
    u1.classList.add("changecolor");
    sc1.classList.add("changecolor");
    sc2.classList.add("changecolor");
    sc3.classList.add("changecolor");
    u.classList.add("changecolor");
    f1.classList.add("changecolor");
    f2.classList.add("changecolor");
    change.style.width = "8rem";
    change.style.height = "4rem";
    change.style.borderRadius = "2rem";
    change.style.marginLeft = "-39%";
    change.style.width = "6.9rem";
    v2.style.display = "block";
    d1.style.borderLeft = "2px solid rgb(172, 173, 172)";
    d3.style.borderLeft = "2px solid rgb(172, 173, 172)";
    d1.style.display = "block";
    d2.style.display = "none";
    v2.style.backgroundImage = "linear-gradient(to right,rgb(226, 63, 93),rgb(210, 64, 91))";
    change.style.backgroundImage = "linear-gradient(to right,rgb(246, 60, 94),rgb(200, 65, 90))";
    document.body.addEventListener('click', function (event) {
        var isClickedInsideSearch = event.target.closest('.searchcontainer');
        if (!isClickedInsideSearch) {
            change.style.width = '';
            texthere.style.display = "none";
            searchlg.style.marginTop = "";
            searchlg.style.marginLeft = "";
            change.style.marginLeft = "";
            change.style.height = "";
            change.style.backgroundColor = "rgb(255, 56, 92)";
            change.style.backgroundImage = ""
            v2.style.backgroundImage = ""
            sc4.classList.remove("changecolor2");
            f3.classList.remove("changecolor2");
            u1.classList.remove("changecolor");
            sc1.classList.remove("changecolor");
            sc2.classList.remove("changecolor");
            sc3.classList.remove("changecolor");
            u.classList.remove("changecolor");
            f1.classList.remove("changecolor");
            f2.classList.remove("changecolor");
            sc4.classList.remove("applyboxshadow");
            d1.style.display = "";
            d2.style.display = "";
        }
    });
    document.body.addEventListener('click', (event) => {
        const lastdiv1 = document.getElementsByClassName("lastdiv1")[0];
        if (!sc4.contains(event.target)) {
            lastdiv1.style.display = "none";
        }
        else {
            lastdiv1.style.display = "block";
        }
    })
}
let counter5 = 0;
function add5() {
    const lastdiv7 = document.getElementById("lastdiv7");
    const lastdiv6 = document.getElementById("lastdiv6");
    const lastdiv9 = document.getElementsByClassName("lastdiv9")[0];
    const f3 = document.getElementById("f3");
    const lastdiv10 = document.getElementById("lastdiv10");
    const sub5 = document.getElementById("sub5");
    const firstadd = document.getElementById("firstadd");
    f3.style.fontSize = "1.3rem";
    f3.style.fontWeight = "500";
    counter5++;
    lastdiv6.style.userSelect = "none";
    lastdiv9.style.userSelect = "none";
    lastdiv9.style.cursor = "pointer";
    lastdiv10.style.cursor = "pointer";
    f3.value = "";
    lastdiv7.innerHTML = counter5;
    UpdateNumberofGuests(counter5, counter6, counter7, counter8)
    firstadd.style.color = "black";
    sub5.style.color = "black";
    lastdiv6.onmouseover = () => {
        lastdiv6.style.border = "2px solid black";
        firstadd.style.color = "black";
    }
    lastdiv6.onmouseout = () => {
        lastdiv6.style.border = "2px solid rgb(185, 185, 185)";
    }
    lastdiv10.onmouseover = () => {
        lastdiv10.style.border = "2px solid black";
        lastdiv9.style.color = "black";
    }
    lastdiv10.onmouseout = () => {
        lastdiv10.style.border = "2px solid rgb(185, 185, 185)";
    }
}
function sub5() {
    const lastdiv6 = document.getElementById("lastdiv6");
    const lastdiv7 = document.getElementById("lastdiv7");
    const lastdiv9 = document.getElementsByClassName("lastdiv9")[0];
    const lastdiv10 = document.getElementById("lastdiv10");
    lastdiv6.style.cursor = "pointer";
    if (counter5 > 0) {
        counter5--;
        lastdiv7.innerHTML = counter5;
        UpdateNumberofGuests(counter5, counter6, counter7, counter8)
        lastdiv10.style.cursor = "pointer";

    }
    if (counter5 == 0) {
        lastdiv10.style.cursor = "not-allowed";
        lastdiv9.style.cursor = "not-allowed";
        lastdiv10.style.border = "2px solid rgb(185, 185, 185)";
        lastdiv9.style.color = "rgb(185, 185, 185)"
        lastdiv10.onmouseover = () => {
            lastdiv10.style.border = "2px solid rgb(185, 185, 185)";
            lastdiv9.style.color = "rgb(185, 185, 185)";
        }
        lastdiv10.onmouseout = () => {
            lastdiv10.style.border = "2px solid rgb(185, 185, 185)";
            lastdiv9.style.color = "rgb(185, 185, 185)";
        }
    }

}
let counter6 = 0;
function add6() {
    const value5 = document.getElementById("value5");
    const value6 = document.getElementById("value6");
    const f3 = document.getElementById("f3");
    const value1 = document.getElementById("value1");
    const sub6 = document.getElementById("sub6");
    f3.style.fontSize = "1.3rem";
    f3.style.fontWeight = "500";
    counter6++;
    value1.style.cursor = "pointer";
    sub6.style.cursor = "pointer";
    value5.innerHTML = counter6;
    UpdateNumberofGuests(counter5, counter6, counter7, counter8)
    sub6.style.color = "black";
    value1.onmouseover = () => {
        value1.style.border = "2px solid black";
    }
    value1.onmouseout = () => {
        value1.style.border = "2px solid rgb(185, 185, 185)";
    }
    value6.onmouseover = () => {
        value6.style.cursor = "pointer";
        value6.style.border = "2px solid black";
    }
    value6.onmouseout = () => {
        value6.style.border = "2px solid rgb(185, 185, 185)";
    }
}
function sub6() {
    const value5 = document.getElementById("value5");
    const value1 = document.getElementById("value1");
    const sub6 = document.getElementById("sub6");
    value1.style.userSelect = "none";
    sub6.style.userSelect = "none";
    if (counter6 > 0) {
        counter6--;
        value5.innerHTML = counter6;
        UpdateNumberofGuests(counter5, counter6, counter7, counter8);
        value1.style.cursor = "pointer";
        sub6.style.cursor = "pointer";
        value1.onmouseover = () => {
            value1.style.border = "2px solid black";
            sub6.style.color = "black";
        }
        value1.onmouseout = () => {
            value1.style.border = "2px solid rgb(185, 185, 185)";
            sub6.style.color = "rgb(185, 185, 185)";
        }
    }
    if (counter6 == 0) {
        value1.style.cursor = "not-allowed";
        sub6.style.cursor = "not-allowed";
        value1.style.border = "2px solid rgb(185, 185, 185)";
        sub6.style.color = "rgb(185, 185, 185)";
        value1.onmouseover = () => {
            value1.style.border = "2px solid rgb(185, 185, 185)";
            sub6.style.color = "rgb(185, 185, 185)";
            value1.style.cursor = "not-allowed";
            sub6.style.cursor = "not-allowed";
        }
        value1.onmouseout = () => {
            value1.style.border = "2px solid rgb(185, 185, 185)";
            sub6.style.color = "rgb(185, 185, 185)";
            value1.style.cursor = "not-allowed";
            sub6.style.cursor = "not-allowed";
        }
    }
}
let counter7 = 0;
function add7() {
    const value8 = document.getElementById("value8");
    const thirdadd = document.getElementById("thirdadd");
    const add7 = document.getElementById("add7");
    const f3 = document.getElementById("f3");
    const sub7 = document.getElementById("sub7");
    const value7 = document.getElementById("value7");
    counter7++;
    value8.innerHTML = counter7;
    UpdateNumberofGuests(counter5, counter6, counter7, counter8);
    add7.style.cursor = "pointer";
    add7.style.userSelect = "none";
    thirdadd.style.userSelect = "none";
    f3.style.fontSize = "1.3rem";
    f3.style.fontWeight = "500";
    sub7.style.color = "black";
    value7.style.cursor = "pointer";
    sub7.style.cursor = "pointer";
    add7.onmouseover = () => {
        add7.style.border = "2px solid black";
    }
    add7.onmouseout = () => {
        add7.style.border = "2px solid rgb(185, 185, 185)";
    }
    value7.onmouseover = () => {
        value7.style.border = "2px solid black";
    }
    value7.onmouseout = () => {
        value7.style.border = "2px solid rgb(185, 185, 185)";
    }
}
function sub7() {
    const sub7 = document.getElementById("sub7");
    const value7 = document.getElementById("value7");
    const value8 = document.getElementById("value8");
    value7.style.userSelect = "none";
    sub7.style.userSelect = "none";
    if (counter7 > 0) {
        counter7--;
        value8.innerHTML = counter7;
        UpdateNumberofGuests(counter5, counter6, counter7, counter8);
        value7.style.cursor = "pointer";
    }
    if (counter7 == 0) {
        value7.style.cursor = "not-allowed";
        sub7.style.cursor = "not-allowed";
        value7.style.border = "2px solid rgb(185, 185, 185)";
        sub7.style.color = "rgb(185, 185, 185)";
        value7.onmouseover = () => {
            value7.style.border = "2px solid rgb(185, 185, 185)";
            sub7.style.color = "rgb(185, 185, 185)";
        }
        value7.onmouseout = () => {
            value7.style.border = "2px solid rgb(185, 185, 185)";
            sub7.style.color = "rgb(185, 185, 185)";
        }
    }
}


let counter8 = 0;
function add8() {
    const value10 = document.getElementById("value10");
    const f3 = document.getElementById("f3");
    const add8 = document.getElementById("add8");
    const value9 = document.getElementById("value9");
    const sub8 = document.getElementById("sub8");
    counter8++;
    value10.innerHTML = counter8;
    UpdateNumberofGuests(counter5, counter6, counter7, counter8)
    f3.style.fontSize = "1.3rem";
    f3.style.fontWeight = "500";
    add8.style.cursor = "pointer";
    add8.style.userSelect = "none";
    add8.style.userSelect = "none";
    sub8.style.color = "black";
    value9.style.cursor = "pointer";
    sub8.style.cursor = "pointer";
    add8.onmouseover = () => {
        add8.style.border = "2px solid black";
    }
    add8.onmouseout = () => {
        add8.style.border = "2px solid rgb(185, 185, 185)";
    }
    value9.onmouseover = () => {
        value9.style.border = "2px solid black";
    }
    value9.onmouseout = () => {
        value9.style.border = "2px solid rgb(185, 185, 185)";
    }
}
function sub8() {
    const value10 = document.getElementById("value10");
    const value9 = document.getElementById("value9");
    const sub8 = document.getElementById("sub8");
    sub8.style.userSelect = "none";
    value9.style.userSelect = "none";
    if (counter8 > 0) {
        sub8.style.userSelect = "none";
        value9.style.userSelect = "none";
        counter8--;
        value10.innerHTML = counter8;
        UpdateNumberofGuests(counter5, counter6, counter7, counter8)
        value9.style.cursor = "pointer";
        sub8.style.cursor = "pointer";
    }
    if (counter8 == 0) {
        value9.style.cursor = "not-allowed";
        sub8.style.cursor = "not-allowed";
        value9.style.border = "2px solid rgb(185, 185, 185)";
        sub8.style.color = "rgb(185, 185, 185)";
        value9.onmouseover = () => {
            value9.style.border = "2px solid rgb(185, 185, 185)";
            sub8.style.color = "rgb(185, 185, 185)";
        }
        value9.onmouseout = () => {
            value9.style.border = "2px solid rgb(185, 185, 185)";
            sub8.style.color = "rgb(185, 185, 185)";
        }
    }
}
var inputData = "";
function UpdateNumberofGuests(a, b, c, d) {
    const f3 = document.getElementById("f3");
    f3.value = "";
    if (a > 0) {
        inputData = a + " guests";
        f3.value += inputData;
    }
    if (b > 0) {
        inputData = " ," + b + " " + "guests";
        f3.value += inputData;
    }
    if (c > 0) {
        inputData = " ," + c + " " + "infants";
        f3.value += inputData;
    }
    if (d > 0) {
        inputData = " ," + d + " " + "pets";
        f3.value += inputData;
    }

    return inputData;
}

function showdata() {
    const datacomes = document.getElementsByClassName("datacomes")[0];
    const tbl = document.getElementById("tbl");
    const hide = document.getElementById("hide");
    hide.style.display = "none";
    datacomes.style.display = "block";
    datacomes.style.display = "grid";
    tbl.style.display = "none"
    datacomes.style.gridTemplateColumns = "repeat(6,25rem)";
    datacomes.style.marginLeft = "3.4%";

}
function fun9() {
    const langdivcont = document.getElementById("langdivcont");
    const pElements = document.querySelectorAll(".p img");
    const dbimg = document.getElementById("dbimg");
    const colorchanges = document.getElementById("colorchanges");
    const imagedes = document.getElementsByClassName("imagedes")[0];
    const container2 = document.getElementById("container2");
    const loginicon = document.getElementsByClassName("loginicon")[0];
    const airbnb = document.getElementsByClassName("airbnb")[0];
    const brw = document.getElementsByClassName("brw")[0];
    const searchcontainer = document.getElementsByClassName("searchcontainer")[0];
    const u1 = document.getElementById("u1");
    const sc1 = document.getElementById("sc1");
    const sc4 = document.getElementById("sc4");
    const u = document.getElementById("u");
    const f1 = document.getElementById("f1");
    const f2 = document.getElementById("f2");
    const f3 = document.getElementById("f3");
    const v1 = document.getElementsByClassName("v1")[0];
    const v2 = document.getElementsByClassName("v2")[0];
    const v4 = document.getElementsByClassName("v4")[0];
    const grayfooter=document.getElementsByClassName("grayfooter")[0];
    const fetchdata=document.querySelectorAll(".fetchdata");
    const KElements=document.querySelectorAll("#k");
    const ZElements=document.querySelectorAll("#z");
   const last1=document.getElementsByClassName("last1")[0];
   const last2=document.getElementsByClassName("last2")[0]
        langdivcont.classList.remove("show");
        langdivcont.classList.add("hide");
        pElements.forEach(img => {
            img.style.filter = "none";

        });
        last1.style.backgroundColor="";
        last2.style.backgroundColor="";
        grayfooter.style.backgroundColor="";
        fetchdata.forEach((element)=>{
            element.style.backgroundColor="";
        });
        KElements.forEach((element)=>{
            element.style.backgroundColor="";
        });
         ZElements.forEach((element)=>{
            element.style.backgroundColor="";
        });
        colorchanges.style.backgroundColor = "";
        colorchanges.style.overflow = "";
        dbimg.style.backgroundColor = "";
        container2.style.backgroundColor = "";
        loginicon.style.filter = "none";
        imagedes.style.color = "";
        u1.style.backgroundColor = "";
        u1.style.border = "";
        u1.style.boxShadow = "";
        sc1.style.backgroundColor = "";
        sc4.style.backgroundColor = "";
        u.style.backgroundColor = "";
        f1.style.backgroundColor = "";
        f2.style.backgroundColor = "";
        f3.style.backgroundColor = "";
        v1.style.borderLeft = "";
        v2.style.borderLeft = "";
        v4.style.borderLeft = "";
        loginicon.style.border = "";
        loginicon.style.pointerEvents = "";
        airbnb.style.pointerEvents = "";
        brw.style.pointerEvents = "";
        searchcontainer.style.pointerEvents = "";
}
function fun10() {
    const line1 = document.getElementsByClassName("line1")[0];
    const line3 = document.getElementsByClassName("line3")[0];
    const curr = document.getElementById("curr");
    const landr = document.getElementById("landr");
    const langdivcont = document.getElementById("langdivcont");
    const hi1 = document.getElementById("hi1");
    const currencydata1 = document.getElementById("currencydata1");
    line3.style.width = "";
    line3.style.height = "0.01rem";
    line1.style.width = "9.5rem";
    line1.style.height = "0.2rem";
    line1.style.backgroundColor = "black";
    line3.style.backgroundColor = "rgb(229, 229, 229)";
    curr.style.color = "rgb(160, 160, 160)";
    curr.style.fontWeight = "";
    landr.style.color = "black";
    landr.style.fontWeight = "500";
    hi1.style.display = "block";
    currencydata1.style.display = "none";
    langdivcont.style.overflowX = "hidden";
    langdivcont.style.overflowY = "scroll";
}
function fun11() {
    const line1 = document.getElementsByClassName("line1")[0];
    const line3 = document.getElementsByClassName("line3")[0];
    const curr = document.getElementById("curr");
    const landr = document.getElementById("landr");
    const hi1 = document.getElementById("hi1");
    const currencydata1 = document.getElementById("currencydata1");
    const langdivcont = document.getElementById("langdivcont");
    line1.style.backgroundColor = "rgb(229, 229, 229)";
    line1.style.width = "";
    line1.style.height = "0.01rem";
    line3.style.backgroundColor = "black";
    line3.style.width = "3.7rem";
    line3.style.height = "0.2rem";
    curr.style.color = "black";
    curr.style.fontWeight = "500";
    landr.style.color = "rgb(160, 160, 160)";
    hi1.style.display = "none";
    currencydata1.style.display = "block";
    langdivcont.style.height = "60rem";
    langdivcont.style.overflowY = "hidden";
    langdivcont.style.overflowX = "hidden";
}
function fun12() {
    const t3 = document.getElementById("t3");
    t3.style.marginLeft = "-20%";
}

function fun13() {
    const langdivcont = document.getElementById("langdivcont");
    const colorchanges = document.getElementById("colorchanges");
    const pElements = document.querySelectorAll(".p img");
    const dbimg = document.getElementById("dbimg");
    const imagedesElements = document.querySelectorAll("#textcolorchange");
    const container2 = document.getElementById("container2");
    const loginicon = document.getElementsByClassName("loginicon")[0];
    const u1 = document.getElementById("u1");
    const sc1 = document.getElementById("sc1");
    const sc4 = document.getElementById("sc4");
    const u = document.getElementById("u");
    const f1 = document.getElementById("f1");
    const f2 = document.getElementById("f2");
    const f3 = document.getElementById("f3");
    const v1 = document.getElementsByClassName("v1")[0];
    const v2 = document.getElementsByClassName("v2")[0];
    const v4 = document.getElementsByClassName("v4")[0];
    const grayfooter = document.getElementsByClassName("grayfooter")[0];
    const colourchange2 = document.getElementById("colourchange2");
    const colourchange3 = document.getElementById("colourchange3");
    const colourchange4 = document.getElementById("colourchange4");
    const colourchange5 = document.getElementById("colourchange5");
    const colourchange6 = document.getElementById("colourchange6");
    const colourchange7 = document.getElementById("colourchange7");
    const colourchange = document.getElementById("colourchange");
    const fetchdataElements = document.querySelectorAll(".table .fetchdata");
    const kElements = document.querySelectorAll("#k");
    const zElements = document.querySelectorAll("#z");
    const last1 = document.getElementsByClassName("last1")[0];
    const last2 = document.getElementsByClassName("last2")[0];
    const airbnb = document.getElementsByClassName("airbnb")[0];
    const brw = document.getElementsByClassName("brw")[0];
    const searchcontainer = document.getElementsByClassName("searchcontainer")[0];
    langdivcont.style.display = "block";
    colorchanges.style.backgroundColor = "rgb(122, 122, 122)";
    colorchanges.style.overflow = "hidden";
    dbimg.style.backgroundColor = "rgb(122, 122, 122)";
    container2.style.backgroundColor = "rgb(122, 122, 122)";
    loginicon.style.filter = "brightness(0.5)";
    loginicon.style.border = "2px solid rgb(88, 85, 85)";
    loginicon.style.pointerEvents = "none";
    airbnb.style.pointerEvents = "none";
    brw.style.pointerEvents = "none";
    searchcontainer.style.pointerEvents = "none";
    loginicon.style.boxShadow = "none";
    u1.style.backgroundColor = "rgb(125, 117, 117)";
    u1.style.border = "2px solid rgb(105, 100, 100)";
    u1.style.boxShadow = "none";
    sc1.style.backgroundColor = "rgb(122, 122, 122)";
    sc4.style.backgroundColor = "rgb(122, 122, 122)";
    u.style.backgroundColor = "rgb(122, 122, 122)";
    u.classList.add("inputclass");
    f1.style.backgroundColor = "rgb(122, 122, 122)";
    f1.classList.add("inputclass");
    f2.style.backgroundColor = "rgb(122, 122, 122)";
    f2.classList.add("inputclass");
    v1.style.borderLeft = " 2px solid rgb(88, 85, 85)";
    v2.style.borderLeft = " 2px solid rgb(88, 85,   85)";
    v4.style.borderLeft = " 2px solid rgb(88, 85, 85)";
    f3.style.backgroundColor = "rgb(122, 122, 122)";
    f3.classList.add("inputclass");
    grayfooter.style.backgroundColor = "rgb(122, 122, 122)";
    colourchange2.style.color = "rgb(88, 85, 85)";
    colourchange3.style.color = "rgb(88, 85, 85)";
    colourchange4.style.color = "rgb(88, 85, 85)";
    colourchange5.style.color = "rgb(88, 85, 85)";
    colourchange6.style.color = "rgb(88, 85, 85)";
    colourchange7.style.color = "rgb(88, 85, 85)";
    colourchange.style.color = "rgb(88, 85, 85)";
    last1.style.backgroundColor = "rgb(122, 122, 122)";
    last2.style.backgroundColor = "rgb(122, 122, 122)";
    pElements.forEach(img => {
        img.style.filter = "brightness(0.5)";
    });
    fetchdataElements.forEach(fetchdata => {
        fetchdata.style.backgroundColor = "rgb(122, 122, 122)";
    });
    kElements.forEach(k => {
        k.style.backgroundColor = "rgb(122, 122, 122)";
    });
    zElements.forEach(z => {
        z.style.backgroundColor = "rgb(122, 122, 122)";
        z.style.color = "rgb(88, 85, 85)";
    });
    imagedesElements.forEach(imagedes => {
        imagedes.style.color = "rgb(67, 65, 65)";
    })
    langdivcont.classList.add("show");
    langdivcont.classList.remove("hide");
}

function closeLanguageDiv(event) {
    const langdivcont = document.getElementById("langdivcont");
    const pElements = document.querySelectorAll(".p img");
    const dbimg = document.getElementById("dbimg");
    const colorchanges = document.getElementById("colorchanges");
    const imagedes = document.getElementsByClassName("imagedes")[0];
    const container2 = document.getElementById("container2");
    const loginicon = document.getElementsByClassName("loginicon")[0];
    const airbnb = document.getElementsByClassName("airbnb")[0];
    const brw = document.getElementsByClassName("brw")[0];
    const grayfooter=document.getElementsByClassName("grayfooter")[0];
    const searchcontainer = document.getElementsByClassName("searchcontainer")[0];
    const u1 = document.getElementById("u1");
    const sc1 = document.getElementById("sc1");
    const sc4 = document.getElementById("sc4");
    const u = document.getElementById("u");
    const f1 = document.getElementById("f1");
    const f2 = document.getElementById("f2");
    const f3 = document.getElementById("f3");
    const v1 = document.getElementsByClassName("v1")[0];
    const v2 = document.getElementsByClassName("v2")[0];
    const v4 = document.getElementsByClassName("v4")[0];
    if (!langdivcont.contains(event.target)) {
        langdivcont.classList.remove("show");
        langdivcont.classList.add("hide");
        pElements.forEach(img => {
            img.style.filter = "none";

        });
        grayfooter.style.backgroundColor="";
        colorchanges.style.backgroundColor = "";
        colorchanges.style.overflow = "";
        dbimg.style.backgroundColor = "";
        container2.style.backgroundColor = "";
        loginicon.style.filter = "none";
        imagedes.style.color = "";
        u1.style.backgroundColor = "";
        u1.style.border = "";
        u1.style.boxShadow = "";
        sc1.style.backgroundColor = "";
        sc4.style.backgroundColor = "";
        u.style.backgroundColor = "";
        f1.style.backgroundColor = "";
        f2.style.backgroundColor = "";
        f3.style.backgroundColor = "";
        v1.style.borderLeft = "";
        v2.style.borderLeft = "";
        v4.style.borderLeft = "";
        loginicon.style.border = "";
        loginicon.style.pointerEvents = "";
        airbnb.style.pointerEvents = "";
        brw.style.pointerEvents = "";
        searchcontainer.style.pointerEvents = "";
    }
}

const browser = document.getElementsByClassName("browser")[0];
browser.addEventListener('click', (event) => {
    fun13();
    event.stopPropagation();
});

document.body.addEventListener('click', closeLanguageDiv);

const langdivcont = document.getElementById("langdivcont");
langdivcont.addEventListener('click', (event) => {
    event.stopPropagation();
});
document.addEventListener('DOMContentLoaded', function () {
    function fun13() {
        const langdivcont = document.getElementById("langdivcont");
        const colorchanges = document.getElementById("colorchanges");
        const pElements = document.querySelectorAll(".p img");
        const dbimg = document.getElementById("dbimg");
        const imagedesElements = document.querySelectorAll("#textcolorchange");
        const container2 = document.getElementById("container2");
        const loginicon = document.getElementsByClassName("loginicon")[0];
        const u1 = document.getElementById("u1");
        const sc1 = document.getElementById("sc1");
        const sc4 = document.getElementById("sc4");
        const u = document.getElementById("u");
        const f1 = document.getElementById("f1");
        const f2 = document.getElementById("f2");
        const f3 = document.getElementById("f3");
        const v1 = document.getElementsByClassName("v1")[0];
        const v2 = document.getElementsByClassName("v2")[0];
        const v4 = document.getElementsByClassName("v4")[0];
        const grayfooter = document.getElementsByClassName("grayfooter")[0];
        const colourchange2 = document.getElementById("colourchange2");
        const colourchange3 = document.getElementById("colourchange3");
        const colourchange4 = document.getElementById("colourchange4");
        const colourchange5 = document.getElementById("colourchange5");
        const colourchange6 = document.getElementById("colourchange6");
        const colourchange7 = document.getElementById("colourchange7");
        const colourchange = document.getElementById("colourchange");
        const fetchdataElements = document.querySelectorAll(".table .fetchdata");
        const kElements = document.querySelectorAll("#k");
        const zElements = document.querySelectorAll("#z");
        const last1 = document.getElementsByClassName("last1")[0];
        const last2 = document.getElementsByClassName("last2")[0];
        const airbnb = document.getElementsByClassName("airbnb")[0];
        const brw = document.getElementsByClassName("brw")[0];
        const searchcontainer = document.getElementsByClassName("searchcontainer")[0];
        langdivcont.style.display = "block";
        colorchanges.style.backgroundColor = "rgb(122, 122, 122)";
        colorchanges.style.overflow = "hidden";
        dbimg.style.backgroundColor = "rgb(122, 122, 122)";
        container2.style.backgroundColor = "rgb(122, 122, 122)";
        loginicon.style.filter = "brightness(0.5)";
        loginicon.style.border = "2px solid rgb(88, 85, 85)";
        loginicon.style.boxShadow = "none";
        loginicon.style.pointerEvents = "none";
        airbnb.style.pointerEvents = "none";
        brw.style.pointerEvents = "none";
        searchcontainer.style.pointerEvents = "none";
        u1.style.backgroundColor = "rgb(125, 117, 117)";
        u1.style.border = "2px solid rgb(105, 100, 100)";
        u1.style.boxShadow = "none";
        sc1.style.backgroundColor = "rgb(122, 122, 122)";
        sc4.style.backgroundColor = "rgb(122, 122, 122)";
        u.style.backgroundColor = "rgb(122, 122, 122)";
        u.classList.add("inputclass");
        f1.style.backgroundColor = "rgb(122, 122, 122)";
        f1.classList.add("inputclass");
        f2.style.backgroundColor = "rgb(122, 122, 122)";
        f2.classList.add("inputclass");
        f3.style.backgroundColor = "rgb(122, 122, 122)";
        f3.classList.add("inputclass");
        v1.style.borderLeft = " 2px solid rgb(88, 85, 85)";
        v2.style.borderLeft = " 2px solid rgb(88, 85, 85)";
        v4.style.borderLeft = " 2px solid rgb(88, 85, 85)";
        grayfooter.style.backgroundColor = "rgb(122, 122, 122)";
        last1.style.backgroundColor = "rgb(122, 122, 122)";
        last2.style.backgroundColor = "rgb(122, 122, 122)";
        colourchange2.style.color = "rgb(88, 85, 85)";
        colourchange3.style.color = "rgb(88, 85, 85)";
        colourchange4.style.color = "rgb(88, 85, 85)";
        colourchange5.style.color = "rgb(88, 85, 85)";
        colourchange6.style.color = "rgb(88, 85, 85)";
        colourchange7.style.color = "rgb(88, 85, 85)";
        colourchange.style.color = "rgb(88, 85, 85)";
        pElements.forEach(img => {
            img.style.filter = "brightness(0.5)";
        });
        fetchdataElements.forEach(fetchdata => {
            fetchdata.style.backgroundColor = "rgb(122, 122, 122)";
        });
        kElements.forEach(k => {
            k.style.backgroundColor = "rgb(122, 122, 122)";
        });
        zElements.forEach(z => {
            z.style.backgroundColor = "rgb(122, 122, 122)";
            z.style.color = "rgb(88, 85, 85)";
        });
        imagedesElements.forEach(imagedes => {
            imagedes.style.color = "rgb(67, 65, 65)";
        })
        langdivcont.classList.add("show");
        langdivcont.classList.remove("hide");
    }
    function closeLanguageDiv(event) {
        const langdivcont = document.getElementById("langdivcont");
        const pElements = document.querySelectorAll(".p img");
        const dbimg = document.getElementById("dbimg");
        const colorchanges = document.getElementById("colorchanges");
        const imagedes = document.getElementsByClassName("imagedes")[0];
        const container2 = document.getElementById("container2");
        const loginicon = document.getElementsByClassName("loginicon")[0];
        const airbnb = document.getElementsByClassName("airbnb")[0];
        const brw = document.getElementsByClassName("brw")[0];
        const searchcontainer = document.getElementsByClassName("searchcontainer")[0];
        const u1 = document.getElementById("u1");
        const sc1 = document.getElementById("sc1");
        const sc4 = document.getElementById("sc4");
        const u = document.getElementById("u");
        const f1 = document.getElementById("f1");
        const f2 = document.getElementById("f2");
        const f3 = document.getElementById("f3");
        const v1 = document.getElementsByClassName("v1")[0];
        const grayfooter=document.getElementsByClassName("grayfooter")[0];
        const v2 = document.getElementsByClassName("v2")[0];
        const v4 = document.getElementsByClassName("v4")[0];
        if (!langdivcont.contains(event.target)) {
            langdivcont.classList.remove("show");
            langdivcont.classList.add("hide");
            pElements.forEach(img => {
                img.style.filter = "none";
            });
            grayfooter.style.backgroundColor="";
            colorchanges.style.backgroundColor = "";
            colorchanges.style.overflow = "";
            dbimg.style.backgroundColor = "";
            container2.style.backgroundColor = "";
            loginicon.style.filter = "none";
            loginicon.style.pointerEvents = "";
            airbnb.style.pointerEvents = "";
            brw.style.pointerEvents = "";
            searchcontainer.style.pointerEvents = "";
            loginicon.style.border = "";
            imagedes.style.color = "";
            u1.style.backgroundColor = "";
            u1.style.border = "";
            u1.style.boxShadow = "";
            sc1.style.backgroundColor = "";
            sc4.style.backgroundColor = "";
            u.style.backgroundColor = "";
            f1.style.backgroundColor = "";
            f2.style.backgroundColor = "";
            f3.style.backgroundColor = "";
            v1.style.borderLeft = "";
            v2.style.borderLeft = "";
            v4.style.borderLeft = "";
        }
    }
    const browser = document.getElementsByClassName("browser")[0];
    browser.addEventListener('click', (event) => {
        fun13();
        event.stopPropagation();
    });
    document.addEventListener('click', closeLanguageDiv);
    const langdivcont = document.getElementById("langdivcont");
    langdivcont.addEventListener('click', (event) => {
        event.stopPropagation();
    });
});
function hidedisplay() {
    const loginsignupdiv = document.getElementById("loginsignupdiv");
    const colorchanges = document.getElementById("colorchanges");
    const container2 = document.getElementById("container2");
    const sc4 = document.getElementById("sc4");
    const u = document.getElementById("u");
    const f1 = document.getElementById("f1");
    const f2 = document.getElementById("f2");
    const grayfooter = document.getElementsByClassName("grayfooter")[0];
    const pElements = document.querySelectorAll(".p img");
    const dbimg = document.getElementById("dbimg");
    const imagedes = document.getElementsByClassName("imagedes")[0];
    const loginicon = document.getElementsByClassName("loginicon")[0];
    const u1 = document.getElementById("u1");
    const sc1 = document.getElementById("sc1");
    const f3 = document.getElementById("f3");
    const v1 = document.getElementsByClassName("v1")[0];
    const v2 = document.getElementsByClassName("v2")[0];
    const v4 = document.getElementsByClassName("v4")[0];
    const kElements = document.querySelectorAll("#k");
    const zElements = document.querySelectorAll("#z");
    const last1 = document.getElementsByClassName("last1")[0];
    const last2 = document.getElementsByClassName("last2")[0];
    const fetchdataElements = document.querySelectorAll(".table .fetchdata");
    const imagedesElements = document.querySelectorAll("#textcolorchange");
    const airbnb = document.getElementsByClassName("airbnb")[0];
    const brw = document.getElementsByClassName("brw")[0];
    const searchcontainer = document.getElementsByClassName("searchcontainer")[0];
    const emailcontent = document.getElementsByClassName("emailcontent")[0];
    const hidediv = document.getElementById("hidediv");
    const pack1 = document.getElementsByClassName("pack1")[0];
    loginsignupdiv.style.width = "35rem";
    loginsignupdiv.style.height = "51rem";
    emailcontent.style.display = "block";
    hidediv.style.display = "block";
    pack1.style.display = "block";
    document.querySelector('#fbsection').style.display = "block";
    document.querySelector('#fbsection').style.display = "flex";
    document.querySelector('#googlesection').style.display = "block";
    document.querySelector('#googlesection').style.display = "flex";
    document.querySelector('#applesection').style.display = "block";
    document.querySelector('#applesection').style.display = "flex";
    document.querySelector('#p22').style.display = "block";
    document.querySelector('#p22').style.display = "flex";
    document.querySelector('.registration-form-container').style.display = "none";
    document.querySelector('.passwordfield').style.display = "block";
    container2.classList.remove("class5");
    u.classList.remove("class4");
    f1.classList.remove("class4");
    f2.classList.remove("class4");
    sc4.classList.remove("class5");
    if (colorchanges) {
        colorchanges.classList.remove("class4");
        colorchanges.classList.remove("class3");
    }
    grayfooter.style.filter = "";
    loginsignupdiv.style.display = "none";
    loginsignupdiv.classList.remove("show1");
    loginsignupdiv.classList.add("hide1");
    loginsignupdiv.classList.add("loginsignupcontainer");
    colorchanges.style.backgroundColor = "";
    colorchanges.style.overflow = "";
    dbimg.style.backgroundColor = "";
    container2.style.backgroundColor = "";
    loginicon.style.backgroundColor = "";
    loginicon.style.border = "";
    imagedes.style.color = "";
    u1.style.backgroundColor = "";
    u1.style.border = "";
    u1.style.boxShadow = "";
    sc1.style.backgroundColor = "";
    sc4.style.backgroundColor = "";
    u.style.backgroundColor = "";
    f1.style.backgroundColor = "";
    f2.style.backgroundColor = "";
    f3.style.backgroundColor = "";
    v1.style.borderLeft = "";
    v2.style.borderLeft = "";
    v4.style.borderLeft = "";
    grayfooter.style.backgroundColor = "";
    last1.style.backgroundColor = "";
    last2.style.backgroundColor = "";
    loginicon.style.filter = "";
    loginicon.style.pointerEvents = "";
    airbnb.style.pointerEvents = "";
    brw.style.pointerEvents = "";
    searchcontainer.style.pointerEvents = "";
    pElements.forEach(img => {
        img.style.filter = "none";
    });
    kElements.forEach(k => {
        k.style.backgroundColor = "";
    });
    zElements.forEach(z => {
        z.style.backgroundColor = "";
        z.style.color = "";
    });
    imagedesElements.forEach(imagedes => {
        imagedes.style.color = "";
    });
    fetchdataElements.forEach(fetchdata => {
        fetchdata.style.backgroundColor = "";
    });
}

function fun17() {
    const emailshow = document.getElementsByClassName("emailshow")[0];
    const emailcontent = document.getElementsByClassName("emailcontent")[0];
    const showemailtext = document.getElementsByClassName("showemailtext")[0];
    const error2 = document.getElementsByClassName("error2")[0];
    const hidediv = document.getElementById("hidediv");
    const emailerror = document.getElementsByClassName("emailerror")[0];
    emailshow.style.display = "block";
    error2.style.display = "none";
    showemailtext.style.display = "none";
    loginsignupdiv.style.height = "50rem";
    hidediv.style.display = "block";
    emailcontent.style.border = "2px solid black";
    document.body.addEventListener("click", (event) => {
        if (!emailcontent.contains(event.target) || !hidediv.contains(event.target)) {
            emailcontent.style.border = "2px solid black";
            emailerror.style.display = "none";
        }
    })
}
function fun18() {
    const showemailtext = document.getElementsByClassName("showemailtext")[0];
    const emailshow = document.getElementsByClassName("emailshow")[0];
    emailshow.style.display = "none";
    showemailtext.style.display = "block";
    document.addEventListener('click', previous);
}
function previous(event) {
    const emailcontent = document.getElementsByClassName("emailcontent")[0];
    const emailshow = document.getElementsByClassName("emailshow")[0];
    const showemailtext = document.getElementsByClassName("showemailtext")[0];
    if (!emailcontent.contains(event.target)) {
        emailshow.style.display = "block";
        showemailtext.style.display = "none";
    }
}
function fun20() {
    const loginsignupdiv = document.getElementById("loginsignupdiv");
    const colorchanges = document.getElementById("colorchanges");
    const pElements = document.querySelectorAll(".p img");
    const dbimg = document.getElementById("dbimg");
    const imagedesElements = document.querySelectorAll("#textcolorchange");
    const container2 = document.getElementById("container2");
    const loginicon = document.getElementsByClassName("loginicon")[0];
    const u1 = document.getElementById("u1");
    const sc1 = document.getElementById("sc1");
    const sc4 = document.getElementById("sc4");
    const u = document.getElementById("u");
    const f1 = document.getElementById("f1");
    const f2 = document.getElementById("f2");
    const f3 = document.getElementById("f3");
    const v1 = document.getElementsByClassName("v1")[0];
    const v2 = document.getElementsByClassName("v2")[0];
    const v4 = document.getElementsByClassName("v4")[0];
    const grayfooter = document.getElementsByClassName("grayfooter")[0];
    const colourchange2 = document.getElementById("colourchange2");
    const colourchange3 = document.getElementById("colourchange3");
    const colourchange4 = document.getElementById("colourchange4");
    const colourchange5 = document.getElementById("colourchange5");
    const colourchange6 = document.getElementById("colourchange6");
    const colourchange7 = document.getElementById("colourchange7");
    const colourchange = document.getElementById("colourchange");
    const fetchdataElements = document.querySelectorAll(".table .fetchdata");
    const kElements = document.querySelectorAll("#k");
    const zElements = document.querySelectorAll("#z");
    const last1 = document.getElementsByClassName("last1")[0];
    const last2 = document.getElementsByClassName("last2")[0];
    const profilepopup = document.getElementById("profilepopup");
    const airbnb = document.getElementsByClassName("airbnb")[0];
    const emailcontent = document.getElementsByClassName("emailcontent")[0];
    const brw = document.getElementsByClassName("brw")[0];
    const hidediv = document.getElementById("hidediv");
    const searchcontainer = document.getElementsByClassName("searchcontainer")[0];
    const passwordfield = document.getElementsByClassName("passwordfield")[0];
    const pack1 = document.getElementsByClassName("pack1")[0];
    colorchanges.style.backgroundColor = "rgb(122, 122, 122)";
    profilepopup.style.display = "none";
    dbimg.style.backgroundColor = "rgb(122, 122, 122)";
    container2.style.backgroundColor = "rgb(122, 122, 122)";
    loginicon.style.pointerEvents = "none";
    airbnb.style.pointerEvents = "none";
    brw.style.pointerEvents = "none";
    searchcontainer.style.pointerEvents = "none";
    loginsignupdiv.style.display = "block";
    loginsignupdiv.style.opacity = "1";
    emailcontent.style.marginLeft = "1.6rem";
    loginsignupdiv.style.transition = "transform 0.5s ease-in-out";
    loginsignupdiv.style.transform = "translateY(0)";
    loginsignupdiv.style.animation = "SlideFromBottom 0.5s ease-in-out";
    loginsignupdiv.style.height = "50rem";
    hidediv.style.marginTop = "8rem";
    passwordfield.style.width = "30.7rem";
    loginicon.style.filter = "brightness(0.5)";
    loginicon.style.border = "2px solid rgb(88, 85, 85)";
    loginicon.style.boxShadow = "none";
    u1.style.backgroundColor = "rgb(125, 117, 117)";
    u1.style.border = "2px solid rgb(105, 100, 100)";
    u1.style.boxShadow = "none";
    sc1.style.backgroundColor = "rgb(122, 122, 122)";
    sc4.style.backgroundColor = "rgb(122, 122, 122)";
    u.style.backgroundColor = "rgb(122, 122, 122)";
    u.classList.add("inputclass");
    f1.style.backgroundColor = "rgb(122, 122, 122)";
    f1.classList.add("inputclass");
    f2.style.backgroundColor = "rgb(122, 122, 122)";
    f2.classList.add("inputclass");
    f3.style.backgroundColor = "rgb(122, 122, 122)";
    f3.classList.add("inputclass");
    v1.style.borderLeft = " 2px solid rgb(88, 85, 85)";
    v2.style.borderLeft = " 2px solid rgb(88, 85, 85)";
    v4.style.borderLeft = " 2px solid rgb(88, 85, 85)";
    grayfooter.style.backgroundColor = "rgb(122, 122, 122)";
    last1.style.backgroundColor = "rgb(122, 122, 122)";
    last2.style.backgroundColor = "rgb(122, 122, 122)";
    colourchange2.style.color = "rgb(88, 85, 85)";
    colourchange3.style.color = "rgb(88, 85, 85)";
    colourchange4.style.color = "rgb(88, 85, 85)";
    colourchange5.style.color = "rgb(88, 85, 85)";
    colourchange6.style.color = "rgb(88, 85, 85)";
    colourchange7.style.color = "rgb(88, 85, 85)";
    colourchange.style.color = "rgb(88, 85, 85)";
    pack1.style.display = "flex";
    pElements.forEach(img => {
        img.style.filter = "brightness(0.5)";
    });
    fetchdataElements.forEach(fetchdata => {
        fetchdata.style.backgroundColor = "rgb(122, 122, 122)";
    });
    kElements.forEach(k => {
        k.style.backgroundColor = "rgb(122, 122, 122)";
    });
    zElements.forEach(z => {
        z.style.backgroundColor = "rgb(122, 122, 122)";
        z.style.color = "rgb(88, 85, 85)";
    });
    imagedesElements.forEach(imagedes => {
        imagedes.style.color = "rgb(67, 65, 65)";
    })
    loginsignupdiv.classList.add("show1");
    loginsignupdiv.classList.remove("hide1");
}
function closeLanguageDiv(event) {
    const loginsignupdiv = document.getElementById("loginsignupdiv");
    const grayfooter = document.getElementsByClassName("grayfooter")[0];
    const pElements = document.querySelectorAll(".p img");
    const dbimg = document.getElementById("dbimg");
    const colorchanges = document.getElementById("colorchanges");
    const imagedes = document.getElementsByClassName("imagedes")[0];
    const container2 = document.getElementById("container2");
    const loginicon = document.getElementsByClassName("loginicon")[0];
    const u1 = document.getElementById("u1");
    const sc1 = document.getElementById("sc1");
    const sc4 = document.getElementById("sc4");
    const u = document.getElementById("u");
    const f1 = document.getElementById("f1");
    const f2 = document.getElementById("f2");
    const f3 = document.getElementById("f3");
    const v1 = document.getElementsByClassName("v1")[0];
    const v2 = document.getElementsByClassName("v2")[0];
    const v4 = document.getElementsByClassName("v4")[0];
    const kElements = document.querySelectorAll("#k");
    const zElements = document.querySelectorAll("#z");
    const last1 = document.getElementsByClassName("last1")[0];
    const last2 = document.getElementsByClassName("last2")[0];
    const fetchdataElements = document.querySelectorAll(".table .fetchdata");
    const imagedesElements = document.querySelectorAll("#textcolorchange");
    const airbnb = document.getElementsByClassName("airbnb")[0];
    const brw = document.getElementsByClassName("brw")[0];
    const searchcontainer = document.getElementsByClassName("searchcontainer")[0];
    const emailcontent = document.getElementsByClassName("emailcontent")[0];
    const hidediv = document.getElementById("hidediv");
    const pack1 = document.getElementsByClassName("pack1")[0];
    if (!loginsignupdiv.contains(event.target)) {
        loginsignupdiv.style.display = "none";
        loginsignupdiv.classList.remove("show1");
        loginsignupdiv.classList.add("hide1");
        loginsignupdiv.classList.add("loginsignupcontainer");
        colorchanges.style.backgroundColor = "";
        colorchanges.style.overflow = "";
        dbimg.style.backgroundColor = "";
        container2.style.backgroundColor = "";
        loginicon.style.backgroundColor = "";
        loginicon.style.border = "";
        imagedes.style.color = "";
        u1.style.backgroundColor = "";
        u1.style.border = "";
        u1.style.boxShadow = "";
        sc1.style.backgroundColor = "";
        sc4.style.backgroundColor = "";
        u.style.backgroundColor = "";
        f1.style.backgroundColor = "";
        f2.style.backgroundColor = "";
        f3.style.backgroundColor = "";
        v1.style.borderLeft = "";
        v2.style.borderLeft = "";
        v4.style.borderLeft = "";
        grayfooter.style.backgroundColor = "";
        last1.style.backgroundColor = "";
        last2.style.backgroundColor = "";
        loginicon.style.pointerEvents = "";
        airbnb.style.pointerEvents = "";
        brw.style.pointerEvents = "";
        searchcontainer.style.pointerEvents = "";
        pElements.forEach(img => {
            img.style.filter = "none";
        });
        kElements.forEach(k => {
            k.style.backgroundColor = "";
        });
        zElements.forEach(z => {
            z.style.backgroundColor = "";
            z.style.color = "";
        });
        imagedesElements.forEach(imagedes => {
            imagedes.style.color = "";
        });
        fetchdataElements.forEach(fetchdata => {
            fetchdata.style.backgroundColor = "";
        });
    }
    loginsignupdiv.style.width = "35rem";
    loginsignupdiv.style.height = "51rem";
    emailcontent.style.display = "block";
    hidediv.style.display = "block";
    pack1.style.display = "block";
    document.querySelector('#fbsection').style.display = "block";
    document.querySelector('#fbsection').style.display = "flex";
    document.querySelector('#googlesection').style.display = "block";
    document.querySelector('#googlesection').style.display = "flex";
    document.querySelector('#applesection').style.display = "block";
    document.querySelector('#applesection').style.display = "flex";
    document.querySelector('#p22').style.display = "block";
    document.querySelector('#p22').style.display = "flex";
    document.querySelector('.registration-form-container').style.display = "none";
    document.querySelector('.passwordfield').style.display = "block";
}

const show = document.getElementById("show");
const show2 = document.getElementById("show2");
show.addEventListener('click', (event) => {
    fun20();
    event.stopPropagation();
});
show2.addEventListener('click', (event) => {
    fun20();
    event.stopPropagation();
});
document.body.addEventListener('click', closeLanguageDiv);

const loginsignupdiv = document.getElementById("loginsignupdiv");
loginsignupdiv.addEventListener('click', (event) => {
    event.stopPropagation();
});
const searchdetails = [
    "Agartala,Tripura",
    "Agra,Uttar Pradesh",
    "Ahmedabad,Gujarat",
    "Aizwal,Mizoram",
    "Ajmer,Rajasthan",
    "Allahabad,Uttar Pradesh",
    "Alleppey,Kerala",
    "Alibagh,Maharashtra",
    "Almora,Uttaranchal",
    "Alsisar,Rajasthan",
    "Alwar,Rajasthan",
    "Ambala,Haryana",
    "Amla,Madhya Pradesh",
    "Amritsar,Punjab",
    "Anand,Gujarat",
    "Ankleshwar,Gujarat",
    "Ashtamudi,Kerala",
    "Auli,Himachal Pradesh",
    "Aurangabad,Maharashtra",
    "Bengaluru, India",
    "Nilgiris, India",
    "Kodaikanal, India",
    "Velloor, India",
    "Konavakorai, India",
    "Kodaikanal, India",
    "Kerala, India",
    "Mysore, India",
    "Coonoor, India",
    "Kotagiri, India",
    "Chennai, India",
    "Nadukani, India",
    "Sigiriya, Sri Lanka",
    "Varkala, India",
    "Kainakary South, India",
    "Mananthavady, India",
    "Kollam, India",
    "Kandy, Sri Lanka",
    "Nedumkandam, India",
    "Habarana, Sri Lanka",
    "Munroe Island, India",
    "Madikeri, India",
    "Kaup, India",
    "Kandy, Sri Lanka",
    "Vythiri, India",
    "Ernakulam, India",
    "Kottayam, India",
    "Ratnapura, Sri Lanka",
    "Siddapura, India"
];

// Function to create and append an <li> element to the list

function createListItem(text) {

    // Create the <li> element
    var li = document.createElement("li");
    li.classList.add("styleli");
    // Create the <a> element
    var a = document.createElement("a");
    var p = document.createElement("p");
    a.classList.add("removestyle");
    p.classList.add("pstyle")
    // Set the text content of the <a> element
    a.textContent = text;
    // Set the href attribute of the <a> element
    a.setAttribute("href", "#");
    // Set the onclick attribute of the <a> element to call populateInput function
    a.setAttribute("onclick", "populateInput(this)");
    // Append the <a> element to the <li> element
    li.appendChild(p);
    p.appendChild(a);
    // Append the <li> element to the list
    document.getElementById("myUL").appendChild(li);
}
function myFunction() {
    var input, filter, ul, li, a, i, txtValue;
    input = document.getElementById("u");
    filter = input.value.toUpperCase();
    ul = document.getElementById("myUL");
    li = ul.getElementsByTagName("li");
    for (i = 0; i < li.length; i++) {
        a = li[i].getElementsByTagName("a")[0];
        txtValue = a.textContent || a.innerText;
        if (txtValue.toUpperCase().indexOf(filter) > -1) {
            li[i].style.display = "";
        } else {
            li[i].style.display = "none";
        }
    }
}

// Function to populate the input field with the clicked item's text content
function populateInput(element) {
    var input = document.getElementById("u");
    input.value = element.textContent || element.innerText;
}


// Call createListItem function for each item in the array
searchdetails.forEach((text) => {
    createListItem(text);
});



function closedropdown() {
    const searchDropdown = document.getElementById("searchDropdown");
    const u = document.getElementById("u");
    document.body.addEventListener('click', (event) => {
        if (u.contains(event.target) || searchDropdown.contains(event.target)) {
            searchDropdown.style.display = "block";
        }
        else {
            searchDropdown.style.display = "none";
        }
    })
}
function fun23() {
    const loginsignupdiv = document.getElementById("loginsignupdiv");
    const colorchanges = document.getElementById("colorchanges");
    const container2 = document.getElementById("container2");
    const sc4 = document.getElementById("sc4");
    const u = document.getElementById("u");
    const f1 = document.getElementById("f1");
    const f2 = document.getElementById("f2");
    const grayfooter = document.getElementsByClassName("grayfooter")[0];
    const error2 = document.getElementsByClassName("error2")[0];
    const emailerror = document.getElementsByClassName("emailerror")[0];
    const emailcontent = document.getElementsByClassName("emailcontent")[0];
    const hidediv = document.getElementById("hidediv");
    const passwordfield = document.getElementsByClassName("passwordfield")[0];
    const pack1 = document.getElementsByClassName("pack1")[0];
    document.body.addEventListener('click', (event) => {
        const clickoutside = event.target.closest("#likebutton");
        if (!clickoutside) {
            loginsignupdiv.style.display = "none";
            container2.classList.remove("class5");
            u.classList.remove("class4");
            f1.classList.remove("class4");
            f2.classList.remove("class4");
            sc4.classList.remove("class5");
            if (colorchanges) {
                colorchanges.classList.remove("class4");
                colorchanges.classList.remove("class3");
            }
            grayfooter.style.filter = "";
            error2.style.display = "none";
            emailcontent.style.border = "2px solid black";
            emailerror.style.display = "none";
            loginsignupdiv.style.height = "50rem";
        }
        else {
            loginsignupdiv.style.display = "block";
            loginsignupdiv.style.opacity = 1;
            loginsignupdiv.style.width = "35rem";
            loginsignupdiv.style.height = "51rem";
            loginsignupdiv.style.backgroundColor = "white";
            loginsignupdiv.style.boxShadow = "-1px -1px 1px rgb(225, 225, 225)";
            loginsignupdiv.style.border = "1px solid rgb(225, 225, 225)";
            loginsignupdiv.style.borderRadius = "1rem";
            loginsignupdiv.style.position = "absolute";
            loginsignupdiv.style.overflow = "auto";
            loginsignupdiv.style.zIndex = "1";
            loginsignupdiv.style.top = "300rem";
            loginsignupdiv.style.transition = "transform 0.5s ease-in-out";
            loginsignupdiv.style.transform = "translateY(0)";
            loginsignupdiv.style.animation = "SlideFromBottom 0.5s ease-in-out";
            container2.classList.add("class5");
            emailcontent.style.marginLeft = "1rem";
            u.classList.add("class4");
            f1.classList.add("class4");
            f2.classList.add("class4");
            sc4.classList.add("class5");
            if (colorchanges) {
                colorchanges.classList.add("class4");
            }
            grayfooter.style.filter = "brightness(0.5)";
        }
        hidediv.style.marginTop = "8rem";
        passwordfield.style.width = "30.7rem";
        pack1.style.display = "flex";
    });
}
function removestyle(){
    const colorchanges = document.getElementById("colorchanges");
    const container2 = document.getElementById("container2");
    const u1 = document.getElementById("u1");
    const images = document.querySelectorAll('.p img');
    const dbimg = document.getElementById("dbimg");
    const sc1 = document.getElementById("sc1");
    const sc4 = document.getElementById("sc4");
    const f1 = document.getElementById("f1");
    const f2 = document.getElementById("f2");
    const f3 = document.getElementById("f3");
    const u = document.getElementById("u");
    const d1 = document.getElementById("d1");
    const d2 = document.getElementById("d2");
    const d3 = document.getElementById("d3");
    const fetchdataElements = document.querySelectorAll(".fetchdata");
    const kElements = document.querySelectorAll("#k");
    const ZElements = document.querySelectorAll("#z");
    const grayfooter = document.getElementsByClassName("grayfooter")[0];
    const last1 = document.getElementsByClassName("last1")[0];
    const last2 = document.getElementsByClassName("last2")[0];
    colorchanges.style.backgroundColor = "white";
    container2.style.backgroundColor = "";
    if(container2){
        container2.classList.remove("class5");
    }
    if(sc4){
        sc4.classList.remove("class5");
    }
    grayfooter.style.filter="";
    u1.style.backgroundColor = "";
    u1.style.border = "2px solid gainsboro";
    u1.style.boxShadow = "-1px -1px 13px 5px rgb(235, 234, 234)";
    d1.style.borderLeft = "2px solid rgb(198, 198, 198)";
    d2.style.borderLeft = "2px solid rgb(198, 198, 198)";
    d3.style.borderLeft = "2px solid rgb(198, 198, 198)";
    images.forEach((element) => {
        element.style.filter = "";
    })
    grayfooter.style.backgroundColor = "";
    fetchdataElements.forEach((element) => {
        element.style.backgroundColor = "";
    })
    kElements.forEach((element) => {
        element.style.backgroundColor = "";
    })
    ZElements.forEach((element) => {
        element.style.backgroundColor = "";
    })
    dbimg.style.backgroundColor = "white";
    sc1.style.backgroundColor = "white";
    f1.style.backgroundColor = "white";
    f2.style.backgroundColor = "white";
    sc4.style.backgroundColor = "white";
    last1.style.backgroundColor = "white";
    last2.style.backgroundColor = "white";
    u.style.backgroundColor = "white";
    f3.style.backgroundColor = "white";
}
function submit2(event) {
    event.preventDefault();
    const et = document.getElementById("et");
    const emailerror = document.getElementsByClassName("emailerror")[0];
    const emailcontent = document.getElementsByClassName("emailcontent")[0];
    const userlogo = document.getElementsByClassName("userlogo")[0];
    const loginsignupdiv = document.getElementById("loginsignupdiv");
    const emailinfoValue = document.getElementById("email-info");
    const pack1 = document.getElementsByClassName("pack1")[0];
    const pass = document.getElementById("pass");
    const Password = pass.value.trim();
    const RegistrationForm = document.getElementsByClassName("registration-form-container")[0];
    let regex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
    const inputValue = et.value.trim();
    const inputValueAsString = inputValue.toString()
    if (regex.test(inputValueAsString)) {
        emailerror.style.display = "none";
        const formData = {
            email: inputValue,
            password: Password,
        };
        fetch('/handlelogin', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(formData),
        })
            .then(response => response.json())
            .then(data => {
                if (data.message === "Success") {
                    alert("You are logged in Successfully");
                    document.querySelector('#loginsignupdiv').style.display = "none";
                    document.querySelector('.loginicon').style.display = "none";
                    let character = inputValue[0];
                    userlogo.innerText = character;
                    document.querySelector('.logincircle').style.display = "block";
                    removestyle();
                } else if (data.message === "Login Failed!") {
                    alert("Invalid Credentials!");
                }
                else if (data.message === "User not found") {
                    alert("Please Register");
                    document.querySelector('.registration-form-container').style.display = 'block';
                    emailinfoValue.value = inputValue;
                    document.querySelector('#hidediv').style.display = "none";
                    document.querySelector('.emailcontent').style.display = "none";
                    document.querySelector('.passwordfield').style.display = "none";
                    document.querySelector('#fbsection').style.display = "none";
                    document.querySelector('#googlesection').style.display = "none";
                    document.querySelector('#applesection').style.display = "none";
                    document.querySelector('#p22').style.display = "none";
                    loginsignupdiv.style.height = "96rem";
                    loginsignupdiv.style.width = "58rem";
                    loginsignupdiv.style.marginLeft = "63rem";
                    loginsignupdiv.style.overflow = "hidden";
                    RegistrationForm.style.marginTop = "-1rem";
                    RegistrationForm.style.marginLeft = "4rem";
                    pack1.style.display = "none";
                }
            })
            .catch((error) => {
                console.error('Error:', error);
            });
    }
    else {
        emailerror.style.display = "block";
        emailcontent.style.border = "2px solid red";
        emailerror.style.color = "red";
        emailerror.style.marginLeft = "5%";
        emailerror.innerHTML = "Please Enter Vaild Email address !";
    }
    if (et.value == "") {
        emailerror.style.display = "block";
        emailcontent.style.border = "2px solid red";
        emailerror.style.color = "red";
        emailerror.style.marginLeft = "5%";
        emailerror.innerHTML = "Email required !";
    }
}
const button = document.querySelector('.continuebutton')
button.addEventListener('mousemove', e => {
    const rect = button.getBoundingClientRect();
    const x = (e.clientX - rect.left) * 100 / button.clientWidth
    const y = (e.clientY - rect.top) * 100 / button.clientHeight
    button.style.setProperty('--mouse-x', x);
    button.style.setProperty('--mouse-y', y);
})

function submit5(event) {
    event.preventDefault();
    const captureemail = document.getElementById("email-info");
    const Firstname = document.getElementById("first-name");
    const Lastname = document.getElementById("last-name");
    const Dob = document.getElementById("date-of-birth");
    const pass2 = document.getElementById("pass2");
    const Password = pass2.value.trim();
    const inputValue = captureemail.value.trim();
    let userlogo = document.getElementsByClassName("userlogo")[0];
    const dateOfBirth = Dob.value;
    const age = calculateAge(dateOfBirth);
    if (age < 18) {
        alert("Age cannot be less than 18 years");
        return;
    }
    const formdata = {
        email: captureemail.value,
        password: Password,
        Firstname: Firstname.value,
        Lastname: Lastname.value,
        Dob: Dob.value,
    }
    fetch('/registeruserdetails', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(formdata)
    })
        .then(response => response.json())
        .then(data => {
            if (data.message === 'Details are already saved.Please login') {
                alert("Details already Saved Please Login")
            }
            else if (data.message === "Details saved Successfully") {
                alert("Details Successfully Saved");
                document.querySelector('.passwordfield').style.display = "none";
                document.querySelector('#googlesection').style.display = "none";
                document.querySelector('#applesection').style.display = "none";
                document.querySelector('#loginsignupdiv').style.display = "none";
                document.querySelector('.loginicon').style.display = "none";
                document.querySelector('.registration-form-container').style.display = "none";
                let character = inputValue[0];
                userlogo.innerText = character;
                document.querySelector('.logincircle').style.display = "block";
            removestyle()  
            }
            
        })
        .catch((err) => {
            console.error(err)
        })
};
function fun56() {
    const emailcontent = document.getElementsByClassName("emailcontent")[0];
    const passwordfield = document.getElementsByClassName("passwordfield")[0];
    const registrationForm = document.getElementsByClassName("registration-form-container")[0];
    const hidediv = document.getElementById("hidediv");
    const pack1 = document.getElementsByClassName("pack1")[0];
    const fbsection = document.getElementById("fbsection");
    const googlesection = document.getElementById("googlesection");
    const applesection = document.getElementById("applesection");
    const p22 = document.getElementById("p22");
    const loginsignupdiv = document.getElementById("loginsignupdiv");
    emailcontent.style.display = "block";
    passwordfield.style.display = "block";
    registrationForm.style.display = "none";
    hidediv.style.display = "block";
    pack1.style.display = "block";
    pack1.style.display = "flex";
    fbsection.style.display = "block";
    fbsection.style.display = "flex";
    googlesection.style.display = "block";
    googlesection.style.display = "flex";
    applesection.style.display = "block";
    applesection.style.display = "flex";
    p22.style.display = "block";
    p22.style.display = "flex";
    loginsignupdiv.style.width = "35rem";
    loginsignupdiv.style.height = "51rem";
}
function fun52() {
    const fname = document.getElementById("fname");
    const showinput1 = document.getElementById("first-name");
    const register1 = document.getElementById("register1");
    fname.style.fontSize = "1rem";
    fname.style.marginTop = "1rem";
    showinput1.style.display = "block";
    showinput1.style.marginTop = "1rem";
    showinput1.style.marginLeft = "1.1rem";
    register1.style.height = "7.6rem";
    register1.style.borderBottomLeftRadius = "0.7rem";
    register1.style.borderBottomRightRadius = "0.7rem";
}
function fun53() {
    const lname = document.getElementById("lname");
    const showinput2 = document.getElementById("last-name");
    const register2 = document.getElementById("register2");
    lname.style.fontSize = "1rem";
    lname.style.marginTop = "1rem";
    showinput2.style.display = "block";
    showinput2.style.position = "relative";
    showinput2.style.marginTop = "1rem";
    showinput2.style.marginLeft = "1.1rem";
    register2.style.height = "7.6rem";
    register2.style.borderBottomLeftRadius = "0.7rem";
    register2.style.borderBottomRightRadius = "0.7rem";
    register2.style.borderTopLeftRadius = "0.7rem";
    register2.style.borderTopRightRadius = "0.7rem";
}
function fun54() {
    const dob = document.getElementById("dob");
    const showinput3 = document.getElementById("date-of-birth");
    dob.style.fontSize = "1rem";
    dob.style.marginTop = "1rem";
    showinput3.style.display = "block";
}
function fun55() {
    const pass1 = document.getElementById("pass1");
    const showinput4 = document.getElementById("pass2");
    const register4 = document.getElementById("register4");
    pass1.style.fontSize = "1rem";
    pass1.style.marginTop = "1rem";
    showinput4.style.display = "block";
    register4.style.border = "2px solid black";
}
function calculateAge(dateOfBirth) {
    // Parse the date of birth string into a Date object
    const dob = new Date(dateOfBirth);

    // Get the current date
    const currentDate = new Date();

    // Calculate the difference in years
    let age = currentDate.getFullYear() - dob.getFullYear();

    // Adjust the age if the birthday hasn't occurred yet this year
    if (currentDate.getMonth() < dob.getMonth() ||
        (currentDate.getMonth() === dob.getMonth() && currentDate.getDate() < dob.getDate())) {
        age--;
    }
    return age;
}
function openlogout() {
    const container14 = document.getElementsByClassName("container14")[0];
    const logincircle = document.getElementsByClassName("logincircle")[0];
    container14.style.display = "block";
    document.body.addEventListener('click', (event) => {
        if (!logincircle.contains(event.target)) {
            container14.style.display = "none";
        }
    })
}
function showresults(event) {
    event.preventDefault();
    const u = document.getElementById("u").value;
    const f1 = document.getElementById("f1").value;
    const f2 = document.getElementById("f2").value;
    const f3 = document.getElementById("f3").value;
    if (u == "" || f1 == "" || f2 == "" || f3 == "") {
        alert("All fields are necessary!")
    }
    else {
        const formdata = {
            data1: u,
            data2:f1,
            data3:f2,
            data4:f3,
        }
        fetch('/userdata', {
            method: "post",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify(formdata),
        })
            .then(response =>
               { 
                if(response.redirected){
                    window.location.href=response.url;
                }
            })
            .then(data => {
                console.log(data)
            })
            .catch(error => console.error(error))
    }
}