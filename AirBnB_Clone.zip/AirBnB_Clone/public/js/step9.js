function nowchange() {
    const limit = document.getElementById("limit");
    const error = document.getElementsByClassName("error")[0];
    const section18 = document.getElementsByClassName("section18")[0];
    const section26 = document.getElementsByClassName("section26")[0];
    const dynamic = document.getElementsByClassName("dynamic")[0];
    const string = limit.value.trim();
    section18.style.display = "none";
    limit.style.border = "";
    limit.style.backgroundColor = "";
    error.innerText = "";
    if(string.length==0){
        dynamic.innerText=string.length;
        section26.style.backgroundColor="rgb(221, 221, 221)";
        section26.style.cursor="not-allowed";
        return;
    }
    if(string.length >500){
        section18.style.display = "block";
        limit.style.border = "3px solid red";
        error.innerText="The maximum number of characters allowed is 500.";
        dynamic.innerText=string.length;
    }  
    else{
        section26.style.backgroundColor="black";
        section26.style.cursor="pointer";
        dynamic.innerText=string.length;
    }
}
const limit = document.getElementById("limit");
limit.addEventListener('input', nowchange);
function nextbutton(event){
    event.preventDefault();
    const string = limit.value.trim();
    if(string.length===0 || string.length >500){
        return
    }
    else{
        fetch('/next5',{
            method:"get",
            headers:{
                "Content-Type":"application/json"
            }
        })
        .then(response=>{
            if(response.redirected){
                window.location.href=response.url;
            }
            else{
               throw new Error;
            }
        })
        .then(data=>console.log(data))
        .catch(error=>console.error(error));
    }
}
function backbutton(event){
    event.preventDefault();
    fetch('/back9',{
        method:"get",
        headers:{
            "Content-Type":"application/json"
        }
    })
    .then(response=>{
        if(response.redirected){
            window.location.href=response.url;
        }
        else{
           throw new Error;
        }
    })
    .then(data=>console.log(data))
    .catch(error=>console.error(error));
}
function nextbutton(event){
    event.preventDefault();
    fetch('/next6',{
        method:"get",
        headers:{
            "Content-Type":"application/json"
        }
    })
    .then(response=>{
        if(response.redirected){
            window.location.href=response.url;
        }
        else{
           throw new Error;
        }
    })
    .then(data=>console.log(data))
    .catch(error=>console.error(error));
}