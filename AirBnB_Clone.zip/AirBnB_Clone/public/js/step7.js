function display1(){
    const first=document.getElementById("first");
    first.style.backgroundColor="rgb(247, 247, 247)";
    first.style.border="4px solid black";
}
function display2(){
    const second=document.getElementById("second");
    second.style.backgroundColor="rgb(247, 247, 247)";
    second.style.border="4px solid black";
}
function display3(){
    const third=document.getElementById("third");
    third.style.backgroundColor="rgb(247, 247, 247)";
    third.style.border="4px solid black";
}
function display4(){
    const four=document.getElementById("four");
    four.style.backgroundColor="rgb(247, 247, 247)";
    four.style.border="4px solid black";
}
function display5(){
    const five=document.getElementById("five");
    five.style.backgroundColor="rgb(247, 247, 247)";
    five.style.border="4px solid black";
}
function display6(){
    const six=document.getElementById("six");
    six.style.backgroundColor="rgb(247, 247, 247)";
    six.style.border="4px solid black";
}
function display7(){
    const seven=document.getElementById("seven");
    seven.style.backgroundColor="rgb(247, 247, 247)";
    seven.style.border="4px solid black";
}
function display8(){
    const eight=document.getElementById("eight");
    eight.style.backgroundColor="rgb(247, 247, 247)";
    eight.style.border="4px solid black";
}
function display9(){
    const nine=document.getElementById("nine");
    nine.style.backgroundColor="rgb(247, 247, 247)";
    nine.style.border="4px solid black";
}
function display10(){
    const ten=document.getElementById("ten");
    ten.style.backgroundColor="rgb(247, 247, 247)";
    ten.style.border="4px solid black";
}
function display11(){
    const eleven=document.getElementById("eleven");
    eleven.style.backgroundColor="rgb(247, 247, 247)";
    eleven.style.border="4px solid black";
}
function display12(){
    const twelve=document.getElementById("twelve");
    twelve.style.backgroundColor="rgb(247, 247, 247)";
    twelve.style.border="4px solid black";
}
function display13(){
    const thirteen=document.getElementById("thirteen");
    thirteen.style.backgroundColor="rgb(247, 247, 247)";
    thirteen.style.border="4px solid black";
}
function display14(){
    const fourteen=document.getElementById("fourteen");
    fourteen.style.backgroundColor="rgb(247, 247, 247)";
    fourteen.style.border="4px solid black";
}
function display15(){
    const fiveteen=document.getElementById("fiveteen");
    fiveteen.style.backgroundColor="rgb(247, 247, 247)";
    fiveteen.style.border="4px solid black";
}
function display16(){
    const sixteen=document.getElementById("sixteen");
    sixteen.style.backgroundColor="rgb(247, 247, 247)";
    sixteen.style.border="4px solid black";
}
function display17(){
    const seventeen=document.getElementById("seventeen");
    seventeen.style.backgroundColor="rgb(247, 247, 247)";
    seventeen.style.border="4px solid black";
}
function display18(){
    const eighteen=document.getElementById("eighteen");
    eighteen.style.backgroundColor="rgb(247, 247, 247)";
    eighteen.style.border="4px solid black";
}
function display19(){
    const nineteen=document.getElementById("nineteen");
    nineteen.style.backgroundColor="rgb(247, 247, 247)";
    nineteen.style.border="4px solid black";
}
function display20(){
    const twenty=document.getElementById("twenty");
    twenty.style.backgroundColor="rgb(247, 247, 247)";
    twenty.style.border="4px solid black";
}
function display21(){
    const twentyone=document.getElementById("twentyone");
    twentyone.style.backgroundColor="rgb(247, 247, 247)";
    twentyone.style.border="4px solid black";
}
function display22(){
    const twentytwo=document.getElementById("twentytwo");
    twentytwo.style.backgroundColor="rgb(247, 247, 247)";
    twentytwo.style.border="4px solid black";
}
function display23(){
    const twentythree=document.getElementById("twentythree");
    twentythree.style.backgroundColor="rgb(247, 247, 247)";
    twentythree.style.border="4px solid black";
}
function display24(){
    const twentyfour=document.getElementById("twentyfour");
    twentyfour.style.backgroundColor="rgb(247, 247, 247)";
    twentyfour.style.border="4px solid black";
}
function display25(){
    const twentyfive=document.getElementById("twentyfive");
    twentyfive.style.backgroundColor="rgb(247, 247, 247)";
    twentyfive.style.border="4px solid black";
}
function display26(){
    const twentysix=document.getElementById("twentysix");
    twentysix.style.backgroundColor="rgb(247, 247, 247)";
    twentysix.style.border="4px solid black";
}
function backbutton(event){
    event.preventDefault();
    fetch('/back6',{
        method:"get",
        headers:{
            "Content-Type":"application/json"
        }
    })
    .then(response=>{
        if(response.redirected){
            window.location.href=response.url
        }
        else{
            throw new Error
        }
    })
    .then(data=>console.log(data)
    )
    .catch(error=>console.error(error))
}
function nextbutton(event){
    event.preventDefault();
    fetch('/next2',{
        method:"get",
        headers:{
            "Content-Type":"application/json"
        }
    })
    .then(response=>{
        if(response.redirected){
            window.location.href=response.url
        }
        else{
            throw new Error
        }
    })
    .then(data=>console.log(data)
    )
    .catch(error=>console.error(error))
}