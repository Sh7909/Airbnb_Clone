const searchdetails = [
    "Agartala,Tripura",
    "Agra,Uttar Pradesh",
    "Ahmedabad,Gujarat",
    "Aizwal,Mizoram",
    "Ajmer,Rajasthan",
    "Allahabad,Uttar Pradesh",
    "Alleppey,Kerala",
    "Alibagh,Maharashtra",
    "Almora,Uttaranchal",
    "Alsisar,Rajasthan",
    "Alwar,Rajasthan",
    "Ambala,Haryana",
    "Amla,Madhya Pradesh",
    "Amritsar,Punjab",
    "Anand,Gujarat",
    "Ankleshwar,Gujarat",
    "Ashtamudi,Kerala",
    "Auli,Himachal Pradesh",
    "Aurangabad,Maharashtra",
    "Bengaluru, India",
    "Nilgiris, India",
    "Kodaikanal, India",
    "Velloor, India",
    "Konavakorai, India",
    "Kodaikanal, India",
    "Kerala, India",
    "Mysore, India",
    "Coonoor, India",
    "Kotagiri, India",
    "Chennai, India",
    "Nadukani, India",
    "Sigiriya, Sri Lanka",
    "Varkala, India",
    "Kainakary South, India",
    "Mananthavady, India",
    "Kollam, India",
    "Kandy, Sri Lanka",
    "Nedumkandam, India",
    "Habarana, Sri Lanka",
    "Munroe Island, India",
    "Madikeri, India",
    "Kaup, India",
    "Kandy, Sri Lanka",
    "Vythiri, India",
    "Ernakulam, India",
    "Kottayam, India",
    "Ratnapura, Sri Lanka",
    "Siddapura, India"
];
// Function to create and append an <li> element to the list

function createListItem(text) {

    // Create the <li> element
    var li = document.createElement("li");
    li.classList.add("styleli");
    // Create the <a> element
    var a = document.createElement("a");
    var p = document.createElement("p");
    a.classList.add("removestyle");
    p.classList.add("pstyle")
    // Set the text content of the <a> element
    a.textContent = text;
    // Set the href attribute of the <a> element
    a.setAttribute("href", "#");
    // Set the onclick attribute of the <a> element to call populateInput function
    a.setAttribute("onclick", "populateInput(this)");
    // Append the <a> element to the <li> element
    li.appendChild(p);
    p.appendChild(a);
    // Append the <li> element to the list
    document.getElementById("myUL").appendChild(li);
}
function myFunction() {
    var input, filter, ul, li, a, i, txtValue;
    input = document.getElementById("u");
    filter = input.value.toUpperCase();
    ul = document.getElementById("myUL");
    li = ul.getElementsByTagName("li");
    for (i = 0; i < li.length; i++) {
        a = li[i].getElementsByTagName("a")[0];
        txtValue = a.textContent || a.innerText;
        if (txtValue.toUpperCase().indexOf(filter) > -1) {
            li[i].style.display = "";
        } else {
            li[i].style.display = "none";
        }
    }
}

// Function to populate the input field with the clicked item's text content
function populateInput(element) {
    var input = document.getElementById("u");
    input.value = element.textContent || element.innerText;
}
// Call createListItem function for each item in the array
searchdetails.forEach((text) => {
    createListItem(text);
});
function closedropdown() {
    const searchDropdown = document.getElementById("searchDropdown");
    const u = document.getElementById("u");
    const section37 = document.getElementsByClassName("section37")[0];
    document.body.addEventListener('click', (event) => {
        if (u.contains(event.target) || searchDropdown.contains(event.target)) {
            searchDropdown.style.display = "block";
        }
        else {
            searchDropdown.style.display = "none";
            searchDropdown.style.marginLeft = "3rem";
            if (u.value == "") {
                section37.style.cursor = "not-allowed";
                section37.style.backgroundColor = "rgb(221, 221, 221)"
            }
            else {
                section37.style.cursor = "pointer";
                section37.style.backgroundColor = "black";
            }
        }
    })
};
function back(event) {
    event.preventDefault();
    fetch('/back3', {
        method: "get",
        headers: {
            "Content-Type": "application/json"
        }
    })
        .then(response => {
            if (response.redirected) {
                window.location.href = response.url
            }
            else {
                throw new Error
            }
        })
        .then(data => console.log(data))
        .catch(error => console.error(error));
};
function nextbutton(event) {
    event.preventDefault();
    const section14=document.getElementsByClassName("section14")[0];
    const section17=document.getElementsByClassName("section17")[0];
    const section16one=document.getElementsByClassName("section16one")[0];
    const section37=document.getElementsByClassName("section37")[0];
    const section22=document.getElementsByClassName("section22")[0];
    const u=document.getElementById("u").value;
    const show7=document.getElementById("show7");
    const show8=document.getElementById("show8");
    if(section37.style.backgroundColor==="black"){
        section14.style.display="none";
        section16one.style.display="none";
        section17.style.display="none";
        section22.style.display="block";
        section22.style.marginTop="-8rem";
        var parts=u.split(',');
        show7.value=parts[0];
        show8.value=parts[1];
}}
function show1(){
    const first=document.getElementById("first");
    const show3=document.getElementById("show3");
    first.style.marginTop="0.5rem";
    first.style.height="2rem";
    first.style.fontSize="1.5rem";
    show3.style.display="block";
    show3.style.marginLeft="1.7rem";
    show3.style.height="3rem";
    show3.style.width="67rem";
}
function show2(){
    const second=document.getElementById("second");
    const show4=document.getElementById("show4");
    second.style.marginTop="0.5rem";
    second.style.height="2rem";
    second.style.fontSize="1.5rem";
    show4.style.display="block";
    show4.style.marginLeft="1.7rem";
    show4.style.height="3rem";
    show4.style.width="67rem";
}
function show3(){
    const third=document.getElementById("third");
    const show5=document.getElementById("show5");
    third.style.marginTop="0.5rem";
    third.style.height="2rem";
    third.style.fontSize="1.5rem";
    show5.style.display="block";
    show5.style.marginLeft="1.7rem";
    show5.style.height="3rem";
    show5.style.width="67rem";
}
function show4(){
    const seven=document.getElementById("seven");
    const show9=document.getElementById("show9");
    seven.style.marginTop="0.5rem";
    seven.style.height="2rem";
    seven.style.fontSize="1.5rem";
    show9.style.display="block";
    show9.style.marginLeft="1.7rem";
    show9.style.height="3rem";
    show9.style.width="67rem";
};
function back1(){
    const section14=document.getElementsByClassName("section14")[0];
    const section16one=document.getElementsByClassName("section16one")[0];
    const section17=document.getElementsByClassName("section17")[0];
    const section22=document.getElementsByClassName("section22")[0];
    section14.style.display="block";
    section16one.style.display="block";
    section17.style.display="block";
    section17.style.display="flex";
    section22.style.display="none";
}
function execute(event){
    event.preventDefault();
    const show3=document.getElementById("show3");
    const show4=document.getElementById("show4");
    const show5=document.getElementById("show5");
    const show6=document.getElementById("show6");
    const show7=document.getElementById("show7");
    const show8=document.getElementById("show8");
    const show9=document.getElementById("show9");
    if(show3.value!="" && show4.value!="" && show5.value!="" && show6.value!="" && show7.value!="" && show8.value!="" && show9.value!=""){        
        fetch('/nextfour',{
            method:'get',
            headers:{
                "Content-Type":"application/json"
            }
        })
        .then(response=>{
            if(response.redirected){
                window.location.href=response.url
            }
            else{
                throw new Error
            }
        })
        .then(data=>console.log(data))
        .catch(error=>console.error(error));
    }
    else{
        return
    }
}
 const section22=document.getElementsByClassName("section22")[0];
 section22.addEventListener("click",(event)=>{
    const show3=document.getElementById("show3");
    const show4=document.getElementById("show4");
    const show5=document.getElementById("show5");
    const show6=document.getElementById("show6");
    const show7=document.getElementById("show7");
    const show8=document.getElementById("show8");
    const show9=document.getElementById("show9");
    const section26=document.getElementsByClassName("section26")[0];
    if(show3.value!="" && show4.value!="" && show5.value!="" && show6.value!="" && show7.value!="" && show8.value!="" && show9.value!=""){
        section26.style.backgroundColor="black";
        section26.style.cursor="pointer";
    }
    else{
        section26.style.backgroundColor="rgb(221, 221, 221)";
        section26.style.cursor="not-allowed";
    }
 })