window.onload = function () {
    const params = new URLSearchParams(window.location.search);
    const basicprice = params.get('basicprice');
    document.getElementById('displayPrice').value = basicprice; 
}
function exec(){
    const five=document.getElementById("five");
    five.innerText="";
}
function nextbutton(event) {
    event.preventDefault();
    const first = document.getElementById("first").value;
    const second = document.getElementById("second").value;
    const secondone = document.getElementById("secondone").value;
    const third = document.getElementById("third").value;
    const thirdone = document.getElementById("thirdone").value;
    const displayPrice = document.getElementById("displayPrice").value;
    const five = document.getElementById("five").value;
    const section26 = document.getElementsByClassName("section26")[0];
    
    // Validate form fields
    if (first === "" || second === "" || secondone === "" || third === "" || four === "" || five === "") {
        alert("Please Fill all the details");
        return;
    }
    
    // Change button style
    section26.style.backgroundColor = "black";
    section26.style.cursor = "pointer";
    
    // Prepare form data
    const formData = {
        firstInputData: first,
        SecondInputData: second,
        SecondoneInputData: secondone,
        ThirdInputData: third,
        ThirdOneInputData:thirdone,
        FourInputData: displayPrice,
        FifthInputData: five,
    };
    
    // Send data to server
    fetch('/finalsubmission', {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify(formData),
    })
    .then(response => response.json())  // Parse the response as JSON
    .then(data => {
        console.log(data);
        if (data.message) {  // Check for the property your server returns
            // Construct URL with query parameters (if needed)
            const queryString = new URLSearchParams({
                firstInputData: first,
                SecondInputData: second,
                SecondoneInputData: secondone,
                ThirdInputData: third,
                ThirdOneInputData: thirdone,
                FourInputData: four,
                FifthInputData: five
            }).toString();
            
            // Redirect to new URL
            window.location.href = `/?${queryString}`;
        } else {
            console.error('Unexpected response format:', data);
        }
    })
    .catch(error => console.error('Error:', error));
}