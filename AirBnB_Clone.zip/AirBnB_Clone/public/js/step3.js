let selectedValue = '';

function selectPlace(id) {
    const first = document.getElementById("first");
    const second = document.getElementById("second");
    const third = document.getElementById("third");

    // Reset styles
    first.style.border = "2px solid rgb(221, 221, 221)";
    first.style.backgroundColor = "";
    second.style.border = "2px solid rgb(221, 221, 221)";
    second.style.backgroundColor = "";
    third.style.border = "2px solid rgb(221, 221, 221)";
    third.style.backgroundColor = "";

    // Apply styles to selected
    if (id === 'first') {
        first.style.border = "4px solid black";
        first.style.backgroundColor = "rgb(247, 247, 247)";
        selectedValue = first.innerText;
    } else if (id === 'second') {
        second.style.border = "4px solid black";
        second.style.backgroundColor = "rgb(247, 247, 247)";
        selectedValue = second.innerText;
    } else if (id === 'third') {
        third.style.border = "4px solid black";
        third.style.backgroundColor = "rgb(247, 247, 247)";
        selectedValue = third.innerText;
    }
}

function back(event){
    event.preventDefault();
        fetch('/back2',{
            method:"get",
            headers:{
                "Content-Type":"application/json"
            }
        })
        .then(response=>{
            if(response.redirected){
                window.location.href=response.url;
            }
            else{
                throw new Error
            }
        })
        .then(data=>console.log(data))
        .catch(error=>console.log(error));
    }
    function next(event) {
        event.preventDefault();
        fetch('/nextthree', {
            method: 'POST', 
            headers: {
                'Content-Type': 'application/json',
            },
        })
        .then(response => {
            if(response.redirected){
                window.location.href=response.url;
            }
            else{
                throw new Error;
            }
        })
        .catch(error => {
            console.log(error);
        });
    }
    