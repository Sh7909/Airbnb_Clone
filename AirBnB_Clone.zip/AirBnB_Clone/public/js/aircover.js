function openlogout() {
    const container14 = document.getElementsByClassName("container14")[0];
    const logincircle = document.getElementsByClassName("logincircle")[0];
    container14.style.display = "block";
    container14.style.marginLeft = "-7rem";
    container14.style.marginTop = "11.5rem";
    container14.style.textAlign = "center";
    document.body.addEventListener('click', (event) => {
        if (!logincircle.contains(event.target)) {
            container14.style.display = "none";
        }
    })
}
function showlogin() {
    const loginsignupdiv = document.getElementById("loginsignupdiv");
    const img2 = document.getElementById("img2");
    const host19 = document.getElementsByClassName("host19")[0];
    const host24 = document.getElementsByClassName("host24")[0];
    const hidediv = document.getElementById("hidediv");
    const pack1 = document.getElementsByClassName("pack1")[0];
    const passwordfield = document.getElementsByClassName("passwordfield")[0]
    const emailcontent = document.getElementsByClassName("emailcontent")[0];
    const RegistrationForm = document.getElementsByClassName("registration-form-container")[0];
    const fbsection = document.getElementById("fbsection");
    const googlesection = document.getElementById("googlesection");
    const applesection = document.getElementById("applesection");
    const p22 = document.getElementById("p22");
    const change1 = document.getElementById("change1");
    const aircoverforhosts = document.getElementsByClassName("aircoverforhosts")[0];
    loginsignupdiv.style.display = "block";
    loginsignupdiv.style.opacity = 1;
    loginsignupdiv.style.width = "35rem";
    loginsignupdiv.style.height = "51rem";
    loginsignupdiv.style.backgroundColor = "white";
    loginsignupdiv.style.boxShadow = "-1px -1px 1px rgb(225, 225, 225)";
    loginsignupdiv.style.border = "1px solid rgb(225, 225, 225)";
    loginsignupdiv.style.borderRadius = "1rem";
    loginsignupdiv.style.position = "absolute";
    loginsignupdiv.style.overflow = "auto";
    loginsignupdiv.style.zIndex = "1";
    loginsignupdiv.style.top = "9rem";
    loginsignupdiv.style.left = "58rem";
    loginsignupdiv.style.transition = "transform 0.5s ease-in-out";
    loginsignupdiv.style.transform = "translateY(0)";
    loginsignupdiv.style.animation = "SlideFromBottom 0.5s ease-in-out";
    hidediv.style.marginTop = "9rem";
    passwordfield.style.width = "30.7rem";
    pack1.style.display = "flex";
    host19.style.backgroundColor = "rgb(122,122,122)";
    host24.style.backgroundColor = "rgb(122,122,122)";
    img2.style.filter = "brightness(0.5)";
    emailcontent.style.marginLeft = "1.6rem";
    change1.style.backgroundColor = "rgb(122,122,122)";
    aircoverforhosts.style.backgroundColor = "rgb(122,122,122)";
    window.addEventListener('click', (event) => {
        const clickoutside1 = document.querySelector(".host4");
        const clickoutside2 = document.querySelector("#btn2");
        if (!clickoutside1.contains(event.target) && !clickoutside2.contains(event.target)) {
            loginsignupdiv.style.display = "none";
            host19.style.backgroundColor = "";
            change1.style.backgroundColor = "";
            img2.style.filter = "";
            host24.style.backgroundColor = "";
            RegistrationForm.style.display = "none";
            emailcontent.style.display = "block";
            hidediv.style.display = "block";
            pack1.style.display = "block";
            pack1.style.display = "flex";
            fbsection.style.display = "block";
            googlesection.style.display = "block";
            applesection.style.display = "block";
            p22.style.display = "block";
            loginsignupdiv.style.width = "35rem";
            loginsignupdiv.style.height = "51rem";
            passwordfield.style.display = "block";
            aircoverforhosts.style.backgroundColor = "";
        }
    });
}
const loginsignupdiv = document.getElementById("loginsignupdiv");
loginsignupdiv.addEventListener("click", (event) => {
    event.stopPropagation();
})
const button = document.querySelector('.continuebutton')
button.addEventListener('mousemove', e => {
    const rect = button.getBoundingClientRect();
    const x = (e.clientX - rect.left) * 100 / button.clientWidth
    const y = (e.clientY - rect.top) * 100 / button.clientHeight
    button.style.setProperty('--mouse-x', x);
    button.style.setProperty('--mouse-y', y);
});
function shownow() {
    const wrap16 = document.getElementsByClassName("wrap16")[0];
    const wrap15 = document.getElementsByClassName("wrap15")[0];
    wrap16.style.display = "block";
    document.body.addEventListener('click', (event) => {
        if (!wrap15.contains(event.target) && (!wrap16.contains(event.target))) {
            wrap16.style.display = "none"
        }
    })
}
function show10() {
    const item13 = document.getElementById("item13");
    const item14 = document.getElementById("item14");
    const item15 = document.getElementById("item15");
    const item17 = document.getElementById("item17");
    const item44 = document.getElementById("item44");
    const item45 = document.getElementById("item45");
    const item46 = document.getElementById("item46");
    const item48 = document.getElementById("item48");
    const item49 = document.getElementById("item49");
    const item50 = document.getElementById("item50");
    item13.style.display = "none";
    item14.style.display = "block";
    item14.style.marginLeft = "94%";
    item14.style.width = "4rem";
    item14.style.height = "4rem";
    item14.style.marginTop = "-4rem";
    item15.style.display = "block";
    item44.style.marginTop = "-34rem";
    item45.style.marginTop = "-35rem";
    item46.style.marginTop = "-70rem";
    item48.style.marginTop = "1rem";
    item49.style.marginTop = "14rem";
    item50.style.marginTop = "-49rem";
}
function show11() {
    const item13 = document.getElementById("item13");
    const item14 = document.getElementById("item14");
    const item15 = document.getElementById("item15");
    const item44 = document.getElementById("item44");
    const item45 = document.getElementById("item45");
    const item46 = document.getElementById("item46");
    const item47 = document.getElementById("item47");
    const item48 = document.getElementById("item48");
    const item49 = document.getElementById("item49");
    const item50 = document.getElementById("item50");
    item13.style.display = "block";
    item13.style.marginTop = "-4rem";
    item14.style.display = "none";
    item15.style.display = "none";
    item44.style.marginTop = "-37rem";
    item45.style.marginTop = "-41rem";
    item46.style.marginTop = "-65rem";
    item47.style.marginTop = "-90rem";
    item48.style.marginTop = "-6rem";
    item49.style.marginTop = "10rem";
    item50.style.marginTop = "-48rem";

}
function show12() {
    const item17 = document.getElementById("item17");
    const item18 = document.getElementById("item18");
    const item19 = document.getElementById("item19");
    const item44 = document.getElementById("item44");
    const item45 = document.getElementById("item45");
    const item46 = document.getElementById("item46");
    const item47 = document.getElementById("item47");
    const item49 = document.getElementById("item49");
    const item50 = document.getElementById("item50");
    item17.style.display = "none";
    item18.style.display = "block";
    item18.style.width = "4rem";
    item18.style.height = "4rem";
    item18.style.marginTop = "-5rem";
    item18.style.marginLeft = "93%";
    item19.style.display = "block";
    item44.style.marginTop = "-27rem";
    item45.style.marginTop = "-31rem";
    item46.style.marginTop = "-64rem";
    item47.style.marginTop = "-92rem";
    item49.style.marginTop = "22rem";
    item50.style.marginTop = "-45rem"
}
function show13() {
    const item17 = document.getElementById("item17");
    const item18 = document.getElementById("item18");
    const item19 = document.getElementById("item19");
    const item44 = document.getElementById("item44");
    const item45 = document.getElementById("item45");
    const item49 = document.getElementById("item49");
    item17.style.display = "block";
    item17.style.marginTop = "-4rem";
    item18.style.display = "none";
    item19.style.display = "none";
    item44.style.marginTop = "-34rem";
    item45.style.marginTop = "-40rem";
    item49.style.marginTop = "13rem";

}
function show14() {
    const item21 = document.getElementById("item21");
    const item22 = document.getElementById("item22");
    const item23 = document.getElementById("item23");
    const item44 = document.getElementById("item44");
    const item46 = document.getElementById("item46");
    const item50 = document.getElementById("item50");
    item21.style.display = "none";
    item22.style.display = "block";
    item22.style.width = "4rem";
    item22.style.height = "4rem";
    item22.style.marginLeft = "93%";
    item22.style.marginTop = "-4rem";
    item23.style.display = "block";
    item44.style.marginTop = "-27rem";
    item46.style.marginTop = "-69rem";
    item50.style.marginTop = "-48rem";

}
function show15() {
    const item25 = document.getElementById("item25");
    const item26 = document.getElementById("item26");
    const item27 = document.getElementById("item27");
    const item44 = document.getElementById("item44");
    const item46 = document.getElementById("item46");
    const item47 = document.getElementById("item47");
    const item49 = document.getElementById("item49");
    const item50 = document.getElementById("item50");
    const host19 = document.getElementsByClassName("host19")[0];
    const host24 = document.getElementsByClassName("host24")[0];
    item25.style.display = "none";
    item26.style.display = "block";
    item27.style.display = "block";
    item26.style.width = "4rem";
    item26.style.height = "4rem";
    item26.style.marginTop = "-4rem";
    item26.style.marginLeft = "93%";
    item44.style.marginTop = "-14rem";
    item46.style.marginTop = "-45rem";
    item47.style.marginTop = "-78rem";
    item49.style.marginTop = "34rem";
    item50.style.marginTop = "-24rem";
    host19.style.height = "288rem";
    host24.style.marginTop = "-75rem";
}
function show16() {
    const item25 = document.getElementById("item25");
    const item26 = document.getElementById("item26");
    const item27 = document.getElementById("item27");
    const item44 = document.getElementById("item44");
    const item46 = document.getElementById("item46");
    const item47 = document.getElementById("item47");
    const item49 = document.getElementById("item49");
    const item50 = document.getElementById("item50");
    item25.style.display = "block";
    item26.style.display = "none";
    item27.style.display = "none";
    item25.style.marginTop = "-4rem";
    item44.style.marginTop = "-35rem";
    item46.style.marginTop = "-66rem";
    item47.style.marginTop = "-93rem";
    item49.style.marginTop = "12rem";
    item50.style.marginTop = "-48rem";
}
function show17() {
    const item21 = document.getElementById("item21");
    const item22 = document.getElementById("item22");
    const item23 = document.getElementById("item23");
    const item44 = document.getElementById("item44");
    const item46 = document.getElementById("item46");
    const item47 = document.getElementById("item47");
    const item50 = document.getElementById("item50");
    item21.style.display = "block";
    item22.style.display = "none";
    item21.style.marginLeft = "94%";
    item21.style.marginTop = "-4rem";
    item23.style.display = "none";
    item44.style.marginTop = "-39rem";
    item46.style.marginTop = "-80rem";
    item47.style.marginTop = "-108rem";
    item50.style.marginTop = "-59rem";
}
function show18() {
    const item29 = document.getElementById("item29");
    const item30 = document.getElementById("item30");
    const item31 = document.getElementById("item31");
    const item46 = document.getElementById("item46");
    const item47 = document.getElementById("item47");
    const item50 = document.getElementById("item50");
    item29.style.display = "none";
    item30.style.display = "block";
    item30.style.width = "4rem";
    item30.style.height = "4rem";
    item30.style.marginLeft = "93%";
    item30.style.marginTop = "-4rem";
    item31.style.display = "block";
    item46.style.marginTop = "-62rem";
    item47.style.marginTop = "-91rem";
    item50.style.marginTop = "-35rem";
}
function show19() {
    const item29 = document.getElementById("item29");
    const item30 = document.getElementById("item30");
    const item31 = document.getElementById("item31");
    const item46 = document.getElementById("item46");
    const item47 = document.getElementById("item47");
    const item50 = document.getElementById("item50");
    item29.style.display = "block";
    item30.style.display = "none";
    item29.style.marginLeft = "97%";
    item29.style.marginTop = "-4rem";
    item31.style.display = "none";
    item46.style.marginTop = "-75rem";
    item47.style.marginTop = "-101rem";
    item50.style.marginTop = "-56rem";
}
function show20() {
    const item33 = document.getElementById("item33");
    const item34 = document.getElementById("item34");
    const item35 = document.getElementById("item35");
    const item46 = document.getElementById("item46");
    const item47 = document.getElementById("item47");
    const host24 = document.getElementsByClassName("host24")[0];
    item33.style.display = "none";
    item34.style.display = "block";
    item34.style.width = "4rem";
    item34.style.height = "4rem";
    item34.style.marginLeft = "93%";
    item34.style.marginTop = "-4rem";
    item35.style.display = "block";
    item46.style.marginTop = "-57rem";
    item47.style.marginTop = "-88rem";
    host24.style.marginTop = "-85rem";
}
function show21() {
    const item33 = document.getElementById("item33");
    const item34 = document.getElementById("item34");
    const item35 = document.getElementById("item35");
    const item46 = document.getElementById("item46");
    const item47 = document.getElementById("item47");
    item33.style.display = "block";
    item34.style.display = "none";
    item33.style.marginTop = "-4rem";
    item35.style.display = "none";
    item46.style.marginTop = "-78rem";
    item47.style.marginTop = "-105rem";
}
function show22() {
    const item37 = document.getElementById("item37");
    const item38 = document.getElementById("item38");
    const item39 = document.getElementById("item39");
    const item40 = document.getElementById("item40");
    const item47 = document.getElementById("item47");
    const host19 = document.getElementsByClassName("host19")[0];
    const host24 = document.getElementsByClassName("host24")[0];
    item37.style.display = "none";
    item38.style.display = "block";
    item38.style.width = "4rem";
    item38.style.height = "4rem";
    item38.style.marginLeft = "93%";
    item38.style.marginTop = "-5rem";
    item39.style.display = "block";
    item40.style.marginTop = "6rem";
    item47.style.marginTop = "-72rem";
    host19.style.height = "294rem";
    host24.style.marginTop = "-69rem";
}
function show23() {
    const item37 = document.getElementById("item37");
    const item38 = document.getElementById("item38");
    const item39 = document.getElementById("item39");
    const item47 = document.getElementById("item47");
    const host19 = document.getElementsByClassName("host19")[0];
    const host24 = document.getElementsByClassName("host24")[0];
    item37.style.display = "block";
    item38.style.display = "none";
    item37.style.marginTop = "-4rem";
    item39.style.display = "none";
    item47.style.marginTop = "-105rem";
    host19.style.height = "268rem";
    host24.style.marginTop = "-99rem";
}
function show24() {
    const item41 = document.getElementById("item41");
    const item42 = document.getElementById("item42");
    const item43 = document.getElementById("item43");
    const host24 = document.getElementsByClassName("host24")[0];
    item41.style.display = "none";
    item42.style.display = "block";
    item42.style.width = "4rem";
    item42.style.height = "4rem";
    item42.style.marginLeft = "93%";
    item42.style.marginTop = "-4rem";
    item43.style.display = "block";
    host24.style.marginTop = "-95rem";
}
function show25() {
    const item41 = document.getElementById("item41");
    const item42 = document.getElementById("item42");
    const item43 = document.getElementById("item43");
    item41.style.display = "block";
    item41.style.marginTop = "-4rem";
    item42.style.display = "none";
    item43.style.display = "none";

}
function fun18() {
    const showemailtext = document.getElementsByClassName("showemailtext")[0];
    const emailshow = document.getElementsByClassName("emailshow")[0];
    emailshow.style.display = "none";
    showemailtext.style.display = "block";
    document.addEventListener('click', previous);
}
function previous(event) {
    const emailcontent = document.getElementsByClassName("emailcontent")[0];
    const emailshow = document.getElementsByClassName("emailshow")[0];
    const showemailtext = document.getElementsByClassName("showemailtext")[0];
    if (!emailcontent.contains(event.target)) {
        emailshow.style.display = "block";
        showemailtext.style.display = "none";
    }
}
function hidedisplay() {
    const loginsignupdiv = document.getElementById("loginsignupdiv");
    const pElements = document.querySelectorAll(".p img");
    const emailcontent = document.getElementsByClassName("emailcontent")[0];
    const hidediv = document.getElementById("hidediv");
    const pack1 = document.getElementsByClassName("pack1")[0];
    const host19 = document.getElementsByClassName("host19")[0];
    const host24 = document.getElementsByClassName("host24")[0];
    const aircoverforhosts = document.getElementsByClassName("aircoverforhosts")[0];
    const passwordfield = document.getElementsByClassName("passwordfield")[0]
    const change1 = document.getElementById("change1");
    const img2 = document.getElementById("img2");
    loginsignupdiv.style.width = "35rem";
    loginsignupdiv.style.height = "51rem";
    emailcontent.style.display = "block";
    hidediv.style.display = "block";
    pack1.style.display = "block";
    document.querySelector('#fbsection').style.display = "block";
    document.querySelector('#fbsection').style.display = "flex";
    document.querySelector('#googlesection').style.display = "block";
    document.querySelector('#googlesection').style.display = "flex";
    document.querySelector('#applesection').style.display = "block";
    document.querySelector('#applesection').style.display = "flex";
    document.querySelector('#p22').style.display = "block";
    document.querySelector('#p22').style.display = "flex";
    document.querySelector('.registration-form-container').style.display = "none";
    document.querySelector('.passwordfield').style.display = "block";
    loginsignupdiv.style.display = "none";
    loginsignupdiv.classList.remove("show1");
    loginsignupdiv.classList.add("loginsignupcontainer");
    host19.style.backgroundColor = "";
    change1.style.backgroundColor = "";
    img2.style.filter = "";
    host24.style.backgroundColor = "";
    aircoverforhosts.style.backgroundColor = "";
}
function fun52() {
    const fname = document.getElementById("fname");
    const showinput1 = document.getElementById("first-name");
    const register1 = document.getElementById("register1");
    fname.style.fontSize = "1rem";
    fname.style.marginTop = "1rem";
    showinput1.style.display = "block";
    showinput1.style.marginTop = "1rem";
    showinput1.style.marginLeft = "1.1rem";
    register1.style.height = "7.6rem";
    register1.style.borderBottomLeftRadius = "0.7rem";
    register1.style.borderBottomRightRadius = "0.7rem";
}
function fun53() {
    const lname = document.getElementById("lname");
    const showinput2 = document.getElementById("last-name");
    const register2 = document.getElementById("register2");
    lname.style.fontSize = "1rem";
    lname.style.marginTop = "1rem";
    showinput2.style.display = "block";
    showinput2.style.position = "relative";
    showinput2.style.marginTop = "1rem";
    showinput2.style.marginLeft = "1.1rem";
    register2.style.height = "7.6rem";
    register2.style.borderBottomLeftRadius = "0.7rem";
    register2.style.borderBottomRightRadius = "0.7rem";
    register2.style.borderTopLeftRadius = "0.7rem";
    register2.style.borderTopRightRadius = "0.7rem";
}
function fun54() {
    const dob = document.getElementById("dob");
    const showinput3 = document.getElementById("date-of-birth");
    dob.style.fontSize = "1rem";
    dob.style.marginTop = "1rem";
    showinput3.style.display = "block";
}
function fun55() {
    const pass1 = document.getElementById("pass1");
    const showinput4 = document.getElementById("pass2");
    const register4 = document.getElementById("register4");
    pass1.style.fontSize = "1rem";
    pass1.style.marginTop = "1rem";
    showinput4.style.display = "block";
    register4.style.border = "2px solid black";
}
function calculateAge(dateOfBirth) {
    // Parse the date of birth string into a Date object
    const dob = new Date(dateOfBirth);

    // Get the current date
    const currentDate = new Date();

    // Calculate the difference in years
    let age = currentDate.getFullYear() - dob.getFullYear();

    // Adjust the age if the birthday hasn't occurred yet this year
    if (currentDate.getMonth() < dob.getMonth() ||
        (currentDate.getMonth() === dob.getMonth() && currentDate.getDate() < dob.getDate())) {
        age--;
    }
    return age;
}
function submit2(event) {
    event.preventDefault();
    const et = document.getElementById("et");
    const emailerror = document.getElementsByClassName("emailerror")[0];
    const emailcontent = document.getElementsByClassName("emailcontent")[0];
    const userlogo = document.getElementsByClassName("userlogo")[0];
    const loginsignupdiv = document.getElementById("loginsignupdiv");
    const emailinfoValue = document.getElementById("email-info");
    const pack1 = document.getElementsByClassName("pack1")[0];
    const pass = document.getElementById("pass");
    const Password = pass.value.trim();
    const change = document.getElementById("change");
    const img2 = document.getElementById("img2");
    const change1 = document.getElementById("change1");
    const host19 = document.getElementsByClassName("host19")[0];
    const host24 = document.getElementsByClassName("host24")[0];
    const aircoverforhosts = document.getElementsByClassName("aircoverforhosts")[0];
    const RegistrationForm = document.getElementsByClassName("registration-form-container")[0];
    const logincircle = document.getElementsByClassName("logincircle")[0];
    let regex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
    const inputValue = et.value.trim();
    const inputValueAsString = inputValue.toString()
    if (regex.test(inputValueAsString)) {
        emailerror.style.display = "none";
        const formData = {
            email: inputValue,
            password: Password,
        };
        fetch('/handlelogin', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(formData),
        })
            .then(response => response.json())
            .then(data => {
                if (data.message === "Success") {
                    alert("You are logged in Successfully");
                    document.querySelector('#loginsignupdiv').style.display = "none";
                    let character = inputValue[0];
                    userlogo.innerText = character;
                    document.querySelector('.logincircle').style.display = "block";
                    logincircle.style.marginLeft = "2rem";
                    logincircle.style.marginTop = "5rem";
                    img2.style.filter = "";
                    host19.style.backgroundColor = "";
                    host24.style.backgroundColor = "";
                    change1.style.backgroundColor = "";
                    aircoverforhosts.style.backgroundColor = "";
                } else if (data.message === "Login Failed!") {
                    alert("Invalid Credentials!");
                }
                else if (data.message === "User not found") {
                    alert("Please Register");
                    document.querySelector('.registration-form-container').style.display = 'block';
                    emailinfoValue.value = inputValue;
                    document.querySelector('#hidediv').style.display = "none";
                    document.querySelector('.emailcontent').style.display = "none";
                    document.querySelector('.passwordfield').style.display = "none";
                    document.querySelector('#fbsection').style.display = "none";
                    document.querySelector('#googlesection').style.display = "none";
                    document.querySelector('#applesection').style.display = "none";
                    document.querySelector('#p22').style.display = "none";
                    loginsignupdiv.style.height = "96rem";
                    loginsignupdiv.style.width = "58rem";
                    loginsignupdiv.style.marginLeft = "1rem";
                    loginsignupdiv.style.overflow = "hidden";
                    RegistrationForm.style.marginTop = "-1rem";
                    RegistrationForm.style.marginLeft = "4rem";
                    pack1.style.display = "none";
                }
            })
            .catch((error) => {
                console.error('Error:', error);
            });
    }
    else {
        emailerror.style.display = "block";
        emailcontent.style.border = "2px solid red";
        emailerror.style.color = "red";
        emailerror.style.marginLeft = "5%";
        emailerror.innerHTML = "Please Enter Vaild Email address !";
    }
    if (et.value == "") {
        emailerror.style.display = "block";
        emailcontent.style.border = "2px solid red";
        emailerror.style.color = "red";
        emailerror.style.marginLeft = "5%";
        emailerror.innerHTML = "Email required !";
    }
}
function submit5(event) {
    event.preventDefault();
    const captureemail = document.getElementById("email-info");
    const Firstname = document.getElementById("first-name");
    const Lastname = document.getElementById("last-name");
    const Dob = document.getElementById("date-of-birth");
    const pass2 = document.getElementById("pass2");
    const Password = pass2.value.trim();
    const inputValue = captureemail.value.trim();
    let userlogo = document.getElementsByClassName("userlogo")[0];
    const img2 = document.getElementById("img2");
    const change1 = document.getElementById("change1");
    const host19 = document.getElementsByClassName("host19")[0];
    const host24 = document.getElementsByClassName("host24")[0];
    const logincircle = document.getElementsByClassName("logincircle")[0];
    const aircoverforhosts = document.getElementsByClassName("aircoverforhosts")[0];
    const dateOfBirth = Dob.value;
    const age = calculateAge(dateOfBirth);
    if (age < 18) {
        alert("Age cannot be less than 18 years");
        return;
    }
    const formdata = {
        email: captureemail.value,
        password: Password,
        Firstname: Firstname.value,
        Lastname: Lastname.value,
        Dob: Dob.value,
    }
    fetch('/registeruserdetails', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(formdata)
    })
        .then(response => response.json())
        .then(data => {
            if (data.message === 'Details are already saved.Please login') {
                alert("Details already Saved Please Login")
            }
            else if (data.message === "Details saved Successfully") {
                alert("Details Successfully Saved");
                document.querySelector('.passwordfield').style.display = "none";
                document.querySelector('#googlesection').style.display = "none";
                document.querySelector('#applesection').style.display = "none";
                document.querySelector('#loginsignupdiv').style.display = "none";
                document.querySelector('.registration-form-container').style.display = "none";
                let character = inputValue[0];
                userlogo.innerText = character;
                document.querySelector('.logincircle').style.display = "block";
                logincircle.style.marginLeft = "2rem";
                logincircle.style.marginTop = "5rem";
                img2.style.filter = "";
                host19.style.backgroundColor = "";
                host24.style.backgroundColor = "";
                change1.style.backgroundColor = "";
                aircoverforhosts.style.backgroundColor = "";
            }
        })
        .catch((err) => {
            console.error(err)
        })
};
function fun17() {
    const emailshow = document.getElementsByClassName("emailshow")[0];
    const emailcontent = document.getElementsByClassName("emailcontent")[0];
    const showemailtext = document.getElementsByClassName("showemailtext")[0];
    const error2 = document.getElementsByClassName("error2")[0];
    const hidediv = document.getElementById("hidediv");
    const emailerror = document.getElementsByClassName("emailerror")[0];
    emailshow.style.display = "block";
    error2.style.display = "none";
    showemailtext.style.display = "none";
    loginsignupdiv.style.height = "50rem";
    hidediv.style.display = "block";
    emailcontent.style.border = "2px solid black";
    document.body.addEventListener("click", (event) => {
        if (!emailcontent.contains(event.target) || !hidediv.contains(event.target)) {
            emailcontent.style.border = "2px solid black";
            emailerror.style.display = "none";
        }
    })
}
function fun56() {
    const emailcontent = document.getElementsByClassName("emailcontent")[0];
    const passwordfield = document.getElementsByClassName("passwordfield")[0];
    const registrationForm = document.getElementsByClassName("registration-form-container")[0];
    const hidediv = document.getElementById("hidediv");
    const pack1 = document.getElementsByClassName("pack1")[0];
    const fbsection = document.getElementById("fbsection");
    const googlesection = document.getElementById("googlesection");
    const applesection = document.getElementById("applesection");
    const p22 = document.getElementById("p22");
    const loginsignupdiv = document.getElementById("loginsignupdiv");
    emailcontent.style.display = "block";
    passwordfield.style.display = "block";
    registrationForm.style.display = "none";
    hidediv.style.display = "block";
    pack1.style.display = "block";
    pack1.style.display = "flex";
    fbsection.style.display = "block";
    fbsection.style.display = "flex";
    googlesection.style.display = "block";
    googlesection.style.display = "flex";
    applesection.style.display = "block";
    applesection.style.display = "flex";
    p22.style.display = "block";
    p22.style.display = "flex";
    loginsignupdiv.style.width = "35rem";
    loginsignupdiv.style.height = "51rem";
}