let counter9=0;
function add9() {
    const four = document.getElementById("four");
    const fifth = document.getElementById("fifth");
    const second = document.getElementById("second");
    const first = document.getElementById("first");
    const sixth = document.getElementById("sixth");
    counter9++;
    fifth.style.userSelect = "none";
    second.style.userSelect = "none";
    second.style.cursor = "pointer";
    first.style.cursor = "pointer";
    four.innerHTML = counter9;
    sixth.style.color = "black";
    second.style.color = "black";
    fifth.onmouseover = () => {
        fifth.style.border = "2px solid black";
        sixth.style.color = "black";
    }
    fifth.onmouseout = () => {
        fifth.style.border = "2px solid rgb(185, 185, 185)";
    }
    first.onmouseover = () => {
        first.style.border = "2px solid black";
        second.style.color = "black";
    }
    first.onmouseout = () => {
        first.style.border = "2px solid rgb(185, 185, 185)";
    }

}
function sub9() {
    const fifth = document.getElementById("fifth");
    const four = document.getElementById("four");
    const second = document.getElementById("second");
    const first = document.getElementById("first");
    fifth.style.cursor = "pointer";
    if (counter9 > 0) {
        counter9--;
        four.innerHTML = counter9;
       first.style.cursor = "pointer";

    }
    if (counter9 == 0) {
        first.style.cursor = "not-allowed";
        second.style.cursor = "not-allowed";
        first.style.border = "2px solid rgb(185, 185, 185)";
        second.style.color = "rgb(185, 185, 185)"
        first.onmouseover = () => {
            first.style.border = "2px solid rgb(185, 185, 185)";
            second.style.color = "rgb(185, 185, 185)";
        }
        first.onmouseout = () => {
            first.style.border = "2px solid rgb(185, 185, 185)";
            second.style.color = "rgb(185, 185, 185)";
        }
    }
}
let counter10=0;
function add10() {
    const ten = document.getElementById("ten");
    const eleven = document.getElementById("eleven");
    const eight = document.getElementById("eight");
    const seven = document.getElementById("seven");
    const twelve = document.getElementById("twelve");
    counter10++;
    eleven.style.userSelect = "none";
    eight.style.userSelect = "none";
    eight.style.cursor = "pointer";
    seven.style.cursor = "pointer";
    ten.innerHTML = counter10;
    twelve.style.color = "black";
    eight.style.color = "black";
    eleven.onmouseover = () => {
        eleven.style.border = "2px solid black";
        twelve.style.color = "black";
    }
    eleven.onmouseout = () => {
        eleven.style.border = "2px solid rgb(185, 185, 185)";
    }
    seven.onmouseover = () => {
        seven.style.border = "2px solid black";
        eight.style.color = "black";
    }
    seven.onmouseout = () => {
        seven.style.border = "2px solid rgb(185, 185, 185)";
    }
}
function sub10() {
    const eleven = document.getElementById("eleven");
    const ten = document.getElementById("ten");
    const eight = document.getElementById("eight");
    const seven = document.getElementById("seven");
    eleven.style.cursor = "pointer";
    if (counter10 > 0) {
        counter10--;
        ten.innerHTML = counter10;
        seven.style.cursor = "pointer";
    }
    if (counter10 == 0) {
        seven.style.cursor = "not-allowed";
        eight.style.cursor = "not-allowed";
        seven.style.border = "2px solid rgb(185, 185, 185)";
        eight.style.color = "rgb(185, 185, 185)"
        seven.onmouseover = () => {
            seven.style.border = "2px solid rgb(185, 185, 185)";
            eight.style.color = "rgb(185, 185, 185)";
        }
        seven.onmouseout = () => {
            seven.style.border = "2px solid rgb(185, 185, 185)";
            eight.style.color = "rgb(185, 185, 185)";
        }
    }
}
let counter11=0;
function add11() {
    const sixteen = document.getElementById("sixteen");
    const seventeen = document.getElementById("seventeen");
    const fourteen = document.getElementById("fourteen");
    const thirteen = document.getElementById("thirteen");
    const eighteen = document.getElementById("eighteen");
    counter11++;
    seventeen.style.userSelect = "none";
    fourteen.style.userSelect = "none";
    fourteen.style.cursor = "pointer";
    thirteen.style.cursor = "pointer";
    sixteen.innerHTML = counter11;
    eighteen.style.color = "black";
    fourteen.style.color = "black";
    seventeen.onmouseover = () => {
        seventeen.style.border = "2px solid black";
        eighteen.style.color = "black";
    }
    seventeen.onmouseout = () => {
        seventeen.style.border = "2px solid rgb(185, 185, 185)";
    }
    thirteen.onmouseover = () => {
        thirteen.style.border = "2px solid black";
        fourteen.style.color = "black";
    }
    thirteen.onmouseout = () => {
        thirteen.style.border = "2px solid rgb(185, 185, 185)";
    }
}
function sub11() {
    const seventeen = document.getElementById("seventeen");
    const sixteen = document.getElementById("sixteen");
    const fourteen = document.getElementById("fourteen");
    const thirteen = document.getElementById("thirteen");
    seventeen.style.cursor = "pointer";
    if (counter11 > 0) {
        counter11--;
        sixteen.innerHTML = counter11;
        thirteen.style.cursor = "pointer";
    }
    if (counter11 == 0) {
        thirteen.style.cursor = "not-allowed";
        fourteen.style.cursor = "not-allowed";
        thirteen.style.border = "2px solid rgb(185, 185, 185)";
        fourteen.style.color = "rgb(185, 185, 185)"
        thirteen.onmouseover = () => {
            thirteen.style.border = "2px solid rgb(185, 185, 185)";
            fourteen.style.color = "rgb(185, 185, 185)";
        }
        thirteen.onmouseout = () => {
            thirteen.style.border = "2px solid rgb(185, 185, 185)";
            fourteen.style.color = "rgb(185, 185, 185)";
        }
    }
}
let counter12=0;
function add12() {
    const twentytwo = document.getElementById("twentytwo");
    const twentythree = document.getElementById("twentythree");
    const twenty = document.getElementById("twenty");
    const nineteen = document.getElementById("nineteen");
    const twentyfour = document.getElementById("twentyfour");
    counter12++;
    twentythree.style.userSelect = "none";
    twenty.style.userSelect = "none";
    twenty.style.cursor = "pointer";
    nineteen.style.cursor = "pointer";
    twentytwo.innerHTML = counter12;
    twentyfour.style.color = "black";
    twenty.style.color = "black";
    twentythree.onmouseover = () => {
        twentythree.style.border = "2px solid black";
        twentyfour.style.color = "black";
    }
    twentythree.onmouseout = () => {
        twentythree.style.border = "2px solid rgb(185, 185, 185)";
    }
    nineteen.onmouseover = () => {
        nineteen.style.border = "2px solid black";
        twenty.style.color = "black";
    }
    nineteen.onmouseout = () => {
        nineteen.style.border = "2px solid rgb(185, 185, 185)";
    }
}
function sub12() {
    const twentythree = document.getElementById("twentythree");
    const twentytwo = document.getElementById("twentytwo");
    const twenty = document.getElementById("twenty");
    const nineteen = document.getElementById("nineteen");
    twentythree.style.cursor = "pointer";
    if (counter12 > 0) {
        counter12--;
        twentytwo.innerHTML = counter12;
        nineteen.style.cursor = "pointer";

    }
    if (counter12 == 0) {
        nineteen.style.cursor = "not-allowed";
        twenty.style.cursor = "not-allowed";
        nineteen.style.border = "2px solid rgb(185, 185, 185)";
        twenty.style.color = "rgb(185, 185, 185)"
        nineteen.onmouseover = () => {
            nineteen.style.border = "2px solid rgb(185, 185, 185)";
            twenty.style.color = "rgb(185, 185, 185)";
        }
        nineteen.onmouseout = () => {
            nineteen.style.border = "2px solid rgb(185, 185, 185)";
            twenty.style.color = "rgb(185, 185, 185)";
        }
    }
}
function back(event){
    event.preventDefault();
    fetch('/back4',{
        method:"get",
        headers:{
            "Content-Type":"application/json"
        }
    })
    .then(response=>{
        if(response.redirected){
            window.location.href=response.url
        }
    })
    .then(data=>console.log(data))
    .catch(error=>console.error(error))
}
function next(event){
event.preventDefault();
fetch('/nextfive',{
    method:"get",
    headers:{
        "Content-Type":"application/json"
    }
})
.then(response=>{
    if(response.redirected){
        window.location.href=response.url
    }
})
.then(data=>console.log(data))
.catch(error=>console.error(error))
}