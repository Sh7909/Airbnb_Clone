function editvalue() {
    const defaultprice = document.querySelector(".defaultprice");
    const price = document.getElementById("price");
    const value1 = document.getElementById("value1");
    const value2 = document.getElementById("value2");
    const value3 = document.getElementById("value3");
    const value4 = document.getElementById("value4");
    const pcount = document.getElementById("pcount");
    const Benefit = document.getElementById("Benefit");
    const previousprice = document.getElementById("previousprice");
    const section17 = document.getElementsByClassName("section17")[0];
    const section19 = document.getElementsByClassName("section19")[0];
    const section21 = document.getElementsByClassName("section21")[0];
    const section22 = document.getElementsByClassName("section22")[0];
    const section22one = document.getElementsByClassName("section22one")[0];
    var count1;
    const arr = [
        444, 544, 644, 744, 844, 944, 1044, 1144, 1244, 1344, 1444, 1544, 1644, 1744, 1844,
        1944, 2044, 2144, 2244, 2344, 2444, 2544, 2644, 2744, 2844, 2944, 3044, 3144, 3244, 3344,
        3444, 3544, 3644, 3744, 3844, 3944, 4044, 4144, 4244, 4344, 4444, 4544, 4644, 4744, 4844,
        4944, 5044, 5144, 5244, 5344, 5444, 5544, 5644, 5744, 5844, 5944, 6044, 6144, 6244, 6344,
        6844, 6944, 7044, 7144, 7244, 7344, 7444, 7544, 7644, 7744, 7844, 7944, 8044, 8144, 8244,
        8344, 8444, 8544, 8644, 8744, 8844, 8944, 9044, 9144, 9244, 9344, 9444, 9544, 9644, 9744,
        9844, 9944, 10044, 10144, 10244, 10344, 10444, 10544, 10644, 10744, 10844, 10944, 11044,
        11144, 11244, 11344, 11444, 11544, 11644, 11744, 11844, 11944, 12044, 12144, 12244, 12344,
        12444, 12544, 12644, 12744, 12844, 12944, 13044, 13144, 13244, 13344, 13444, 13544, 13644,
        13744, 13844, 13944, 14044, 14144, 14244, 14344, 14444, 14544, 14644, 14744, 14844, 14944,
        15044, 15144, 15244, 15344, 15444, 15544, 15644, 15744, 15844, 15944, 16044, 16144, 16244,
        16344, 16444, 16544, 16644, 16744, 16844, 16944, 17044, 17144, 17244, 17344, 17444, 17544,
        17644, 17744, 17844, 17944, 18044, 18144, 18244, 18344, 18444, 18544, 18644, 18744, 18844,
        18944, 19044, 19144, 19244, 19344, 19444, 19544, 19644, 19744, 19844, 19944, 20044, 20144,
        20244,20344]
    defaultprice.style.display = "none";
    price.value = "";
    price.style.display = "block";
    document.body.addEventListener("click", (event) => {
        if (!section17.contains(event.target)) {
            previousprice.style.display = "none";
            pcount.style.display = "none";
            section22.style.display = "block";
            section22one.style.display = "flex";
            section22one.style.justifyContent = "space-between";
            value1.value = price.value;
            const str=price.value.trim();
            count1 = str.replace(/,/g, "");
            if (count1 < 3000) {
                alert("Please enter a basic price between ₹3000 and ₹200000")
                section19.style.display = "none";
                section21.style.display = "none";
            }

            if (count1 >= 3000 && count1 < 4000) {
                value2.innerText = arr[0];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }
    
            if (count1 >= 4000 && count1 < 5000) {
                value2.innerText = arr[1];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }

            if (count1 >= 5000 && count1 < 6000) {
                value2.innerText = arr[2];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }

            if (count1 >= 6000 && count1 < 7000) {
                value2.innerText = arr[3];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }

            if (count1 >= 7000 && count1 < 8000) {
                value2.innerText = arr[4];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }
        
            if (count1 >= 8000 && count1 < 9000) {
                value2.innerText = arr[5];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }
        
            if (count1 >= 9000 && count1 < 10000) {
                value2.innerText = arr[6];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }
        
            if (count1 >= 10000 && count1 < 11000) {
                value2.innerText = arr[7];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }
        
            if (count1 >= 11000 && count1 < 12000) {
                value2.innerText = arr[8];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }
        
            if (count1 >= 12000 && count1 < 13000) {
                value2.innerText = arr[9];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }
        
            if (count1 >= 13000 && count1 < 14000) {
                value2.innerText = arr[10];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }
    
            if (count1 >= 14000 && count1 < 15000) {
                value2.innerText = arr[11];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }
       
            if (count1 >= 15000 && count1 < 16000) {
                value2.innerText = arr[12];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
                
            }
            if (count1 >= 16000 && count1 < 17000) {
                value2.innerText = arr[13];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }
       
            if (count1 >= 17000 && count1 < 18000) {
                value2.innerText = arr[14];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }

            if (count1 >= 18000 && count1 < 19000) {
                value2.innerText = arr[15];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }
       
            if (count1 >= 19000 && count1 < 20000) {
                value2.innerText = arr[16];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }
        
            if (count1 >= 20000 && count1 < 21000) {
                value2.innerText = arr[17];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }

            if (count1 >= 21000 && count1 < 22000) {
                value2.innerText = arr[18];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }

            if (count1 >= 22000 && count1 < 23000) {
                value2.innerText = arr[19];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }
        
            if (count1 >= 23000 && count1 < 24000) {
                value2.innerText = arr[20];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }
    
            if (count1 >= 24000 && count1 < 25000) {
                value2.innerText = arr[21];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }
        
            if (count1 >= 25000 && count1 < 26000) {
                value2.innerText = arr[22];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }
    
            if (count1 >= 26000 && count1 < 27000) {
                value2.innerText = arr[23];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }

            if (count1 >= 27000 && count1 < 28000) {
                value2.innerText = arr[24];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }
        
            if (count1 >= 28000 && count1 < 29000) {
                value2.innerText = arr[25];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }

            if (count1 >= 29000 && count1 < 30000) {
                value2.innerText = arr[26];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }
        
            if (count1 >= 30000 && count1 < 31000) {
                value2.innerText = arr[27];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }
    
            if (count1 >= 31000 && count1 < 32000) {
                value2.innerText = arr[28];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }
    
            if (count1 >= 32000 && count1 < 33000) {
                value2.innerText = arr[29];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }
        
            if (count1 >= 33000 && count1 < 34000) {
                value2.innerText = arr[30];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }
        
            if (count1 >= 34000 && count1 < 35000) {
                value2.innerText = arr[31];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }
            if (count1 >= 35000 && count1 < 36000) {
                value2.innerText = arr[32];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }
            if (count1 >= 36000 && count1 < 37000) {
                value2.innerText = arr[33];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }
        
            if (count1 >= 37000 && count1 < 38000) {
                value2.innerText = arr[34];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }
    
            if (count1 >= 38000 && count1 < 39000) {
                value2.innerText = arr[35];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }
        
            if (count1 >= 39000 && count1 < 40000) {
                value2.innerText = arr[36];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }
        
            if (count1 >= 40000 && count1 < 41000) {
                value2.innerText = arr[37];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }
            if (count1 >= 41000 && count1 < 42000) {
                value2.innerText = arr[38];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }
      
            if (count1 >= 42000 && count1 < 43000) {
                value2.innerText = arr[39];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }
            if (count1 >= 43000 && count1 < 44000) {
                value2.innerText = arr[40];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }
      
            if (count1 >= 44000 && count1 < 45000) {
                value2.innerText = arr[41];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }

            if (count1 >= 45000 && count1 < 46000) {
                value2.innerText = arr[42];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }
       
            if (count1 >= 46000 && count1 < 47000) {
                value2.innerText = arr[43];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }
       
            if (count1 >= 47000 && count1 < 48000) {
                value2.innerText = arr[44];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }
       
            if (count1 >= 49000 && count1 < 50000) {
                value2.innerText = arr[45];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }

            if (count1 >= 50000 && count1 < 51000) {
                value2.innerText = arr[46];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }

            if (count1 >= 51000 && count1 < 52000) {
                value2.innerText = arr[47];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }
    
            if (count1 >= 52000 && count1 < 53000) {
                value2.innerText = arr[48];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }

            if (count1 >= 53000 && count1 < 54000) {
                value2.innerText = arr[49];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }
       
            if (count1 >= 54000 && count1 < 55000) {
                value2.innerText = arr[50];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }

            if (count1 >= 55000 && count1 < 56000) {
                value2.innerText = arr[51];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }
       
            if (count1 >= 56000 && count1 < 57000) {
                value2.innerText = arr[52];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }
    
            if (count1 >= 57000 && count1 < 58000) {
                value2.innerText = arr[53];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }

            if (count1 >= 58000 && count1 < 59000) {
                value2.innerText = arr[54];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }

            if (count1 >= 59000 && count1 < 60000) {
                value2.innerText = arr[55];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }
       
            if (count1 >= 60000 && count1 < 61000) {
                value2.innerText = arr[56];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }

            if (count1 >= 61000 && count1 < 62000) {
                value2.innerText = arr[57];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }
            if (count1 >= 62000 && count1 < 63000) {
                value2.innerText = arr[58];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }
            if (count1 >= 63000 && count1 < 64000) {
                value2.innerText = arr[59];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }
    
            if (count1 >= 64000 && count1 < 65000) {
                value2.innerText = arr[60];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }
       
            if (count1 >= 65000 && count1 < 66000) {
                value2.innerText = arr[61];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }
    
            if (count1 >= 66000 && count1 < 67000) {
                value2.innerText = arr[62];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }
        
            if (count1 >= 67000 && count1 < 68000) {
                value2.innerText = arr[63];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }
            if (count1 >= 68000 && count1 < 69000) {
                value2.innerText = arr[64];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }
        
            if (count1 >= 69000 && count1 < 70000) {
                value2.innerText = arr[65];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }
       
            if (count1 >= 70000 && count1 < 71000) {
                value2.innerText = arr[66];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }
       
            if (count1 >= 71000 && count1 < 72000) {
                value2.innerText = arr[67];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }
        
            if (count1 >= 72000 && count1 < 73000) {
                value2.innerText = arr[68];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }
       
            if (count1 >= 73000 && count1 < 74000) {
                value2.innerText = arr[69];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }
            if (count1 >= 74000 && count1 < 75000) {
                value2.innerText = arr[70];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }
            if (count1 >= 75000 && count1 < 76000) {
                value2.innerText = arr[71];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }
       
            if (count1 >= 76000 && count1 < 77000) {
                value2.innerText = arr[72];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }
       
            if (count1 >= 77000 && count1 < 78000) {
                value2.innerText = arr[73];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }
            if (count1 >= 78000 && count1 < 79000) {
                value2.innerText = arr[74];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }
            if (count1 >= 79000 && count1 < 80000) {
                value2.innerText = arr[75];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }
            if (count1 >=80000 && count1 < 81000) {
                value2.innerText = arr[76];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }
        
            if (count1 >=81000 && count1 < 82000) {
                value2.innerText = arr[77];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }
            if (count1 >=82000 && count1 < 83000) {
                value2.innerText = arr[78];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }
            if (count1 >=83000 && count1 < 84000) {
                value2.innerText = arr[79];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }
            if (count1 >=84000 && count1 < 85000) {
                value2.innerText = arr[80];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }
            if (count1 >=85000 && count1 < 86000) {
                value2.innerText = arr[81];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }
            if (count1 >=86000 && count1 < 87000) {
                value2.innerText = arr[82];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }
            if (count1 >=87000 && count1 < 88000) {
                value2.innerText = arr[83];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }
            if (count1 >=88000 && count1 < 89000) {
                value2.innerText = arr[84];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }
            if (count1 >=89000 && count1 < 90000) {
                value2.innerText = arr[85];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }
            if (count1 >=90000 && count1 < 91000) {
                value2.innerText = arr[86];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }
            if (count1 >=91000 && count1 < 92000) {
                value2.innerText = arr[87];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }
            if (count1 >=92000 && count1 < 93000) {
                value2.innerText = arr[88];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }
            if (count1 >=93000 && count1 < 94000) {
                value2.innerText = arr[89];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }
            if (count1 >=94000 && count1 < 95000) {
                value2.innerText = arr[90];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }
            if (count1 >=95000 && count1 < 96000) {
                value2.innerText = arr[91];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }
            if (count1 >=96000 && count1 < 97000) {
                value2.innerText = arr[92];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }
            if (count1 >=97000 && count1 < 98000) {
                value2.innerText = arr[93];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }
            if (count1 >=98000 && count1 < 99000) {
                value2.innerText = arr[94];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }
            if (count1 >=99000 && count1 < 100000) {
                value2.innerText = arr[95];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }
            if (count1 >=100000 && count1 < 101000) {
                value2.innerText = arr[96];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }
            if (count1 >=101000 && count1 < 102000) {
                value2.innerText = arr[97];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }
            if (count1 >=102000 && count1 < 103000) {
                value2.innerText = arr[98];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }
            if (count1 >=103000 && count1 < 104000) {
                value2.innerText = arr[99];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }
            if (count1 >=104000 && count1 < 105000) {
                value2.innerText = arr[100];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }
            if (count1 >=105000 && count1 < 106000) {
                value2.innerText = arr[101];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }
            if (count1 >=106000 && count1 < 107000) {
                value2.innerText = arr[102];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }
            if (count1 >=107000 && count1 < 108000) {
                value2.innerText = arr[103];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }

            if (count1 >=108000 && count1 < 109000) {
                value2.innerText = arr[104];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }
            if (count1 >=109000 && count1 < 110000) {
                value2.innerText = arr[105];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }
            if (count1 >=110000 && count1 < 111000) {
                value2.innerText = arr[106];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }
            if (count1 >=111000 && count1 < 112000) {
                value2.innerText = arr[107];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }
       
            if (count1 >=112000 && count1 < 113000) {
                value2.innerText = arr[108];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }

            if (count1 >=113000 && count1 < 114000) {
                value2.innerText = arr[109];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }
        
            if (count1 >=114000 && count1 < 115000) {
                value2.innerText = arr[110];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }

            if (count1 >=115000 && count1 < 116000) {
                value2.innerText = arr[111];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }
       
            if (count1 >=116000 && count1 < 117000) {
                value2.innerText = arr[112];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }

            if (count1 >=117000 && count1 < 118000) {
                value2.innerText = arr[113];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }
       
            if (count1 >=118000 && count1 < 119000) {
                value2.innerText = arr[114];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }

            if (count1 >=119000 && count1 < 120000) {
                value2.innerText = arr[115];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }
        
            if (count1 >=120000 && count1 < 121000) {
                value2.innerText = arr[116];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }
       
            if (count1 >=121000 && count1 < 122000) {
                value2.innerText = arr[117];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }
        
            if (count1 >=122000 && count1 < 123000) {
                value2.innerText = arr[118];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }
        
            if (count1 >=123000 && count1 < 124000) {
                value2.innerText = arr[119];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }
       
            if (count1 >=124000 && count1 < 125000) {
                value2.innerText = arr[120];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }
       
            if (count1 >=125000 && count1 < 126000) {
                value2.innerText = arr[121];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }
        
            if (count1 >=126000 && count1 < 127000) {
                value2.innerText = arr[122];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }
       
            if (count1 >=127000 && count1 < 128000) {
                value2.innerText = arr[123];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }
        
            if (count1 >=128000 && count1 < 129000) {
                value2.innerText = arr[124];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }

            if (count1 >=129000 && count1 < 130000) {
                value2.innerText = arr[125];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }
        
            if (count1 >=130000 && count1 < 131000) {
                value2.innerText = arr[126];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }
        
            if (count1 >=131000 && count1 < 132000) {
                value2.innerText = arr[127];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }
        
            if (count1 >=132000 && count1 < 133000) {
                value2.innerText = arr[128];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }

            if (count1 >=133000 && count1 < 134000) {
                value2.innerText = arr[129];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }
       
            if (count1 >=134000 && count1 < 135000) {
                value2.innerText = arr[130];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }
       
            if (count1 >=135000 && count1 < 136000) {
                value2.innerText = arr[131];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }
      
            if (count1 >=136000 && count1 < 137000) {
                value2.innerText = arr[132];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }
       
            if (count1 >=137000 && count1 < 138000) {
                value2.innerText = arr[133];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }

            if (count1 >=138000 && count1 < 139000) {
                value2.innerText = arr[134];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }

            if (count1 >=139000 && count1 < 140000) {
                value2.innerText = arr[135];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }
       
            if (count1 >=140000 && count1 < 141000) {
                value2.innerText = arr[136];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }
       
            if (count1 >=141000 && count1 < 142000) {
                value2.innerText = arr[137];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }
        
            if (count1 >=142000 && count1 < 143000) {
                value2.innerText = arr[138];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }

            if (count1 >=143000 && count1 < 144000) {
                value2.innerText = arr[139];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }
       
            if (count1 >=144000 && count1 < 145000) {
                value2.innerText = arr[140];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }
        
            if (count1 >=145000 && count1 < 146000) {
                value2.innerText = arr[141];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }

            if (count1 >=146000 && count1 < 147000) {
                value2.innerText = arr[142];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }

            if (count1 >=147000 && count1 < 148000) {
                value2.innerText = arr[143];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }
       
            if (count1 >=148000 && count1 < 149000) {
                value2.innerText = arr[144];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }
       
            if (count1 >=149000 && count1 < 150000) {
                value2.innerText = arr[145];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }
            if (count1 >=150000 && count1 < 151000) {
                value2.innerText = arr[146];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }
            if (count1 >=151000 && count1 < 152000) {
                value2.innerText = arr[147];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }
       
            if (count1 >=152000 && count1 < 153000) {
                value2.innerText = arr[148];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }
            if (count1 >=153000 && count1 < 154000) {
                value2.innerText = arr[149];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }
       
            if (count1 >=154000 && count1 < 155000) {
                value2.innerText = arr[150];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }
      
            if (count1 >=155000 && count1 < 156000) {
                value2.innerText = arr[151];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }

            if (count1 >=156000 && count1 < 157000) {
                value2.innerText = arr[152];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }

            if (count1 >=157000 && count1 < 158000) {
                value2.innerText = arr[153];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }

            if (count1 >=158000 && count1 < 159000) {
                value2.innerText = arr[154];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }
       
            if (count1 >=159000 && count1 < 160000) {
                value2.innerText = arr[155];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }
        
            if (count1 >=160000 && count1 < 161000) {
                value2.innerText = arr[156];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }
       
            if (count1 >=161000 && count1 < 162000) {
                value2.innerText = arr[157];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }
            if (count1 >=162000 && count1 < 163000) {
                value2.innerText = arr[158];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }
        
            if (count1 >=163000 && count1 < 164000) {
                value2.innerText = arr[159];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }

            if (count1 >=164000 && count1 < 165000) {
                value2.innerText = arr[160];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }
       
            if (count1 >=165000 && count1 < 166000) {
                value2.innerText = arr[161];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }
       
            if (count1 >=166000 && count1 < 167000) {
                value2.innerText = arr[162];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }
       
            if (count1 >=167000 && count1 < 168000) {
                value2.innerText = arr[163];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }
        
            if (count1 >=168000 && count1 < 169000) {
                value2.innerText = arr[164];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }
       
            if (count1 >=169000 && count1 < 170000) {
                value2.innerText = arr[165];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }
    
            if (count1 >=170000 && count1 < 171000) {
                value2.innerText = arr[166];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }
       
            if (count1 >=171000 && count1 < 172000) {
                value2.innerText = arr[167];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }
        
            if (count1 >=172000 && count1 < 173000) {
                value2.innerText = arr[168];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }

            if (count1 >=173000 && count1 < 174000) {
                value2.innerText = arr[169];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }
        
            if (count1 >=174000 && count1 < 175000) {
                value2.innerText = arr[170];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }

            if (count1 >=175000 && count1 < 176000) {
                value2.innerText = arr[171];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }
        
            if (count1 >=176000 && count1 < 177000) {
                value2.innerText = arr[172];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }
        
            if (count1 >=177000 && count1 < 178000) {
                value2.innerText = arr[173];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }
        
            if (count1 >=178000 && count1 < 179000) {
                value2.innerText = arr[174];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }

            if (count1 >=179000 && count1 < 180000) {
                value2.innerText = arr[175];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }
        
            if (count1 >=180000 && count1 < 181000) {
                value2.innerText = arr[176];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }

            if (count1 >=181000 && count1 < 182000) {
                value2.innerText = arr[177];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }
        
            if (count1 >=182000 && count1 < 183000) {
                value2.innerText = arr[178];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }
       
            if (count1 >=183000 && count1 < 184000) {
                value2.innerText = arr[179];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }
       
            if (count1 >=184000 && count1 < 185000) {
                value2.innerText = arr[180];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }
       
            if (count1 >=185000 && count1 < 186000) {
                value2.innerText = arr[181];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }
    
            if (count1 >=186000 && count1 < 187000) {
                value2.innerText = arr[182];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }
        
            if (count1 >=187000 && count1 < 188000) {
                value2.innerText = arr[183];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }
       
            if (count1 >=188000 && count1 < 189000) {
                value2.innerText = arr[184];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }
       
            if (count1 >=189000 && count1 < 190000) {
                value2.innerText = arr[185];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }
        
            if (count1 >=190000 && count1 < 191000) {
                value2.innerText = arr[186];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }
        
            if (count1 >=191000 && count1 < 192000) {
                value2.innerText = arr[187];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }
       
            if (count1 >=192000 && count1 < 193000) {
                value2.innerText = arr[188];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }

            if (count1 >=193000 && count1 < 194000) {
                value2.innerText = arr[189];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }
       
            if (count1 >=194000 && count1 < 195000) {
                value2.innerText = arr[190];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }
       
            if (count1 >=195000 && count1 < 196000) {
                value2.innerText = arr[191];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }

            if (count1 >=196000 && count1 < 197000) {
                value2.innerText = arr[192];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }
        
            if (count1 >=197000 && count1 < 198000) {
                value2.innerText = arr[193];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }
       
            if (count1 >=198000 && count1 < 199000) {
                value2.innerText = arr[194];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }
       
            if (count1 >=199000 && count1 <= 200000) {
                value2.innerText = arr[195];
                let num1 = count1;
                let num2 = value2.innerText;
                const integer1 = parseInt(num1, 10);
                const integer2 = parseInt(num2, 10);
                const integer3 = 540;
                const sum = integer1 + integer2
                value3.innerText = sum;
                value4.innerText = sum;
                const benefitamount = sum - integer3;
                Benefit.innerText = benefitamount;
            }
        
            if (count1 >200000) {
               alert("Please enter a basic price between ₹3000 and ₹200000")
               section19.style.display = "none";
               section21.style.display = "none";
            }
        }
    })
}
function shownow(){
    const section18 = document.getElementsByClassName("section18")[0];
    const section19 = document.getElementsByClassName("section19")[0];
    const section21 = document.getElementsByClassName("section21")[0];
    const section23 = document.getElementsByClassName("section23")[0];
    const section24 = document.getElementsByClassName("section24")[0];
    section18.style.display="none";
    section19.style.display = "block";
    section21.style.display = "block";
    section23.style.display="block";
    section24.style.marginTop="2rem";
}
function exec(){
    const section18 = document.getElementsByClassName("section18")[0];
    const section19 = document.getElementsByClassName("section19")[0];
    const section21 = document.getElementsByClassName("section21")[0];
    const section23 = document.getElementsByClassName("section23")[0];
    const section24 = document.getElementsByClassName("section24")[0];
    section18.style.display="block";
    section18.style.display="flex";
    section19.style.display = "none";
    section21.style.display = "none";
    section23.style.display="none";
    section24.style.marginTop="22rem";
}
function backbutton(event){
    event.preventDefault();
    fetch('/back13',{
        method:"get",
        headers:{
            "Content-Type":"application/json"
        },
    })
    .then(response=>{
        if(response.redirected){
            window.location.href=response.url
        }
        else{
            throw new Error
        }
    })
    .then(data=>console.log(data))
    .catch(error=>console.error(error))
}
function nextbutton(event){
    const value1=document.getElementById("price").value.trim();
    const Pricedata = value1.replace(/,/g, "");
    event.preventDefault();
    const formdata={
        basicprice:Pricedata,
    };
        fetch('/next10',{
        method:"post",
        headers:{
            "Content-Type":"application/json"
        },
        body:JSON.stringify(formdata),
    })
    .then(response => {
        if (response.redirected) {
            window.location.href = response.url;
        } else {
            return response.json(); 
        }
    })
    .then(data=>
    {
        window.location.href = `/processing?basicprice=${(data.received)}`;
    }
    )
    .catch(error=>console.error(error))
}