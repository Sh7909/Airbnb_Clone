function fun1() {
    const section6 = document.getElementById("section6");
    const section7 = document.getElementById("section7");
    const section8 = document.getElementById("section8");
    const section9 = document.getElementById("section9");
    const section10 = document.getElementById("section10");
    const section11 = document.getElementById("section11");
    const section12 = document.getElementById("section12");
    const section13 = document.getElementById("section13");
    const section14 = document.getElementById("section14");
    const section15 = document.getElementById("section15");
    const section16 = document.getElementById("section16");
    const section17 = document.getElementById("section17");
    const section18 = document.getElementById("section18");
    const section19 = document.getElementById("section19");
    const section20 = document.getElementById("section20");
    const section21 = document.getElementById("section21");
    const section22 = document.getElementById("section22");
    const section23 = document.getElementById("section23");
    const section24 = document.getElementById("section24");
    const section25 = document.getElementById("section25");
    const section26 = document.getElementById("section26");
    const section27 = document.getElementById("section27");
    const section28 = document.getElementById("section28");
    const section29 = document.getElementById("section29");
    const section30 = document.getElementById("section30");
    const section31 = document.getElementById("section31");
    const section32 = document.getElementById("section32");
    const section33 = document.getElementById("section33");
    const section34 = document.getElementById("section34");
    const section35 = document.getElementById("section35");
    const section36 = document.getElementById("section36");
    const section37 = document.getElementsByClassName("section37")[0];
    section6.style.border = "3px solid black";
    section7.style.border = "2px solid rgb(216, 211, 211)";
    section8.style.border = "2px solid rgb(216, 211, 211)";
    section9.style.border = "2px solid rgb(216, 211, 211)";
    section10.style.border = "2px solid rgb(216, 211, 211)";
    section11.style.border = "2px solid rgb(216, 211, 211)";
    section12.style.border = "2px solid rgb(216, 211, 211)";
    section13.style.border = "2px solid rgb(216, 211, 211)";
    section14.style.border = "2px solid rgb(216, 211, 211)";
    section15.style.border = "2px solid rgb(216, 211, 211)";
    section16.style.border = "2px solid rgb(216, 211, 211)";
    section17.style.border = "2px solid rgb(216, 211, 211)";
    section18.style.border = "2px solid rgb(216, 211, 211)";
    section19.style.border = "2px solid rgb(216, 211, 211)";
    section20.style.border = "2px solid rgb(216, 211, 211)";
    section21.style.border = "2px solid rgb(216, 211, 211)";
    section22.style.border = "2px solid rgb(216, 211, 211)";
    section23.style.border = "2px solid rgb(216, 211, 211)";
    section24.style.border = "2px solid rgb(216, 211, 211)";
    section25.style.border = "2px solid rgb(216, 211, 211)";
    section26.style.border = "2px solid rgb(216, 211, 211)";
    section27.style.border = "2px solid rgb(216, 211, 211)";
    section28.style.border = "2px solid rgb(216, 211, 211)";
    section29.style.border = "2px solid rgb(216, 211, 211)";
    section30.style.border = "2px solid rgb(216, 211, 211)";
    section31.style.border = "2px solid rgb(216, 211, 211)";
    section32.style.border = "2px solid rgb(216, 211, 211)";
    section33.style.border = "2px solid rgb(216, 211, 211)";
    section34.style.border = "2px solid rgb(216, 211, 211)";
    section35.style.border = "2px solid rgb(216, 211, 211)";
    section36.style.border = "2px solid rgb(216, 211, 211)";
    section37.style.backgroundColor = "black";
    section37.style.cursor = "pointer";
    section37.onmouseover = () => {
        section37.style.cursor = "pointer"
    }
    section37.onmouseout = () => {
        section37.style.cursor = "pointer"
    }
    section6.onmouseover=()=>{
        section6.style.border="3px solid black";
    }
    section6.onmouseout=()=>{
        section6.style.border="3px solid black";
    }
    section7.onmouseover=()=>{
        section7.style.border="3px solid black";
    }
    section7.onmouseout=()=>{
        section7.style.border="2px solid rgb(216, 211, 211)";
    }
    section8.onmouseover=()=>{
        section8.style.border="3px solid black";
    }
    section8.onmouseout=()=>{
        section8.style.border="2px solid rgb(216, 211, 211)";
    }
    section9.onmouseover=()=>{
        section9.style.border="3px solid black";
    }
    section9.onmouseout=()=>{
        section9.style.border="2px solid rgb(216, 211, 211)";
    }
    section10.onmouseover=()=>{
        section10.style.border="3px solid black";
    }
    section10.onmouseout=()=>{
        section10.style.border="2px solid rgb(216, 211, 211)";
    }
    section11.onmouseover=()=>{
        section11.style.border="3px solid black";
    }
    section11.onmouseout=()=>{
        section11.style.border="2px solid rgb(216, 211, 211)";
    }
    section12.onmouseover=()=>{
        section12.style.border="3px solid black";
    }
    section12.onmouseout=()=>{
        section12.style.border="2px solid rgb(216, 211, 211)";
    }
    section13.onmouseover=()=>{
        section13.style.border="3px solid black";
    }
    section13.onmouseout=()=>{
        section13.style.border="2px solid rgb(216, 211, 211)";
    }
    section14.onmouseover=()=>{
        section14.style.border="3px solid black";
    }
    section14.onmouseout=()=>{
        section14.style.border="2px solid rgb(216, 211, 211)";
    }
    section15.onmouseover=()=>{
        section15.style.border="3px solid black";
    }
    section15.onmouseout=()=>{
        section15.style.border="2px solid rgb(216, 211, 211)";
    }
    section16.onmouseover=()=>{
        section16.style.border="3px solid black";
    }
    section16.onmouseout=()=>{
        section16.style.border="2px solid rgb(216, 211, 211)";
    }
    section17.onmouseover=()=>{
        section17.style.border="3px solid black";
    }
    section17.onmouseout=()=>{
        section17.style.border="2px solid rgb(216, 211, 211)";
    }
    section18.onmouseover=()=>{
        section18.style.border="3px solid black";
    }
    section18.onmouseout=()=>{
        section18.style.border="2px solid rgb(216, 211, 211)";
    }
    section19.onmouseover=()=>{
        section19.style.border="3px solid black";
    }
    section19.onmouseout=()=>{
        section19.style.border="2px solid rgb(216, 211, 211)";
    }
    section20.onmouseover=()=>{
        section20.style.border="3px solid black";
    }
    section20.onmouseout=()=>{
        section20.style.border="2px solid rgb(216, 211, 211)";
    }
    section21.onmouseover=()=>{
        section21.style.border="3px solid black";
    }
    section21.onmouseout=()=>{
        section21.style.border="2px solid rgb(216, 211, 211)";
    }
    section22.onmouseover=()=>{
        section22.style.border="3px solid black";
    }
    section22.onmouseout=()=>{
        section22.style.border="2px solid rgb(216, 211, 211)";
    }
    section23.onmouseover=()=>{
        section23.style.border="3px solid black";
    }
    section23.onmouseout=()=>{
        section23.style.border="2px solid rgb(216, 211, 211)";
    }
    section24.onmouseover=()=>{
        section24.style.border="3px solid black";
    }
    section24.onmouseout=()=>{
        section24.style.border="2px solid rgb(216, 211, 211)";
    }
    section25.onmouseover=()=>{
        section25.style.border="3px solid black";
    }
    section25.onmouseout=()=>{
        section25.style.border="2px solid rgb(216, 211, 211)";
    }
    section26.onmouseover=()=>{
        section26.style.border="3px solid black";
    }
    section26.onmouseout=()=>{
        section26.style.border="2px solid rgb(216, 211, 211)";
    }
    section27.onmouseover=()=>{
        section27.style.border="3px solid black";
    }
    section27.onmouseout=()=>{
        section27.style.border="2px solid rgb(216, 211, 211)";
    }
    section28.onmouseover=()=>{
        section28.style.border="3px solid black";
    }
    section28.onmouseout=()=>{
        section28.style.border="2px solid rgb(216, 211, 211)";
    }
    section29.onmouseover=()=>{
        section29.style.border="3px solid black";
    }
    section29.onmouseout=()=>{
        section29.style.border="2px solid rgb(216, 211, 211)";
    }
    section30.onmouseover=()=>{
        section30.style.border="3px solid black";
    }
    section30.onmouseout=()=>{
        section30.style.border="2px solid rgb(216, 211, 211)";
    }
    section31.onmouseover=()=>{
        section31.style.border="3px solid black";
    }
    section31.onmouseout=()=>{
        section31.style.border="2px solid rgb(216, 211, 211)";
    }
    section32.onmouseover=()=>{
        section32.style.border="3px solid black";
    }
    section32.onmouseout=()=>{
        section32.style.border="2px solid rgb(216, 211, 211)";
    }
    section33.onmouseover=()=>{
        section33.style.border="3px solid black";
    }
    section33.onmouseout=()=>{
        section33.style.border="2px solid rgb(216, 211, 211)";
    }
    section34.onmouseover=()=>{
        section34.style.border="3px solid black";
    }
    section34.onmouseout=()=>{
        section34.style.border="2px solid rgb(216, 211, 211)";
    }
    section35.onmouseover=()=>{
        section35.style.border="3px solid black";
    }
    section35.onmouseout=()=>{
        section35.style.border="2px solid rgb(216, 211, 211)";
    }
    section36.onmouseover=()=>{
        section36.style.border="3px solid black";
    }
    section36.onmouseout=()=>{
        section36.style.border="2px solid rgb(216, 211, 211)";
    }
}
function fun2() {
    const section6 = document.getElementById("section6");
    const section7 = document.getElementById("section7");
    const section8 = document.getElementById("section8");
    const section9 = document.getElementById("section9");
    const section10 = document.getElementById("section10");
    const section11 = document.getElementById("section11");
    const section12 = document.getElementById("section12");
    const section13 = document.getElementById("section13");
    const section14 = document.getElementById("section14");
    const section15 = document.getElementById("section15");
    const section16 = document.getElementById("section16");
    const section17 = document.getElementById("section17");
    const section18 = document.getElementById("section18");
    const section19 = document.getElementById("section19");
    const section20 = document.getElementById("section20");
    const section21 = document.getElementById("section21");
    const section22 = document.getElementById("section22");
    const section23 = document.getElementById("section23");
    const section24 = document.getElementById("section24");
    const section25 = document.getElementById("section25");
    const section26 = document.getElementById("section26");
    const section27 = document.getElementById("section27");
    const section28 = document.getElementById("section28");
    const section29 = document.getElementById("section29");
    const section30 = document.getElementById("section30");
    const section31 = document.getElementById("section31");
    const section32 = document.getElementById("section32");
    const section33 = document.getElementById("section33");
    const section34 = document.getElementById("section34");
    const section35 = document.getElementById("section35");
    const section36 = document.getElementById("section36");
    const section37 = document.getElementsByClassName("section37")[0];
    section6.style.border = "2px solid rgb(216, 211, 211)";
    section7.style.border = "3px solid black";
    section8.style.border = "2px solid rgb(216, 211, 211)";
    section9.style.border = "2px solid rgb(216, 211, 211)";
    section10.style.border = "2px solid rgb(216, 211, 211)";
    section11.style.border = "2px solid rgb(216, 211, 211)";
    section12.style.border = "2px solid rgb(216, 211, 211)";
    section13.style.border = "2px solid rgb(216, 211, 211)";
    section14.style.border = "2px solid rgb(216, 211, 211)";
    section15.style.border = "2px solid rgb(216, 211, 211)";
    section16.style.border = "2px solid rgb(216, 211, 211)";
    section17.style.border = "2px solid rgb(216, 211, 211)";
    section18.style.border = "2px solid rgb(216, 211, 211)";
    section19.style.border = "2px solid rgb(216, 211, 211)";
    section20.style.border = "2px solid rgb(216, 211, 211)";
    section21.style.border = "2px solid rgb(216, 211, 211)";
    section22.style.border = "2px solid rgb(216, 211, 211)";
    section23.style.border = "2px solid rgb(216, 211, 211)";
    section24.style.border = "2px solid rgb(216, 211, 211)";
    section25.style.border = "2px solid rgb(216, 211, 211)";
    section26.style.border = "2px solid rgb(216, 211, 211)";
    section27.style.border = "2px solid rgb(216, 211, 211)";
    section28.style.border = "2px solid rgb(216, 211, 211)";
    section29.style.border = "2px solid rgb(216, 211, 211)";
    section30.style.border = "2px solid rgb(216, 211, 211)";
    section31.style.border = "2px solid rgb(216, 211, 211)";
    section32.style.border = "2px solid rgb(216, 211, 211)";
    section33.style.border = "2px solid rgb(216, 211, 211)";
    section34.style.border = "2px solid rgb(216, 211, 211)";
    section35.style.border = "2px solid rgb(216, 211, 211)";
    section36.style.border = "2px solid rgb(216, 211, 211)";
    section37.style.backgroundColor = "black";
    section37.style.cursor = "pointer";
    section37.onmouseover = () => {
        section37.style.cursor = "pointer"
    }
    section37.onmouseout = () => {
        section37.style.cursor = "pointer"
    }
    section6.onmouseover=()=>{
        section6.style.border="3px solid black";
    }
    section6.onmouseout=()=>{
        section6.style.border="2px solid rgb(216, 211, 211)";
    }
    section7.onmouseover=()=>{
        section7.style.border="3px solid black";
    }
    section7.onmouseout=()=>{
        section7.style.border="3px solid black";
    }
    section8.onmouseover=()=>{
        section8.style.border="3px solid black";
    }
    section8.onmouseout=()=>{
        section8.style.border="2px solid rgb(216, 211, 211)";
    }
    section9.onmouseover=()=>{
        section9.style.border="3px solid black";
    }
    section9.onmouseout=()=>{
        section9.style.border="2px solid rgb(216, 211, 211)";
    }
    section10.onmouseover=()=>{
        section10.style.border="3px solid black";
    }
    section10.onmouseout=()=>{
        section10.style.border="2px solid rgb(216, 211, 211)";
    }
    section11.onmouseover=()=>{
        section11.style.border="3px solid black";
    }
    section11.onmouseout=()=>{
        section11.style.border="2px solid rgb(216, 211, 211)";
    }
    section12.onmouseover=()=>{
        section12.style.border="3px solid black";
    }
    section12.onmouseout=()=>{
        section12.style.border="2px solid rgb(216, 211, 211)";
    }
    section13.onmouseover=()=>{
        section13.style.border="3px solid black";
    }
    section13.onmouseout=()=>{
        section13.style.border="2px solid rgb(216, 211, 211)";
    }
    section14.onmouseover=()=>{
        section14.style.border="3px solid black";
    }
    section14.onmouseout=()=>{
        section14.style.border="2px solid rgb(216, 211, 211)";
    }
    section15.onmouseover=()=>{
        section15.style.border="3px solid black";
    }
    section15.onmouseout=()=>{
        section15.style.border="2px solid rgb(216, 211, 211)";
    }
    section16.onmouseover=()=>{
        section16.style.border="3px solid black";
    }
    section16.onmouseout=()=>{
        section16.style.border="2px solid rgb(216, 211, 211)";
    }
    section17.onmouseover=()=>{
        section17.style.border="3px solid black";
    }
    section17.onmouseout=()=>{
        section17.style.border="2px solid rgb(216, 211, 211)";
    }
    section18.onmouseover=()=>{
        section18.style.border="3px solid black";
    }
    section18.onmouseout=()=>{
        section18.style.border="2px solid rgb(216, 211, 211)";
    }
    section19.onmouseover=()=>{
        section19.style.border="3px solid black";
    }
    section19.onmouseout=()=>{
        section19.style.border="2px solid rgb(216, 211, 211)";
    }
    section20.onmouseover=()=>{
        section20.style.border="3px solid black";
    }
    section20.onmouseout=()=>{
        section20.style.border="2px solid rgb(216, 211, 211)";
    }
    section21.onmouseover=()=>{
        section21.style.border="3px solid black";
    }
    section21.onmouseout=()=>{
        section21.style.border="2px solid rgb(216, 211, 211)";
    }
    section22.onmouseover=()=>{
        section22.style.border="3px solid black";
    }
    section22.onmouseout=()=>{
        section22.style.border="2px solid rgb(216, 211, 211)";
    }
    section23.onmouseover=()=>{
        section23.style.border="3px solid black";
    }
    section23.onmouseout=()=>{
        section23.style.border="2px solid rgb(216, 211, 211)";
    }
    section24.onmouseover=()=>{
        section24.style.border="3px solid black";
    }
    section24.onmouseout=()=>{
        section24.style.border="2px solid rgb(216, 211, 211)";
    }
    section25.onmouseover=()=>{
        section25.style.border="3px solid black";
    }
    section25.onmouseout=()=>{
        section25.style.border="2px solid rgb(216, 211, 211)";
    }
    section26.onmouseover=()=>{
        section26.style.border="3px solid black";
    }
    section26.onmouseout=()=>{
        section26.style.border="2px solid rgb(216, 211, 211)";
    }
    section27.onmouseover=()=>{
        section27.style.border="3px solid black";
    }
    section27.onmouseout=()=>{
        section27.style.border="2px solid rgb(216, 211, 211)";
    }
    section28.onmouseover=()=>{
        section28.style.border="3px solid black";
    }
    section28.onmouseout=()=>{
        section28.style.border="2px solid rgb(216, 211, 211)";
    }
    section29.onmouseover=()=>{
        section29.style.border="3px solid black";
    }
    section29.onmouseout=()=>{
        section29.style.border="2px solid rgb(216, 211, 211)";
    }
    section30.onmouseover=()=>{
        section30.style.border="3px solid black";
    }
    section30.onmouseout=()=>{
        section30.style.border="2px solid rgb(216, 211, 211)";
    }
    section31.onmouseover=()=>{
        section31.style.border="3px solid black";
    }
    section31.onmouseout=()=>{
        section31.style.border="2px solid rgb(216, 211, 211)";
    }
    section32.onmouseover=()=>{
        section32.style.border="3px solid black";
    }
    section32.onmouseout=()=>{
        section32.style.border="2px solid rgb(216, 211, 211)";
    }
    section33.onmouseover=()=>{
        section33.style.border="3px solid black";
    }
    section33.onmouseout=()=>{
        section33.style.border="2px solid rgb(216, 211, 211)";
    }
    section34.onmouseover=()=>{
        section34.style.border="3px solid black";
    }
    section34.onmouseout=()=>{
        section34.style.border="2px solid rgb(216, 211, 211)";
    }
    section35.onmouseover=()=>{
        section35.style.border="3px solid black";
    }
    section35.onmouseout=()=>{
        section35.style.border="2px solid rgb(216, 211, 211)";
    }
    section36.onmouseover=()=>{
        section36.style.border="3px solid black";
    }
    section36.onmouseout=()=>{
        section36.style.border="2px solid rgb(216, 211, 211)";
    }
}
function fun3() {
    const section6 = document.getElementById("section6");
    const section7 = document.getElementById("section7");
    const section8 = document.getElementById("section8");
    const section9 = document.getElementById("section9");
    const section10 = document.getElementById("section10");
    const section11 = document.getElementById("section11");
    const section12 = document.getElementById("section12");
    const section13 = document.getElementById("section13");
    const section14 = document.getElementById("section14");
    const section15 = document.getElementById("section15");
    const section16 = document.getElementById("section16");
    const section17 = document.getElementById("section17");
    const section18 = document.getElementById("section18");
    const section19 = document.getElementById("section19");
    const section20 = document.getElementById("section20");
    const section21 = document.getElementById("section21");
    const section22 = document.getElementById("section22");
    const section23 = document.getElementById("section23");
    const section24 = document.getElementById("section24");
    const section25 = document.getElementById("section25");
    const section26 = document.getElementById("section26");
    const section27 = document.getElementById("section27");
    const section28 = document.getElementById("section28");
    const section29 = document.getElementById("section29");
    const section30 = document.getElementById("section30");
    const section31 = document.getElementById("section31");
    const section32 = document.getElementById("section32");
    const section33 = document.getElementById("section33");
    const section34 = document.getElementById("section34");
    const section35 = document.getElementById("section35");
    const section36 = document.getElementById("section36");
    const section37 = document.getElementsByClassName("section37")[0];
    section6.style.border = "2px solid rgb(216, 211, 211)";
    section7.style.border = "2px solid rgb(216, 211, 211)";
    section8.style.border = "3px solid black";
    section9.style.border = "2px solid rgb(216, 211, 211)";
    section10.style.border = "2px solid rgb(216, 211, 211)";
    section11.style.border = "2px solid rgb(216, 211, 211)";
    section12.style.border = "2px solid rgb(216, 211, 211)";
    section13.style.border = "2px solid rgb(216, 211, 211)";
    section14.style.border = "2px solid rgb(216, 211, 211)";
    section15.style.border = "2px solid rgb(216, 211, 211)";
    section16.style.border = "2px solid rgb(216, 211, 211)";
    section17.style.border = "2px solid rgb(216, 211, 211)";
    section18.style.border = "2px solid rgb(216, 211, 211)";
    section19.style.border = "2px solid rgb(216, 211, 211)";
    section20.style.border = "2px solid rgb(216, 211, 211)";
    section21.style.border = "2px solid rgb(216, 211, 211)";
    section22.style.border = "2px solid rgb(216, 211, 211)";
    section23.style.border = "2px solid rgb(216, 211, 211)";
    section24.style.border = "2px solid rgb(216, 211, 211)";
    section25.style.border = "2px solid rgb(216, 211, 211)";
    section26.style.border = "2px solid rgb(216, 211, 211)";
    section27.style.border = "2px solid rgb(216, 211, 211)";
    section28.style.border = "2px solid rgb(216, 211, 211)";
    section29.style.border = "2px solid rgb(216, 211, 211)";
    section30.style.border = "2px solid rgb(216, 211, 211)";
    section31.style.border = "2px solid rgb(216, 211, 211)";
    section32.style.border = "2px solid rgb(216, 211, 211)";
    section33.style.border = "2px solid rgb(216, 211, 211)";
    section34.style.border = "2px solid rgb(216, 211, 211)";
    section35.style.border = "2px solid rgb(216, 211, 211)";
    section36.style.border = "2px solid rgb(216, 211, 211)";
    section37.style.backgroundColor = "black";
    section37.style.cursor = "pointer";
    section37.onmouseover = () => {
        section37.style.cursor = "pointer"
    }
    section37.onmouseout = () => {
        section37.style.cursor = "pointer"
    }
    section6.onmouseover=()=>{
        section6.style.border="3px solid black";
    }
    section6.onmouseout=()=>{
        section6.style.border="2px solid rgb(216, 211, 211)";
    }
    section7.onmouseover=()=>{
        section7.style.border="3px solid black";
    }
    section7.onmouseout=()=>{
        section7.style.border="2px solid rgb(216, 211, 211)";
    }
    section8.onmouseover=()=>{
        section8.style.border="3px solid black";
    }
    section8.onmouseout=()=>{
        section8.style.border="3px solid black";
    }
    section9.onmouseover=()=>{
        section9.style.border="3px solid black";
    }
    section9.onmouseout=()=>{
        section9.style.border="2px solid rgb(216, 211, 211)";
    }
    section10.onmouseover=()=>{
        section10.style.border="3px solid black";
    }
    section10.onmouseout=()=>{
        section10.style.border="2px solid rgb(216, 211, 211)";
    }
    section11.onmouseover=()=>{
        section11.style.border="3px solid black";
    }
    section11.onmouseout=()=>{
        section11.style.border="2px solid rgb(216, 211, 211)";
    }
    section12.onmouseover=()=>{
        section12.style.border="3px solid black";
    }
    section12.onmouseout=()=>{
        section12.style.border="2px solid rgb(216, 211, 211)";
    }
    section13.onmouseover=()=>{
        section13.style.border="3px solid black";
    }
    section13.onmouseout=()=>{
        section13.style.border="2px solid rgb(216, 211, 211)";
    }
    section14.onmouseover=()=>{
        section14.style.border="3px solid black";
    }
    section14.onmouseout=()=>{
        section14.style.border="2px solid rgb(216, 211, 211)";
    }
    section15.onmouseover=()=>{
        section15.style.border="3px solid black";
    }
    section15.onmouseout=()=>{
        section15.style.border="2px solid rgb(216, 211, 211)";
    }
    section16.onmouseover=()=>{
        section16.style.border="3px solid black";
    }
    section16.onmouseout=()=>{
        section16.style.border="2px solid rgb(216, 211, 211)";
    }
    section17.onmouseover=()=>{
        section17.style.border="3px solid black";
    }
    section17.onmouseout=()=>{
        section17.style.border="2px solid rgb(216, 211, 211)";
    }
    section18.onmouseover=()=>{
        section18.style.border="3px solid black";
    }
    section18.onmouseout=()=>{
        section18.style.border="2px solid rgb(216, 211, 211)";
    }
    section19.onmouseover=()=>{
        section19.style.border="3px solid black";
    }
    section19.onmouseout=()=>{
        section19.style.border="2px solid rgb(216, 211, 211)";
    }
    section20.onmouseover=()=>{
        section20.style.border="3px solid black";
    }
    section20.onmouseout=()=>{
        section20.style.border="2px solid rgb(216, 211, 211)";
    }
    section21.onmouseover=()=>{
        section21.style.border="3px solid black";
    }
    section21.onmouseout=()=>{
        section21.style.border="2px solid rgb(216, 211, 211)";
    }
    section22.onmouseover=()=>{
        section22.style.border="3px solid black";
    }
    section22.onmouseout=()=>{
        section22.style.border="2px solid rgb(216, 211, 211)";
    }
    section23.onmouseover=()=>{
        section23.style.border="3px solid black";
    }
    section23.onmouseout=()=>{
        section23.style.border="2px solid rgb(216, 211, 211)";
    }
    section24.onmouseover=()=>{
        section24.style.border="3px solid black";
    }
    section24.onmouseout=()=>{
        section24.style.border="2px solid rgb(216, 211, 211)";
    }
    section25.onmouseover=()=>{
        section25.style.border="3px solid black";
    }
    section25.onmouseout=()=>{
        section25.style.border="2px solid rgb(216, 211, 211)";
    }
    section26.onmouseover=()=>{
        section26.style.border="3px solid black";
    }
    section26.onmouseout=()=>{
        section26.style.border="2px solid rgb(216, 211, 211)";
    }
    section27.onmouseover=()=>{
        section27.style.border="3px solid black";
    }
    section27.onmouseout=()=>{
        section27.style.border="2px solid rgb(216, 211, 211)";
    }
    section28.onmouseover=()=>{
        section28.style.border="3px solid black";
    }
    section28.onmouseout=()=>{
        section28.style.border="2px solid rgb(216, 211, 211)";
    }
    section29.onmouseover=()=>{
        section29.style.border="3px solid black";
    }
    section29.onmouseout=()=>{
        section29.style.border="2px solid rgb(216, 211, 211)";
    }
    section30.onmouseover=()=>{
        section30.style.border="3px solid black";
    }
    section30.onmouseout=()=>{
        section30.style.border="2px solid rgb(216, 211, 211)";
    }
    section31.onmouseover=()=>{
        section31.style.border="3px solid black";
    }
    section31.onmouseout=()=>{
        section31.style.border="2px solid rgb(216, 211, 211)";
    }
    section32.onmouseover=()=>{
        section32.style.border="3px solid black";
    }
    section32.onmouseout=()=>{
        section32.style.border="2px solid rgb(216, 211, 211)";
    }
    section33.onmouseover=()=>{
        section33.style.border="3px solid black";
    }
    section33.onmouseout=()=>{
        section33.style.border="2px solid rgb(216, 211, 211)";
    }
    section34.onmouseover=()=>{
        section34.style.border="3px solid black";
    }
    section34.onmouseout=()=>{
        section34.style.border="2px solid rgb(216, 211, 211)";
    }
    section35.onmouseover=()=>{
        section35.style.border="3px solid black";
    }
    section35.onmouseout=()=>{
        section35.style.border="2px solid rgb(216, 211, 211)";
    }
    section36.onmouseover=()=>{
        section36.style.border="3px solid black";
    }
    section36.onmouseout=()=>{
        section36.style.border="2px solid rgb(216, 211, 211)";
    }
}
function fun4() {
    const section6 = document.getElementById("section6");
    const section7 = document.getElementById("section7");
    const section8 = document.getElementById("section8");
    const section9 = document.getElementById("section9");
    const section10 = document.getElementById("section10");
    const section11 = document.getElementById("section11");
    const section12 = document.getElementById("section12");
    const section13 = document.getElementById("section13");
    const section14 = document.getElementById("section14");
    const section15 = document.getElementById("section15");
    const section16 = document.getElementById("section16");
    const section17 = document.getElementById("section17");
    const section18 = document.getElementById("section18");
    const section19 = document.getElementById("section19");
    const section20 = document.getElementById("section20");
    const section21 = document.getElementById("section21");
    const section22 = document.getElementById("section22");
    const section23 = document.getElementById("section23");
    const section24 = document.getElementById("section24");
    const section25 = document.getElementById("section25");
    const section26 = document.getElementById("section26");
    const section27 = document.getElementById("section27");
    const section28 = document.getElementById("section28");
    const section29 = document.getElementById("section29");
    const section30 = document.getElementById("section30");
    const section31 = document.getElementById("section31");
    const section32 = document.getElementById("section32");
    const section33 = document.getElementById("section33");
    const section34 = document.getElementById("section34");
    const section35 = document.getElementById("section35");
    const section36 = document.getElementById("section36");
    const section37 = document.getElementsByClassName("section37")[0];
    section6.style.border = "2px solid rgb(216, 211, 211)";
    section7.style.border = "2px solid rgb(216, 211, 211)";
    section8.style.border = "2px solid rgb(216, 211, 211)";
    section9.style.border = "3px solid black";
    section10.style.border = "2px solid rgb(216, 211, 211)";
    section11.style.border = "2px solid rgb(216, 211, 211)";
    section12.style.border = "2px solid rgb(216, 211, 211)";
    section13.style.border = "2px solid rgb(216, 211, 211)";
    section14.style.border = "2px solid rgb(216, 211, 211)";
    section15.style.border = "2px solid rgb(216, 211, 211)";
    section16.style.border = "2px solid rgb(216, 211, 211)";
    section17.style.border = "2px solid rgb(216, 211, 211)";
    section18.style.border = "2px solid rgb(216, 211, 211)";
    section19.style.border = "2px solid rgb(216, 211, 211)";
    section20.style.border = "2px solid rgb(216, 211, 211)";
    section21.style.border = "2px solid rgb(216, 211, 211)";
    section22.style.border = "2px solid rgb(216, 211, 211)";
    section23.style.border = "2px solid rgb(216, 211, 211)";
    section24.style.border = "2px solid rgb(216, 211, 211)";
    section25.style.border = "2px solid rgb(216, 211, 211)";
    section26.style.border = "2px solid rgb(216, 211, 211)";
    section27.style.border = "2px solid rgb(216, 211, 211)";
    section28.style.border = "2px solid rgb(216, 211, 211)";
    section29.style.border = "2px solid rgb(216, 211, 211)";
    section30.style.border = "2px solid rgb(216, 211, 211)";
    section31.style.border = "2px solid rgb(216, 211, 211)";
    section32.style.border = "2px solid rgb(216, 211, 211)";
    section33.style.border = "2px solid rgb(216, 211, 211)";
    section34.style.border = "2px solid rgb(216, 211, 211)";
    section35.style.border = "2px solid rgb(216, 211, 211)";
    section36.style.border = "2px solid rgb(216, 211, 211)";
    section37.style.backgroundColor = "black";
    section37.style.cursor = "pointer";
    section37.onmouseover = () => {
        section37.style.cursor = "pointer"
    }
    section37.onmouseout = () => {
        section37.style.cursor = "pointer"
    }
    section6.onmouseover=()=>{
        section6.style.border="3px solid black";
    }
    section6.onmouseout=()=>{
        section6.style.border="2px solid rgb(216, 211, 211)";
    }
    section7.onmouseover=()=>{
        section7.style.border="3px solid black";
    }
    section7.onmouseout=()=>{
        section7.style.border="2px solid rgb(216, 211, 211)";
    }
    section8.onmouseover=()=>{
        section8.style.border="3px solid black";
    }
    section8.onmouseout=()=>{
        section8.style.border="2px solid rgb(216, 211, 211)";
    }
    section9.onmouseover=()=>{
        section9.style.border="3px solid black";
    }
    section9.onmouseout=()=>{
        section9.style.border="3px solid black";
    }
    section10.onmouseover=()=>{
        section10.style.border="3px solid black";
    }
    section10.onmouseout=()=>{
        section10.style.border="2px solid rgb(216, 211, 211)";
    }
    section11.onmouseover=()=>{
        section11.style.border="3px solid black";
    }
    section11.onmouseout=()=>{
        section11.style.border="2px solid rgb(216, 211, 211)";
    }
    section12.onmouseover=()=>{
        section12.style.border="3px solid black";
    }
    section12.onmouseout=()=>{
        section12.style.border="2px solid rgb(216, 211, 211)";
    }
    section13.onmouseover=()=>{
        section13.style.border="3px solid black";
    }
    section13.onmouseout=()=>{
        section13.style.border="2px solid rgb(216, 211, 211)";
    }
    section14.onmouseover=()=>{
        section14.style.border="3px solid black";
    }
    section14.onmouseout=()=>{
        section14.style.border="2px solid rgb(216, 211, 211)";
    }
    section15.onmouseover=()=>{
        section15.style.border="3px solid black";
    }
    section15.onmouseout=()=>{
        section15.style.border="2px solid rgb(216, 211, 211)";
    }
    section16.onmouseover=()=>{
        section16.style.border="3px solid black";
    }
    section16.onmouseout=()=>{
        section16.style.border="2px solid rgb(216, 211, 211)";
    }
    section17.onmouseover=()=>{
        section17.style.border="3px solid black";
    }
    section17.onmouseout=()=>{
        section17.style.border="2px solid rgb(216, 211, 211)";
    }
    section18.onmouseover=()=>{
        section18.style.border="3px solid black";
    }
    section18.onmouseout=()=>{
        section18.style.border="2px solid rgb(216, 211, 211)";
    }
    section19.onmouseover=()=>{
        section19.style.border="3px solid black";
    }
    section19.onmouseout=()=>{
        section19.style.border="2px solid rgb(216, 211, 211)";
    }
    section20.onmouseover=()=>{
        section20.style.border="3px solid black";
    }
    section20.onmouseout=()=>{
        section20.style.border="2px solid rgb(216, 211, 211)";
    }
    section21.onmouseover=()=>{
        section21.style.border="3px solid black";
    }
    section21.onmouseout=()=>{
        section21.style.border="2px solid rgb(216, 211, 211)";
    }
    section22.onmouseover=()=>{
        section22.style.border="3px solid black";
    }
    section22.onmouseout=()=>{
        section22.style.border="2px solid rgb(216, 211, 211)";
    }
    section23.onmouseover=()=>{
        section23.style.border="3px solid black";
    }
    section23.onmouseout=()=>{
        section23.style.border="2px solid rgb(216, 211, 211)";
    }
    section24.onmouseover=()=>{
        section24.style.border="3px solid black";
    }
    section24.onmouseout=()=>{
        section24.style.border="2px solid rgb(216, 211, 211)";
    }
    section25.onmouseover=()=>{
        section25.style.border="3px solid black";
    }
    section25.onmouseout=()=>{
        section25.style.border="2px solid rgb(216, 211, 211)";
    }
    section26.onmouseover=()=>{
        section26.style.border="3px solid black";
    }
    section26.onmouseout=()=>{
        section26.style.border="2px solid rgb(216, 211, 211)";
    }
    section27.onmouseover=()=>{
        section27.style.border="3px solid black";
    }
    section27.onmouseout=()=>{
        section27.style.border="2px solid rgb(216, 211, 211)";
    }
    section28.onmouseover=()=>{
        section28.style.border="3px solid black";
    }
    section28.onmouseout=()=>{
        section28.style.border="2px solid rgb(216, 211, 211)";
    }
    section29.onmouseover=()=>{
        section29.style.border="3px solid black";
    }
    section29.onmouseout=()=>{
        section29.style.border="2px solid rgb(216, 211, 211)";
    }
    section30.onmouseover=()=>{
        section30.style.border="3px solid black";
    }
    section30.onmouseout=()=>{
        section30.style.border="2px solid rgb(216, 211, 211)";
    }
    section31.onmouseover=()=>{
        section31.style.border="3px solid black";
    }
    section31.onmouseout=()=>{
        section31.style.border="2px solid rgb(216, 211, 211)";
    }
    section32.onmouseover=()=>{
        section32.style.border="3px solid black";
    }
    section32.onmouseout=()=>{
        section32.style.border="2px solid rgb(216, 211, 211)";
    }
    section33.onmouseover=()=>{
        section33.style.border="3px solid black";
    }
    section33.onmouseout=()=>{
        section33.style.border="2px solid rgb(216, 211, 211)";
    }
    section34.onmouseover=()=>{
        section34.style.border="3px solid black";
    }
    section34.onmouseout=()=>{
        section34.style.border="2px solid rgb(216, 211, 211)";
    }
    section35.onmouseover=()=>{
        section35.style.border="3px solid black";
    }
    section35.onmouseout=()=>{
        section35.style.border="2px solid rgb(216, 211, 211)";
    }
    section36.onmouseover=()=>{
        section36.style.border="3px solid black";
    }
    section36.onmouseout=()=>{
        section36.style.border="2px solid rgb(216, 211, 211)";
    }
}
function fun5() {
    const section6 = document.getElementById("section6");
    const section7 = document.getElementById("section7");
    const section8 = document.getElementById("section8");
    const section9 = document.getElementById("section9");
    const section10 = document.getElementById("section10");
    const section11 = document.getElementById("section11");
    const section12 = document.getElementById("section12");
    const section13 = document.getElementById("section13");
    const section14 = document.getElementById("section14");
    const section15 = document.getElementById("section15");
    const section16 = document.getElementById("section16");
    const section17 = document.getElementById("section17");
    const section18 = document.getElementById("section18");
    const section19 = document.getElementById("section19");
    const section20 = document.getElementById("section20");
    const section21 = document.getElementById("section21");
    const section22 = document.getElementById("section22");
    const section23 = document.getElementById("section23");
    const section24 = document.getElementById("section24");
    const section25 = document.getElementById("section25");
    const section26 = document.getElementById("section26");
    const section27 = document.getElementById("section27");
    const section28 = document.getElementById("section28");
    const section29 = document.getElementById("section29");
    const section30 = document.getElementById("section30");
    const section31 = document.getElementById("section31");
    const section32 = document.getElementById("section32");
    const section33 = document.getElementById("section33");
    const section34 = document.getElementById("section34");
    const section35 = document.getElementById("section35");
    const section36 = document.getElementById("section36");
    const section37 = document.getElementsByClassName("section37")[0];
    section6.style.border = "2px solid rgb(216, 211, 211)";
    section7.style.border = "2px solid rgb(216, 211, 211)";
    section8.style.border = "2px solid rgb(216, 211, 211)";
    section9.style.border = "2px solid rgb(216, 211, 211)";
    section10.style.border = "3px solid black";
    section11.style.border = "2px solid rgb(216, 211, 211)";
    section12.style.border = "2px solid rgb(216, 211, 211)";
    section13.style.border = "2px solid rgb(216, 211, 211)";
    section14.style.border = "2px solid rgb(216, 211, 211)";
    section15.style.border = "2px solid rgb(216, 211, 211)";
    section16.style.border = "2px solid rgb(216, 211, 211)";
    section17.style.border = "2px solid rgb(216, 211, 211)";
    section18.style.border = "2px solid rgb(216, 211, 211)";
    section19.style.border = "2px solid rgb(216, 211, 211)";
    section20.style.border = "2px solid rgb(216, 211, 211)";
    section21.style.border = "2px solid rgb(216, 211, 211)";
    section22.style.border = "2px solid rgb(216, 211, 211)";
    section23.style.border = "2px solid rgb(216, 211, 211)";
    section24.style.border = "2px solid rgb(216, 211, 211)";
    section25.style.border = "2px solid rgb(216, 211, 211)";
    section26.style.border = "2px solid rgb(216, 211, 211)";
    section27.style.border = "2px solid rgb(216, 211, 211)";
    section28.style.border = "2px solid rgb(216, 211, 211)";
    section29.style.border = "2px solid rgb(216, 211, 211)";
    section30.style.border = "2px solid rgb(216, 211, 211)";
    section31.style.border = "2px solid rgb(216, 211, 211)";
    section32.style.border = "2px solid rgb(216, 211, 211)";
    section33.style.border = "2px solid rgb(216, 211, 211)";
    section34.style.border = "2px solid rgb(216, 211, 211)";
    section35.style.border = "2px solid rgb(216, 211, 211)";
    section36.style.border = "2px solid rgb(216, 211, 211)";
    section37.style.backgroundColor = "black";
    section37.style.cursor = "pointer";
    section37.onmouseover = () => {
        section37.style.cursor = "pointer"
    }
    section37.onmouseout = () => {
        section37.style.cursor = "pointer"
    }
    section6.onmouseover=()=>{
        section6.style.border="3px solid black";
    }
    section6.onmouseout=()=>{
        section6.style.border="2px solid rgb(216, 211, 211)";
    }
    section7.onmouseover=()=>{
        section7.style.border="3px solid black";
    }
    section7.onmouseout=()=>{
        section7.style.border="2px solid rgb(216, 211, 211)";
    }
    section8.onmouseover=()=>{
        section8.style.border="3px solid black";
    }
    section8.onmouseout=()=>{
        section8.style.border="2px solid rgb(216, 211, 211)";
    }
    section9.onmouseover=()=>{
        section9.style.border="3px solid black";
    }
    section9.onmouseout=()=>{
        section9.style.border="2px solid rgb(216, 211, 211)";
    }
    section10.onmouseover=()=>{
        section10.style.border="3px solid black";
    }
    section10.onmouseout=()=>{
        section10.style.border="3px solid black";
    }
    section11.onmouseover=()=>{
        section11.style.border="3px solid black";
    }
    section11.onmouseout=()=>{
        section11.style.border="2px solid rgb(216, 211, 211)";
    }
    section12.onmouseover=()=>{
        section12.style.border="3px solid black";
    }
    section12.onmouseout=()=>{
        section12.style.border="2px solid rgb(216, 211, 211)";
    }
    section13.onmouseover=()=>{
        section13.style.border="3px solid black";
    }
    section13.onmouseout=()=>{
        section13.style.border="2px solid rgb(216, 211, 211)";
    }
    section14.onmouseover=()=>{
        section14.style.border="3px solid black";
    }
    section14.onmouseout=()=>{
        section14.style.border="2px solid rgb(216, 211, 211)";
    }
    section15.onmouseover=()=>{
        section15.style.border="3px solid black";
    }
    section15.onmouseout=()=>{
        section15.style.border="2px solid rgb(216, 211, 211)";
    }
    section16.onmouseover=()=>{
        section16.style.border="3px solid black";
    }
    section16.onmouseout=()=>{
        section16.style.border="2px solid rgb(216, 211, 211)";
    }
    section17.onmouseover=()=>{
        section17.style.border="3px solid black";
    }
    section17.onmouseout=()=>{
        section17.style.border="2px solid rgb(216, 211, 211)";
    }
    section18.onmouseover=()=>{
        section18.style.border="3px solid black";
    }
    section18.onmouseout=()=>{
        section18.style.border="2px solid rgb(216, 211, 211)";
    }
    section19.onmouseover=()=>{
        section19.style.border="3px solid black";
    }
    section19.onmouseout=()=>{
        section19.style.border="2px solid rgb(216, 211, 211)";
    }
    section20.onmouseover=()=>{
        section20.style.border="3px solid black";
    }
    section20.onmouseout=()=>{
        section20.style.border="2px solid rgb(216, 211, 211)";
    }
    section21.onmouseover=()=>{
        section21.style.border="3px solid black";
    }
    section21.onmouseout=()=>{
        section21.style.border="2px solid rgb(216, 211, 211)";
    }
    section22.onmouseover=()=>{
        section22.style.border="3px solid black";
    }
    section22.onmouseout=()=>{
        section22.style.border="2px solid rgb(216, 211, 211)";
    }
    section23.onmouseover=()=>{
        section23.style.border="3px solid black";
    }
    section23.onmouseout=()=>{
        section23.style.border="2px solid rgb(216, 211, 211)";
    }
    section24.onmouseover=()=>{
        section24.style.border="3px solid black";
    }
    section24.onmouseout=()=>{
        section24.style.border="2px solid rgb(216, 211, 211)";
    }
    section25.onmouseover=()=>{
        section25.style.border="3px solid black";
    }
    section25.onmouseout=()=>{
        section25.style.border="2px solid rgb(216, 211, 211)";
    }
    section26.onmouseover=()=>{
        section26.style.border="3px solid black";
    }
    section26.onmouseout=()=>{
        section26.style.border="2px solid rgb(216, 211, 211)";
    }
    section27.onmouseover=()=>{
        section27.style.border="3px solid black";
    }
    section27.onmouseout=()=>{
        section27.style.border="2px solid rgb(216, 211, 211)";
    }
    section28.onmouseover=()=>{
        section28.style.border="3px solid black";
    }
    section28.onmouseout=()=>{
        section28.style.border="2px solid rgb(216, 211, 211)";
    }
    section29.onmouseover=()=>{
        section29.style.border="3px solid black";
    }
    section29.onmouseout=()=>{
        section29.style.border="2px solid rgb(216, 211, 211)";
    }
    section30.onmouseover=()=>{
        section30.style.border="3px solid black";
    }
    section30.onmouseout=()=>{
        section30.style.border="2px solid rgb(216, 211, 211)";
    }
    section31.onmouseover=()=>{
        section31.style.border="3px solid black";
    }
    section31.onmouseout=()=>{
        section31.style.border="2px solid rgb(216, 211, 211)";
    }
    section32.onmouseover=()=>{
        section32.style.border="3px solid black";
    }
    section32.onmouseout=()=>{
        section32.style.border="2px solid rgb(216, 211, 211)";
    }
    section33.onmouseover=()=>{
        section33.style.border="3px solid black";
    }
    section33.onmouseout=()=>{
        section33.style.border="2px solid rgb(216, 211, 211)";
    }
    section34.onmouseover=()=>{
        section34.style.border="3px solid black";
    }
    section34.onmouseout=()=>{
        section34.style.border="2px solid rgb(216, 211, 211)";
    }
    section35.onmouseover=()=>{
        section35.style.border="3px solid black";
    }
    section35.onmouseout=()=>{
        section35.style.border="2px solid rgb(216, 211, 211)";
    }
    section36.onmouseover=()=>{
        section36.style.border="3px solid black";
    }
    section36.onmouseout=()=>{
        section36.style.border="2px solid rgb(216, 211, 211)";
    }
}
function fun6() {
    const section6 = document.getElementById("section6");
    const section7 = document.getElementById("section7");
    const section8 = document.getElementById("section8");
    const section9 = document.getElementById("section9");
    const section10 = document.getElementById("section10");
    const section11 = document.getElementById("section11");
    const section12 = document.getElementById("section12");
    const section13 = document.getElementById("section13");
    const section14 = document.getElementById("section14");
    const section15 = document.getElementById("section15");
    const section16 = document.getElementById("section16");
    const section17 = document.getElementById("section17");
    const section18 = document.getElementById("section18");
    const section19 = document.getElementById("section19");
    const section20 = document.getElementById("section20");
    const section21 = document.getElementById("section21");
    const section22 = document.getElementById("section22");
    const section23 = document.getElementById("section23");
    const section24 = document.getElementById("section24");
    const section25 = document.getElementById("section25");
    const section26 = document.getElementById("section26");
    const section27 = document.getElementById("section27");
    const section28 = document.getElementById("section28");
    const section29 = document.getElementById("section29");
    const section30 = document.getElementById("section30");
    const section31 = document.getElementById("section31");
    const section32 = document.getElementById("section32");
    const section33 = document.getElementById("section33");
    const section34 = document.getElementById("section34");
    const section35 = document.getElementById("section35");
    const section36 = document.getElementById("section36");
    const section37 = document.getElementsByClassName("section37")[0];
    section6.style.border = "2px solid rgb(216, 211, 211)";
    section7.style.border = "2px solid rgb(216, 211, 211)";
    section8.style.border = "2px solid rgb(216, 211, 211)";
    section9.style.border = "2px solid rgb(216, 211, 211)";
    section10.style.border = "2px solid rgb(216, 211, 211)";
    section11.style.border = "3px solid black";
    section12.style.border = "2px solid rgb(216, 211, 211)";
    section13.style.border = "2px solid rgb(216, 211, 211)";
    section14.style.border = "2px solid rgb(216, 211, 211)";
    section15.style.border = "2px solid rgb(216, 211, 211)";
    section16.style.border = "2px solid rgb(216, 211, 211)";
    section17.style.border = "2px solid rgb(216, 211, 211)";
    section18.style.border = "2px solid rgb(216, 211, 211)";
    section19.style.border = "2px solid rgb(216, 211, 211)";
    section20.style.border = "2px solid rgb(216, 211, 211)";
    section21.style.border = "2px solid rgb(216, 211, 211)";
    section22.style.border = "2px solid rgb(216, 211, 211)";
    section23.style.border = "2px solid rgb(216, 211, 211)";
    section24.style.border = "2px solid rgb(216, 211, 211)";
    section25.style.border = "2px solid rgb(216, 211, 211)";
    section26.style.border = "2px solid rgb(216, 211, 211)";
    section27.style.border = "2px solid rgb(216, 211, 211)";
    section28.style.border = "2px solid rgb(216, 211, 211)";
    section29.style.border = "2px solid rgb(216, 211, 211)";
    section30.style.border = "2px solid rgb(216, 211, 211)";
    section31.style.border = "2px solid rgb(216, 211, 211)";
    section32.style.border = "2px solid rgb(216, 211, 211)";
    section33.style.border = "2px solid rgb(216, 211, 211)";
    section34.style.border = "2px solid rgb(216, 211, 211)";
    section35.style.border = "2px solid rgb(216, 211, 211)";
    section36.style.border = "2px solid rgb(216, 211, 211)";
    section37.style.backgroundColor = "black";
    section37.style.cursor = "pointer";
    section37.onmouseover = () => {
        section37.style.cursor = "pointer"
    }
    section37.onmouseout = () => {
        section37.style.cursor = "pointer"
    }
    section6.onmouseover=()=>{
        section6.style.border="3px solid black";
    }
    section6.onmouseout=()=>{
        section6.style.border="2px solid rgb(216, 211, 211)";
    }
    section7.onmouseover=()=>{
        section7.style.border="3px solid black";
    }
    section7.onmouseout=()=>{
        section7.style.border="2px solid rgb(216, 211, 211)";
    }
    section8.onmouseover=()=>{
        section8.style.border="3px solid black";
    }
    section8.onmouseout=()=>{
        section8.style.border="2px solid rgb(216, 211, 211)";
    }
    section9.onmouseover=()=>{
        section9.style.border="3px solid black";
    }
    section9.onmouseout=()=>{
        section9.style.border="2px solid rgb(216, 211, 211)";
    }
    section10.onmouseover=()=>{
        section10.style.border="3px solid black";
    }
    section10.onmouseout=()=>{
        section10.style.border="2px solid rgb(216, 211, 211)";
    }
    section11.onmouseover=()=>{
        section11.style.border="3px solid black";
    }
    section11.onmouseout=()=>{
        section11.style.border="3px solid black";
    }
    section12.onmouseover=()=>{
        section12.style.border="3px solid black";
    }
    section12.onmouseout=()=>{
        section12.style.border="2px solid rgb(216, 211, 211)";
    }
    section13.onmouseover=()=>{
        section13.style.border="3px solid black";
    }
    section13.onmouseout=()=>{
        section13.style.border="2px solid rgb(216, 211, 211)";
    }
    section14.onmouseover=()=>{
        section14.style.border="3px solid black";
    }
    section14.onmouseout=()=>{
        section14.style.border="2px solid rgb(216, 211, 211)";
    }
    section15.onmouseover=()=>{
        section15.style.border="3px solid black";
    }
    section15.onmouseout=()=>{
        section15.style.border="2px solid rgb(216, 211, 211)";
    }
    section16.onmouseover=()=>{
        section16.style.border="3px solid black";
    }
    section16.onmouseout=()=>{
        section16.style.border="2px solid rgb(216, 211, 211)";
    }
    section17.onmouseover=()=>{
        section17.style.border="3px solid black";
    }
    section17.onmouseout=()=>{
        section17.style.border="2px solid rgb(216, 211, 211)";
    }
    section18.onmouseover=()=>{
        section18.style.border="3px solid black";
    }
    section18.onmouseout=()=>{
        section18.style.border="2px solid rgb(216, 211, 211)";
    }
    section19.onmouseover=()=>{
        section19.style.border="3px solid black";
    }
    section19.onmouseout=()=>{
        section19.style.border="2px solid rgb(216, 211, 211)";
    }
    section20.onmouseover=()=>{
        section20.style.border="3px solid black";
    }
    section20.onmouseout=()=>{
        section20.style.border="2px solid rgb(216, 211, 211)";
    }
    section21.onmouseover=()=>{
        section21.style.border="3px solid black";
    }
    section21.onmouseout=()=>{
        section21.style.border="2px solid rgb(216, 211, 211)";
    }
    section22.onmouseover=()=>{
        section22.style.border="3px solid black";
    }
    section22.onmouseout=()=>{
        section22.style.border="2px solid rgb(216, 211, 211)";
    }
    section23.onmouseover=()=>{
        section23.style.border="3px solid black";
    }
    section23.onmouseout=()=>{
        section23.style.border="2px solid rgb(216, 211, 211)";
    }
    section24.onmouseover=()=>{
        section24.style.border="3px solid black";
    }
    section24.onmouseout=()=>{
        section24.style.border="2px solid rgb(216, 211, 211)";
    }
    section25.onmouseover=()=>{
        section25.style.border="3px solid black";
    }
    section25.onmouseout=()=>{
        section25.style.border="2px solid rgb(216, 211, 211)";
    }
    section26.onmouseover=()=>{
        section26.style.border="3px solid black";
    }
    section26.onmouseout=()=>{
        section26.style.border="2px solid rgb(216, 211, 211)";
    }
    section27.onmouseover=()=>{
        section27.style.border="3px solid black";
    }
    section27.onmouseout=()=>{
        section27.style.border="2px solid rgb(216, 211, 211)";
    }
    section28.onmouseover=()=>{
        section28.style.border="3px solid black";
    }
    section28.onmouseout=()=>{
        section28.style.border="2px solid rgb(216, 211, 211)";
    }
    section29.onmouseover=()=>{
        section29.style.border="3px solid black";
    }
    section29.onmouseout=()=>{
        section29.style.border="2px solid rgb(216, 211, 211)";
    }
    section30.onmouseover=()=>{
        section30.style.border="3px solid black";
    }
    section30.onmouseout=()=>{
        section30.style.border="2px solid rgb(216, 211, 211)";
    }
    section31.onmouseover=()=>{
        section31.style.border="3px solid black";
    }
    section31.onmouseout=()=>{
        section31.style.border="2px solid rgb(216, 211, 211)";
    }
    section32.onmouseover=()=>{
        section32.style.border="3px solid black";
    }
    section32.onmouseout=()=>{
        section32.style.border="2px solid rgb(216, 211, 211)";
    }
    section33.onmouseover=()=>{
        section33.style.border="3px solid black";
    }
    section33.onmouseout=()=>{
        section33.style.border="2px solid rgb(216, 211, 211)";
    }
    section34.onmouseover=()=>{
        section34.style.border="3px solid black";
    }
    section34.onmouseout=()=>{
        section34.style.border="2px solid rgb(216, 211, 211)";
    }
    section35.onmouseover=()=>{
        section35.style.border="3px solid black";
    }
    section35.onmouseout=()=>{
        section35.style.border="2px solid rgb(216, 211, 211)";
    }
    section36.onmouseover=()=>{
        section36.style.border="3px solid black";
    }
    section36.onmouseout=()=>{
        section36.style.border="2px solid rgb(216, 211, 211)";
    }
}
function fun7() {
    const section6 = document.getElementById("section6");
    const section7 = document.getElementById("section7");
    const section8 = document.getElementById("section8");
    const section9 = document.getElementById("section9");
    const section10 = document.getElementById("section10");
    const section11 = document.getElementById("section11");
    const section12 = document.getElementById("section12");
    const section13 = document.getElementById("section13");
    const section14 = document.getElementById("section14");
    const section15 = document.getElementById("section15");
    const section16 = document.getElementById("section16");
    const section17 = document.getElementById("section17");
    const section18 = document.getElementById("section18");
    const section19 = document.getElementById("section19");
    const section20 = document.getElementById("section20");
    const section21 = document.getElementById("section21");
    const section22 = document.getElementById("section22");
    const section23 = document.getElementById("section23");
    const section24 = document.getElementById("section24");
    const section25 = document.getElementById("section25");
    const section26 = document.getElementById("section26");
    const section27 = document.getElementById("section27");
    const section28 = document.getElementById("section28");
    const section29 = document.getElementById("section29");
    const section30 = document.getElementById("section30");
    const section31 = document.getElementById("section31");
    const section32 = document.getElementById("section32");
    const section33 = document.getElementById("section33");
    const section34 = document.getElementById("section34");
    const section35 = document.getElementById("section35");
    const section36 = document.getElementById("section36");
    const section37 = document.getElementsByClassName("section37")[0];
    section6.style.border = "2px solid rgb(216, 211, 211)";
    section7.style.border = "2px solid rgb(216, 211, 211)";
    section8.style.border = "2px solid rgb(216, 211, 211)";
    section9.style.border = "2px solid rgb(216, 211, 211)";
    section10.style.border = "2px solid rgb(216, 211, 211)";
    section11.style.border = "2px solid rgb(216, 211, 211)";
    section12.style.border = "3px solid black";
    section13.style.border = "2px solid rgb(216, 211, 211)";
    section14.style.border = "2px solid rgb(216, 211, 211)";
    section15.style.border = "2px solid rgb(216, 211, 211)";
    section16.style.border = "2px solid rgb(216, 211, 211)";
    section17.style.border = "2px solid rgb(216, 211, 211)";
    section18.style.border = "2px solid rgb(216, 211, 211)";
    section19.style.border = "2px solid rgb(216, 211, 211)";
    section20.style.border = "2px solid rgb(216, 211, 211)";
    section21.style.border = "2px solid rgb(216, 211, 211)";
    section22.style.border = "2px solid rgb(216, 211, 211)";
    section23.style.border = "2px solid rgb(216, 211, 211)";
    section24.style.border = "2px solid rgb(216, 211, 211)";
    section25.style.border = "2px solid rgb(216, 211, 211)";
    section26.style.border = "2px solid rgb(216, 211, 211)";
    section27.style.border = "2px solid rgb(216, 211, 211)";
    section28.style.border = "2px solid rgb(216, 211, 211)";
    section29.style.border = "2px solid rgb(216, 211, 211)";
    section30.style.border = "2px solid rgb(216, 211, 211)";
    section31.style.border = "2px solid rgb(216, 211, 211)";
    section32.style.border = "2px solid rgb(216, 211, 211)";
    section33.style.border = "2px solid rgb(216, 211, 211)";
    section34.style.border = "2px solid rgb(216, 211, 211)";
    section35.style.border = "2px solid rgb(216, 211, 211)";
    section36.style.border = "2px solid rgb(216, 211, 211)";
    section37.style.backgroundColor = "black";
    section37.style.cursor = "pointer";
    section37.onmouseover = () => {
        section37.style.cursor = "pointer"
    }
    section37.onmouseout = () => {
        section37.style.cursor = "pointer"
    }
    section6.onmouseover=()=>{
        section6.style.border="3px solid black";
    }
    section6.onmouseout=()=>{
        section6.style.border="2px solid rgb(216, 211, 211)";
    }
    section7.onmouseover=()=>{
        section7.style.border="3px solid black";
    }
    section7.onmouseout=()=>{
        section7.style.border="2px solid rgb(216, 211, 211)";
    }
    section8.onmouseover=()=>{
        section8.style.border="3px solid black";
    }
    section8.onmouseout=()=>{
        section8.style.border="2px solid rgb(216, 211, 211)";
    }
    section9.onmouseover=()=>{
        section9.style.border="3px solid black";
    }
    section9.onmouseout=()=>{
        section9.style.border="2px solid rgb(216, 211, 211)";
    }
    section10.onmouseover=()=>{
        section10.style.border="3px solid black";
    }
    section10.onmouseout=()=>{
        section10.style.border="2px solid rgb(216, 211, 211)";
    }
    section11.onmouseover=()=>{
        section11.style.border="3px solid black";
    }
    section11.onmouseout=()=>{
        section11.style.border="2px solid rgb(216, 211, 211)";
    }
    section12.onmouseover=()=>{
        section12.style.border="3px solid black";
    }
    section12.onmouseout=()=>{
        section12.style.border="3px solid black";
    }
    section13.onmouseover=()=>{
        section13.style.border="3px solid black";
    }
    section13.onmouseout=()=>{
        section13.style.border="2px solid rgb(216, 211, 211)";
    }
    section14.onmouseover=()=>{
        section14.style.border="3px solid black";
    }
    section14.onmouseout=()=>{
        section14.style.border="2px solid rgb(216, 211, 211)";
    }
    section15.onmouseover=()=>{
        section15.style.border="3px solid black";
    }
    section15.onmouseout=()=>{
        section15.style.border="2px solid rgb(216, 211, 211)";
    }
    section16.onmouseover=()=>{
        section16.style.border="3px solid black";
    }
    section16.onmouseout=()=>{
        section16.style.border="2px solid rgb(216, 211, 211)";
    }
    section17.onmouseover=()=>{
        section17.style.border="3px solid black";
    }
    section17.onmouseout=()=>{
        section17.style.border="2px solid rgb(216, 211, 211)";
    }
    section18.onmouseover=()=>{
        section18.style.border="3px solid black";
    }
    section18.onmouseout=()=>{
        section18.style.border="2px solid rgb(216, 211, 211)";
    }
    section19.onmouseover=()=>{
        section19.style.border="3px solid black";
    }
    section19.onmouseout=()=>{
        section19.style.border="2px solid rgb(216, 211, 211)";
    }
    section20.onmouseover=()=>{
        section20.style.border="3px solid black";
    }
    section20.onmouseout=()=>{
        section20.style.border="2px solid rgb(216, 211, 211)";
    }
    section21.onmouseover=()=>{
        section21.style.border="3px solid black";
    }
    section21.onmouseout=()=>{
        section21.style.border="2px solid rgb(216, 211, 211)";
    }
    section22.onmouseover=()=>{
        section22.style.border="3px solid black";
    }
    section22.onmouseout=()=>{
        section22.style.border="2px solid rgb(216, 211, 211)";
    }
    section23.onmouseover=()=>{
        section23.style.border="3px solid black";
    }
    section23.onmouseout=()=>{
        section23.style.border="2px solid rgb(216, 211, 211)";
    }
    section24.onmouseover=()=>{
        section24.style.border="3px solid black";
    }
    section24.onmouseout=()=>{
        section24.style.border="2px solid rgb(216, 211, 211)";
    }
    section25.onmouseover=()=>{
        section25.style.border="3px solid black";
    }
    section25.onmouseout=()=>{
        section25.style.border="2px solid rgb(216, 211, 211)";
    }
    section26.onmouseover=()=>{
        section26.style.border="3px solid black";
    }
    section26.onmouseout=()=>{
        section26.style.border="2px solid rgb(216, 211, 211)";
    }
    section27.onmouseover=()=>{
        section27.style.border="3px solid black";
    }
    section27.onmouseout=()=>{
        section27.style.border="2px solid rgb(216, 211, 211)";
    }
    section28.onmouseover=()=>{
        section28.style.border="3px solid black";
    }
    section28.onmouseout=()=>{
        section28.style.border="2px solid rgb(216, 211, 211)";
    }
    section29.onmouseover=()=>{
        section29.style.border="3px solid black";
    }
    section29.onmouseout=()=>{
        section29.style.border="2px solid rgb(216, 211, 211)";
    }
    section30.onmouseover=()=>{
        section30.style.border="3px solid black";
    }
    section30.onmouseout=()=>{
        section30.style.border="2px solid rgb(216, 211, 211)";
    }
    section31.onmouseover=()=>{
        section31.style.border="3px solid black";
    }
    section31.onmouseout=()=>{
        section31.style.border="2px solid rgb(216, 211, 211)";
    }
    section32.onmouseover=()=>{
        section32.style.border="3px solid black";
    }
    section32.onmouseout=()=>{
        section32.style.border="2px solid rgb(216, 211, 211)";
    }
    section33.onmouseover=()=>{
        section33.style.border="3px solid black";
    }
    section33.onmouseout=()=>{
        section33.style.border="2px solid rgb(216, 211, 211)";
    }
    section34.onmouseover=()=>{
        section34.style.border="3px solid black";
    }
    section34.onmouseout=()=>{
        section34.style.border="2px solid rgb(216, 211, 211)";
    }
    section35.onmouseover=()=>{
        section35.style.border="3px solid black";
    }
    section35.onmouseout=()=>{
        section35.style.border="2px solid rgb(216, 211, 211)";
    }
    section36.onmouseover=()=>{
        section36.style.border="3px solid black";
    }
    section36.onmouseout=()=>{
        section36.style.border="2px solid rgb(216, 211, 211)";
    }
}
function fun8() {
    const section6 = document.getElementById("section6");
    const section7 = document.getElementById("section7");
    const section8 = document.getElementById("section8");
    const section9 = document.getElementById("section9");
    const section10 = document.getElementById("section10");
    const section11 = document.getElementById("section11");
    const section12 = document.getElementById("section12");
    const section13 = document.getElementById("section13");
    const section14 = document.getElementById("section14");
    const section15 = document.getElementById("section15");
    const section16 = document.getElementById("section16");
    const section17 = document.getElementById("section17");
    const section18 = document.getElementById("section18");
    const section19 = document.getElementById("section19");
    const section20 = document.getElementById("section20");
    const section21 = document.getElementById("section21");
    const section22 = document.getElementById("section22");
    const section23 = document.getElementById("section23");
    const section24 = document.getElementById("section24");
    const section25 = document.getElementById("section25");
    const section26 = document.getElementById("section26");
    const section27 = document.getElementById("section27");
    const section28 = document.getElementById("section28");
    const section29 = document.getElementById("section29");
    const section30 = document.getElementById("section30");
    const section31 = document.getElementById("section31");
    const section32 = document.getElementById("section32");
    const section33 = document.getElementById("section33");
    const section34 = document.getElementById("section34");
    const section35 = document.getElementById("section35");
    const section36 = document.getElementById("section36");
    const section37 = document.getElementsByClassName("section37")[0];
    section6.style.border = "2px solid rgb(216, 211, 211)";
    section7.style.border = "2px solid rgb(216, 211, 211)";
    section8.style.border = "2px solid rgb(216, 211, 211)";
    section9.style.border = "2px solid rgb(216, 211, 211)";
    section10.style.border = "2px solid rgb(216, 211, 211)";
    section11.style.border = "2px solid rgb(216, 211, 211)";
    section12.style.border = "2px solid rgb(216, 211, 211)";
    section13.style.border = "3px solid black";
    section14.style.border = "2px solid rgb(216, 211, 211)";
    section15.style.border = "2px solid rgb(216, 211, 211)";
    section16.style.border = "2px solid rgb(216, 211, 211)";
    section17.style.border = "2px solid rgb(216, 211, 211)";
    section18.style.border = "2px solid rgb(216, 211, 211)";
    section19.style.border = "2px solid rgb(216, 211, 211)";
    section20.style.border = "2px solid rgb(216, 211, 211)";
    section21.style.border = "2px solid rgb(216, 211, 211)";
    section22.style.border = "2px solid rgb(216, 211, 211)";
    section23.style.border = "2px solid rgb(216, 211, 211)";
    section24.style.border = "2px solid rgb(216, 211, 211)";
    section25.style.border = "2px solid rgb(216, 211, 211)";
    section26.style.border = "2px solid rgb(216, 211, 211)";
    section27.style.border = "2px solid rgb(216, 211, 211)";
    section28.style.border = "2px solid rgb(216, 211, 211)";
    section29.style.border = "2px solid rgb(216, 211, 211)";
    section30.style.border = "2px solid rgb(216, 211, 211)";
    section31.style.border = "2px solid rgb(216, 211, 211)";
    section32.style.border = "2px solid rgb(216, 211, 211)";
    section33.style.border = "2px solid rgb(216, 211, 211)";
    section34.style.border = "2px solid rgb(216, 211, 211)";
    section35.style.border = "2px solid rgb(216, 211, 211)";
    section36.style.border = "2px solid rgb(216, 211, 211)";
    section37.style.backgroundColor = "black";
    section37.style.cursor = "pointer";
    section37.onmouseover = () => {
        section37.style.cursor = "pointer"
    }
    section37.onmouseout = () => {
        section37.style.cursor = "pointer"
    }
    section6.onmouseover=()=>{
        section6.style.border="3px solid black";
    }
    section6.onmouseout=()=>{
        section6.style.border="2px solid rgb(216, 211, 211)";
    }
    section7.onmouseover=()=>{
        section7.style.border="3px solid black";
    }
    section7.onmouseout=()=>{
        section7.style.border="2px solid rgb(216, 211, 211)";
    }
    section8.onmouseover=()=>{
        section8.style.border="3px solid black";
    }
    section8.onmouseout=()=>{
        section8.style.border="2px solid rgb(216, 211, 211)";
    }
    section9.onmouseover=()=>{
        section9.style.border="3px solid black";
    }
    section9.onmouseout=()=>{
        section9.style.border="2px solid rgb(216, 211, 211)";
    }
    section10.onmouseover=()=>{
        section10.style.border="3px solid black";
    }
    section10.onmouseout=()=>{
        section10.style.border="2px solid rgb(216, 211, 211)";
    }
    section11.onmouseover=()=>{
        section11.style.border="3px solid black";
    }
    section11.onmouseout=()=>{
        section11.style.border="2px solid rgb(216, 211, 211)";
    }
    section12.onmouseover=()=>{
        section12.style.border="3px solid black";
    }
    section12.onmouseout=()=>{
        section12.style.border="2px solid rgb(216, 211, 211)";
    }
    section13.onmouseover=()=>{
        section13.style.border="3px solid black";
    }
    section13.onmouseout=()=>{
        section13.style.border="3px solid black";
    }
    section14.onmouseover=()=>{
        section14.style.border="3px solid black";
    }
    section14.onmouseout=()=>{
        section14.style.border="2px solid rgb(216, 211, 211)";
    }
    section15.onmouseover=()=>{
        section15.style.border="3px solid black";
    }
    section15.onmouseout=()=>{
        section15.style.border="2px solid rgb(216, 211, 211)";
    }
    section16.onmouseover=()=>{
        section16.style.border="3px solid black";
    }
    section16.onmouseout=()=>{
        section16.style.border="2px solid rgb(216, 211, 211)";
    }
    section17.onmouseover=()=>{
        section17.style.border="3px solid black";
    }
    section17.onmouseout=()=>{
        section17.style.border="2px solid rgb(216, 211, 211)";
    }
    section18.onmouseover=()=>{
        section18.style.border="3px solid black";
    }
    section18.onmouseout=()=>{
        section18.style.border="2px solid rgb(216, 211, 211)";
    }
    section19.onmouseover=()=>{
        section19.style.border="3px solid black";
    }
    section19.onmouseout=()=>{
        section19.style.border="2px solid rgb(216, 211, 211)";
    }
    section20.onmouseover=()=>{
        section20.style.border="3px solid black";
    }
    section20.onmouseout=()=>{
        section20.style.border="2px solid rgb(216, 211, 211)";
    }
    section21.onmouseover=()=>{
        section21.style.border="3px solid black";
    }
    section21.onmouseout=()=>{
        section21.style.border="2px solid rgb(216, 211, 211)";
    }
    section22.onmouseover=()=>{
        section22.style.border="3px solid black";
    }
    section22.onmouseout=()=>{
        section22.style.border="2px solid rgb(216, 211, 211)";
    }
    section23.onmouseover=()=>{
        section23.style.border="3px solid black";
    }
    section23.onmouseout=()=>{
        section23.style.border="2px solid rgb(216, 211, 211)";
    }
    section24.onmouseover=()=>{
        section24.style.border="3px solid black";
    }
    section24.onmouseout=()=>{
        section24.style.border="2px solid rgb(216, 211, 211)";
    }
    section25.onmouseover=()=>{
        section25.style.border="3px solid black";
    }
    section25.onmouseout=()=>{
        section25.style.border="2px solid rgb(216, 211, 211)";
    }
    section26.onmouseover=()=>{
        section26.style.border="3px solid black";
    }
    section26.onmouseout=()=>{
        section26.style.border="2px solid rgb(216, 211, 211)";
    }
    section27.onmouseover=()=>{
        section27.style.border="3px solid black";
    }
    section27.onmouseout=()=>{
        section27.style.border="2px solid rgb(216, 211, 211)";
    }
    section28.onmouseover=()=>{
        section28.style.border="3px solid black";
    }
    section28.onmouseout=()=>{
        section28.style.border="2px solid rgb(216, 211, 211)";
    }
    section29.onmouseover=()=>{
        section29.style.border="3px solid black";
    }
    section29.onmouseout=()=>{
        section29.style.border="2px solid rgb(216, 211, 211)";
    }
    section30.onmouseover=()=>{
        section30.style.border="3px solid black";
    }
    section30.onmouseout=()=>{
        section30.style.border="2px solid rgb(216, 211, 211)";
    }
    section31.onmouseover=()=>{
        section31.style.border="3px solid black";
    }
    section31.onmouseout=()=>{
        section31.style.border="2px solid rgb(216, 211, 211)";
    }
    section32.onmouseover=()=>{
        section32.style.border="3px solid black";
    }
    section32.onmouseout=()=>{
        section32.style.border="2px solid rgb(216, 211, 211)";
    }
    section33.onmouseover=()=>{
        section33.style.border="3px solid black";
    }
    section33.onmouseout=()=>{
        section33.style.border="2px solid rgb(216, 211, 211)";
    }
    section34.onmouseover=()=>{
        section34.style.border="3px solid black";
    }
    section34.onmouseout=()=>{
        section34.style.border="2px solid rgb(216, 211, 211)";
    }
    section35.onmouseover=()=>{
        section35.style.border="3px solid black";
    }
    section35.onmouseout=()=>{
        section35.style.border="2px solid rgb(216, 211, 211)";
    }
    section36.onmouseover=()=>{
        section36.style.border="3px solid black";
    }
    section36.onmouseout=()=>{
        section36.style.border="2px solid rgb(216, 211, 211)";
    }
}
function fun9() {
    const section6 = document.getElementById("section6");
    const section7 = document.getElementById("section7");
    const section8 = document.getElementById("section8");
    const section9 = document.getElementById("section9");
    const section10 = document.getElementById("section10");
    const section11 = document.getElementById("section11");
    const section12 = document.getElementById("section12");
    const section13 = document.getElementById("section13");
    const section14 = document.getElementById("section14");
    const section15 = document.getElementById("section15");
    const section16 = document.getElementById("section16");
    const section17 = document.getElementById("section17");
    const section18 = document.getElementById("section18");
    const section19 = document.getElementById("section19");
    const section20 = document.getElementById("section20");
    const section21 = document.getElementById("section21");
    const section22 = document.getElementById("section22");
    const section23 = document.getElementById("section23");
    const section24 = document.getElementById("section24");
    const section25 = document.getElementById("section25");
    const section26 = document.getElementById("section26");
    const section27 = document.getElementById("section27");
    const section28 = document.getElementById("section28");
    const section29 = document.getElementById("section29");
    const section30 = document.getElementById("section30");
    const section31 = document.getElementById("section31");
    const section32 = document.getElementById("section32");
    const section33 = document.getElementById("section33");
    const section34 = document.getElementById("section34");
    const section35 = document.getElementById("section35");
    const section36 = document.getElementById("section36");
    const section37 = document.getElementsByClassName("section37")[0];
    section6.style.border = "2px solid rgb(216, 211, 211)";
    section7.style.border = "2px solid rgb(216, 211, 211)";
    section8.style.border = "2px solid rgb(216, 211, 211)";
    section9.style.border = "2px solid rgb(216, 211, 211)";
    section10.style.border = "2px solid rgb(216, 211, 211)";
    section11.style.border = "2px solid rgb(216, 211, 211)";
    section12.style.border = "2px solid rgb(216, 211, 211)";
    section13.style.border = "2px solid rgb(216, 211, 211)";
    section14.style.border = "3px solid black";
    section15.style.border = "2px solid rgb(216, 211, 211)";
    section16.style.border = "2px solid rgb(216, 211, 211)";
    section17.style.border = "2px solid rgb(216, 211, 211)";
    section18.style.border = "2px solid rgb(216, 211, 211)";
    section19.style.border = "2px solid rgb(216, 211, 211)";
    section20.style.border = "2px solid rgb(216, 211, 211)";
    section21.style.border = "2px solid rgb(216, 211, 211)";
    section22.style.border = "2px solid rgb(216, 211, 211)";
    section23.style.border = "2px solid rgb(216, 211, 211)";
    section24.style.border = "2px solid rgb(216, 211, 211)";
    section25.style.border = "2px solid rgb(216, 211, 211)";
    section26.style.border = "2px solid rgb(216, 211, 211)";
    section27.style.border = "2px solid rgb(216, 211, 211)";
    section28.style.border = "2px solid rgb(216, 211, 211)";
    section29.style.border = "2px solid rgb(216, 211, 211)";
    section30.style.border = "2px solid rgb(216, 211, 211)";
    section31.style.border = "2px solid rgb(216, 211, 211)";
    section32.style.border = "2px solid rgb(216, 211, 211)";
    section33.style.border = "2px solid rgb(216, 211, 211)";
    section34.style.border = "2px solid rgb(216, 211, 211)";
    section35.style.border = "2px solid rgb(216, 211, 211)";
    section36.style.border = "2px solid rgb(216, 211, 211)";
    section37.style.backgroundColor = "black";
    section37.style.cursor = "pointer";
    section37.onmouseover = () => {
        section37.style.cursor = "pointer"
    }
    section37.onmouseout = () => {
        section37.style.cursor = "pointer"
    }
    section6.onmouseover=()=>{
        section6.style.border="3px solid black";
    }
    section6.onmouseout=()=>{
        section6.style.border="2px solid rgb(216, 211, 211)";
    }
    section7.onmouseover=()=>{
        section7.style.border="3px solid black";
    }
    section7.onmouseout=()=>{
        section7.style.border="2px solid rgb(216, 211, 211)";
    }
    section8.onmouseover=()=>{
        section8.style.border="3px solid black";
    }
    section8.onmouseout=()=>{
        section8.style.border="2px solid rgb(216, 211, 211)";
    }
    section9.onmouseover=()=>{
        section9.style.border="3px solid black";
    }
    section9.onmouseout=()=>{
        section9.style.border="2px solid rgb(216, 211, 211)";
    }
    section10.onmouseover=()=>{
        section10.style.border="3px solid black";
    }
    section10.onmouseout=()=>{
        section10.style.border="2px solid rgb(216, 211, 211)";
    }
    section11.onmouseover=()=>{
        section11.style.border="3px solid black";
    }
    section11.onmouseout=()=>{
        section11.style.border="2px solid rgb(216, 211, 211)";
    }
    section12.onmouseover=()=>{
        section12.style.border="3px solid black";
    }
    section12.onmouseout=()=>{
        section12.style.border="2px solid rgb(216, 211, 211)";
    }
    section13.onmouseover=()=>{
        section13.style.border="3px solid black";
    }
    section13.onmouseout=()=>{
        section13.style.border="2px solid rgb(216, 211, 211)";
    }
    section14.onmouseover=()=>{
        section14.style.border="3px solid black";
    }
    section14.onmouseout=()=>{
        section14.style.border="3px solid black";
    }
    section15.onmouseover=()=>{
        section15.style.border="3px solid black";
    }
    section15.onmouseout=()=>{
        section15.style.border="2px solid rgb(216, 211, 211)";
    }
    section16.onmouseover=()=>{
        section16.style.border="3px solid black";
    }
    section16.onmouseout=()=>{
        section16.style.border="2px solid rgb(216, 211, 211)";
    }
    section17.onmouseover=()=>{
        section17.style.border="3px solid black";
    }
    section17.onmouseout=()=>{
        section17.style.border="2px solid rgb(216, 211, 211)";
    }
    section18.onmouseover=()=>{
        section18.style.border="3px solid black";
    }
    section18.onmouseout=()=>{
        section18.style.border="2px solid rgb(216, 211, 211)";
    }
    section19.onmouseover=()=>{
        section19.style.border="3px solid black";
    }
    section19.onmouseout=()=>{
        section19.style.border="2px solid rgb(216, 211, 211)";
    }
    section20.onmouseover=()=>{
        section20.style.border="3px solid black";
    }
    section20.onmouseout=()=>{
        section20.style.border="2px solid rgb(216, 211, 211)";
    }
    section21.onmouseover=()=>{
        section21.style.border="3px solid black";
    }
    section21.onmouseout=()=>{
        section21.style.border="2px solid rgb(216, 211, 211)";
    }
    section22.onmouseover=()=>{
        section22.style.border="3px solid black";
    }
    section22.onmouseout=()=>{
        section22.style.border="2px solid rgb(216, 211, 211)";
    }
    section23.onmouseover=()=>{
        section23.style.border="3px solid black";
    }
    section23.onmouseout=()=>{
        section23.style.border="2px solid rgb(216, 211, 211)";
    }
    section24.onmouseover=()=>{
        section24.style.border="3px solid black";
    }
    section24.onmouseout=()=>{
        section24.style.border="2px solid rgb(216, 211, 211)";
    }
    section25.onmouseover=()=>{
        section25.style.border="3px solid black";
    }
    section25.onmouseout=()=>{
        section25.style.border="2px solid rgb(216, 211, 211)";
    }
    section26.onmouseover=()=>{
        section26.style.border="3px solid black";
    }
    section26.onmouseout=()=>{
        section26.style.border="2px solid rgb(216, 211, 211)";
    }
    section27.onmouseover=()=>{
        section27.style.border="3px solid black";
    }
    section27.onmouseout=()=>{
        section27.style.border="2px solid rgb(216, 211, 211)";
    }
    section28.onmouseover=()=>{
        section28.style.border="3px solid black";
    }
    section28.onmouseout=()=>{
        section28.style.border="2px solid rgb(216, 211, 211)";
    }
    section29.onmouseover=()=>{
        section29.style.border="3px solid black";
    }
    section29.onmouseout=()=>{
        section29.style.border="2px solid rgb(216, 211, 211)";
    }
    section30.onmouseover=()=>{
        section30.style.border="3px solid black";
    }
    section30.onmouseout=()=>{
        section30.style.border="2px solid rgb(216, 211, 211)";
    }
    section31.onmouseover=()=>{
        section31.style.border="3px solid black";
    }
    section31.onmouseout=()=>{
        section31.style.border="2px solid rgb(216, 211, 211)";
    }
    section32.onmouseover=()=>{
        section32.style.border="3px solid black";
    }
    section32.onmouseout=()=>{
        section32.style.border="2px solid rgb(216, 211, 211)";
    }
    section33.onmouseover=()=>{
        section33.style.border="3px solid black";
    }
    section33.onmouseout=()=>{
        section33.style.border="2px solid rgb(216, 211, 211)";
    }
    section34.onmouseover=()=>{
        section34.style.border="3px solid black";
    }
    section34.onmouseout=()=>{
        section34.style.border="2px solid rgb(216, 211, 211)";
    }
    section35.onmouseover=()=>{
        section35.style.border="3px solid black";
    }
    section35.onmouseout=()=>{
        section35.style.border="2px solid rgb(216, 211, 211)";
    }
    section36.onmouseover=()=>{
        section36.style.border="3px solid black";
    }
    section36.onmouseout=()=>{
        section36.style.border="2px solid rgb(216, 211, 211)";
    }
}
function fun10() {
    const section6 = document.getElementById("section6");
    const section7 = document.getElementById("section7");
    const section8 = document.getElementById("section8");
    const section9 = document.getElementById("section9");
    const section10 = document.getElementById("section10");
    const section11 = document.getElementById("section11");
    const section12 = document.getElementById("section12");
    const section13 = document.getElementById("section13");
    const section14 = document.getElementById("section14");
    const section15 = document.getElementById("section15");
    const section16 = document.getElementById("section16");
    const section17 = document.getElementById("section17");
    const section18 = document.getElementById("section18");
    const section19 = document.getElementById("section19");
    const section20 = document.getElementById("section20");
    const section21 = document.getElementById("section21");
    const section22 = document.getElementById("section22");
    const section23 = document.getElementById("section23");
    const section24 = document.getElementById("section24");
    const section25 = document.getElementById("section25");
    const section26 = document.getElementById("section26");
    const section27 = document.getElementById("section27");
    const section28 = document.getElementById("section28");
    const section29 = document.getElementById("section29");
    const section30 = document.getElementById("section30");
    const section31 = document.getElementById("section31");
    const section32 = document.getElementById("section32");
    const section33 = document.getElementById("section33");
    const section34 = document.getElementById("section34");
    const section35 = document.getElementById("section35");
    const section36 = document.getElementById("section36");
    const section37 = document.getElementsByClassName("section37")[0];
    section6.style.border = "2px solid rgb(216, 211, 211)";
    section7.style.border = "2px solid rgb(216, 211, 211)";
    section8.style.border = "2px solid rgb(216, 211, 211)";
    section9.style.border = "2px solid rgb(216, 211, 211)";
    section10.style.border = "2px solid rgb(216, 211, 211)";
    section11.style.border = "2px solid rgb(216, 211, 211)";
    section12.style.border = "2px solid rgb(216, 211, 211)";
    section13.style.border = "2px solid rgb(216, 211, 211)";
    section14.style.border = "2px solid rgb(216, 211, 211)";
    section15.style.border = "3px solid black";
    section16.style.border = "2px solid rgb(216, 211, 211)";
    section17.style.border = "2px solid rgb(216, 211, 211)";
    section18.style.border = "2px solid rgb(216, 211, 211)";
    section19.style.border = "2px solid rgb(216, 211, 211)";
    section20.style.border = "2px solid rgb(216, 211, 211)";
    section21.style.border = "2px solid rgb(216, 211, 211)";
    section22.style.border = "2px solid rgb(216, 211, 211)";
    section23.style.border = "2px solid rgb(216, 211, 211)";
    section24.style.border = "2px solid rgb(216, 211, 211)";
    section25.style.border = "2px solid rgb(216, 211, 211)";
    section26.style.border = "2px solid rgb(216, 211, 211)";
    section27.style.border = "2px solid rgb(216, 211, 211)";
    section28.style.border = "2px solid rgb(216, 211, 211)";
    section29.style.border = "2px solid rgb(216, 211, 211)";
    section30.style.border = "2px solid rgb(216, 211, 211)";
    section31.style.border = "2px solid rgb(216, 211, 211)";
    section32.style.border = "2px solid rgb(216, 211, 211)";
    section33.style.border = "2px solid rgb(216, 211, 211)";
    section34.style.border = "2px solid rgb(216, 211, 211)";
    section35.style.border = "2px solid rgb(216, 211, 211)";
    section36.style.border = "2px solid rgb(216, 211, 211)";
    section37.style.backgroundColor = "black";
    section37.style.cursor = "pointer";
    section37.onmouseover = () => {
        section37.style.cursor = "pointer"
    }
    section37.onmouseout = () => {
        section37.style.cursor = "pointer"
    }
    section6.onmouseover=()=>{
        section6.style.border="3px solid black";
    }
    section6.onmouseout=()=>{
        section6.style.border="2px solid rgb(216, 211, 211)";
    }
    section7.onmouseover=()=>{
        section7.style.border="3px solid black";
    }
    section7.onmouseout=()=>{
        section7.style.border="2px solid rgb(216, 211, 211)";
    }
    section8.onmouseover=()=>{
        section8.style.border="3px solid black";
    }
    section8.onmouseout=()=>{
        section8.style.border="2px solid rgb(216, 211, 211)";
    }
    section9.onmouseover=()=>{
        section9.style.border="3px solid black";
    }
    section9.onmouseout=()=>{
        section9.style.border="2px solid rgb(216, 211, 211)";
    }
    section10.onmouseover=()=>{
        section10.style.border="3px solid black";
    }
    section10.onmouseout=()=>{
        section10.style.border="2px solid rgb(216, 211, 211)";
    }
    section11.onmouseover=()=>{
        section11.style.border="3px solid black";
    }
    section11.onmouseout=()=>{
        section11.style.border="2px solid rgb(216, 211, 211)";
    }
    section12.onmouseover=()=>{
        section12.style.border="3px solid black";
    }
    section12.onmouseout=()=>{
        section12.style.border="2px solid rgb(216, 211, 211)";
    }
    section13.onmouseover=()=>{
        section13.style.border="3px solid black";
    }
    section13.onmouseout=()=>{
        section13.style.border="2px solid rgb(216, 211, 211)";
    }
    section14.onmouseover=()=>{
        section14.style.border="3px solid black";
    }
    section14.onmouseout=()=>{
        section14.style.border="2px solid rgb(216, 211, 211)";
    }
    section15.onmouseover=()=>{
        section15.style.border="3px solid black";
    }
    section15.onmouseout=()=>{
        section15.style.border="3px solid black";
    }
    section16.onmouseover=()=>{
        section16.style.border="3px solid black";
    }
    section16.onmouseout=()=>{
        section16.style.border="2px solid rgb(216, 211, 211)";
    }
    section17.onmouseover=()=>{
        section17.style.border="3px solid black";
    }
    section17.onmouseout=()=>{
        section17.style.border="2px solid rgb(216, 211, 211)";
    }
    section18.onmouseover=()=>{
        section18.style.border="3px solid black";
    }
    section18.onmouseout=()=>{
        section18.style.border="2px solid rgb(216, 211, 211)";
    }
    section19.onmouseover=()=>{
        section19.style.border="3px solid black";
    }
    section19.onmouseout=()=>{
        section19.style.border="2px solid rgb(216, 211, 211)";
    }
    section20.onmouseover=()=>{
        section20.style.border="3px solid black";
    }
    section20.onmouseout=()=>{
        section20.style.border="2px solid rgb(216, 211, 211)";
    }
    section21.onmouseover=()=>{
        section21.style.border="3px solid black";
    }
    section21.onmouseout=()=>{
        section21.style.border="2px solid rgb(216, 211, 211)";
    }
    section22.onmouseover=()=>{
        section22.style.border="3px solid black";
    }
    section22.onmouseout=()=>{
        section22.style.border="2px solid rgb(216, 211, 211)";
    }
    section23.onmouseover=()=>{
        section23.style.border="3px solid black";
    }
    section23.onmouseout=()=>{
        section23.style.border="2px solid rgb(216, 211, 211)";
    }
    section24.onmouseover=()=>{
        section24.style.border="3px solid black";
    }
    section24.onmouseout=()=>{
        section24.style.border="2px solid rgb(216, 211, 211)";
    }
    section25.onmouseover=()=>{
        section25.style.border="3px solid black";
    }
    section25.onmouseout=()=>{
        section25.style.border="2px solid rgb(216, 211, 211)";
    }
    section26.onmouseover=()=>{
        section26.style.border="3px solid black";
    }
    section26.onmouseout=()=>{
        section26.style.border="2px solid rgb(216, 211, 211)";
    }
    section27.onmouseover=()=>{
        section27.style.border="3px solid black";
    }
    section27.onmouseout=()=>{
        section27.style.border="2px solid rgb(216, 211, 211)";
    }
    section28.onmouseover=()=>{
        section28.style.border="3px solid black";
    }
    section28.onmouseout=()=>{
        section28.style.border="2px solid rgb(216, 211, 211)";
    }
    section29.onmouseover=()=>{
        section29.style.border="3px solid black";
    }
    section29.onmouseout=()=>{
        section29.style.border="2px solid rgb(216, 211, 211)";
    }
    section30.onmouseover=()=>{
        section30.style.border="3px solid black";
    }
    section30.onmouseout=()=>{
        section30.style.border="2px solid rgb(216, 211, 211)";
    }
    section31.onmouseover=()=>{
        section31.style.border="3px solid black";
    }
    section31.onmouseout=()=>{
        section31.style.border="2px solid rgb(216, 211, 211)";
    }
    section32.onmouseover=()=>{
        section32.style.border="3px solid black";
    }
    section32.onmouseout=()=>{
        section32.style.border="2px solid rgb(216, 211, 211)";
    }
    section33.onmouseover=()=>{
        section33.style.border="3px solid black";
    }
    section33.onmouseout=()=>{
        section33.style.border="2px solid rgb(216, 211, 211)";
    }
    section34.onmouseover=()=>{
        section34.style.border="3px solid black";
    }
    section34.onmouseout=()=>{
        section34.style.border="2px solid rgb(216, 211, 211)";
    }
    section35.onmouseover=()=>{
        section35.style.border="3px solid black";
    }
    section35.onmouseout=()=>{
        section35.style.border="2px solid rgb(216, 211, 211)";
    }
    section36.onmouseover=()=>{
        section36.style.border="3px solid black";
    }
    section36.onmouseout=()=>{
        section36.style.border="2px solid rgb(216, 211, 211)";
    }
}
function fun11() {
    const section6 = document.getElementById("section6");
    const section7 = document.getElementById("section7");
    const section8 = document.getElementById("section8");
    const section9 = document.getElementById("section9");
    const section10 = document.getElementById("section10");
    const section11 = document.getElementById("section11");
    const section12 = document.getElementById("section12");
    const section13 = document.getElementById("section13");
    const section14 = document.getElementById("section14");
    const section15 = document.getElementById("section15");
    const section16 = document.getElementById("section16");
    const section17 = document.getElementById("section17");
    const section18 = document.getElementById("section18");
    const section19 = document.getElementById("section19");
    const section20 = document.getElementById("section20");
    const section21 = document.getElementById("section21");
    const section22 = document.getElementById("section22");
    const section23 = document.getElementById("section23");
    const section24 = document.getElementById("section24");
    const section25 = document.getElementById("section25");
    const section26 = document.getElementById("section26");
    const section27 = document.getElementById("section27");
    const section28 = document.getElementById("section28");
    const section29 = document.getElementById("section29");
    const section30 = document.getElementById("section30");
    const section31 = document.getElementById("section31");
    const section32 = document.getElementById("section32");
    const section33 = document.getElementById("section33");
    const section34 = document.getElementById("section34");
    const section35 = document.getElementById("section35");
    const section36 = document.getElementById("section36");
    const section37 = document.getElementsByClassName("section37")[0];
    section6.style.border = "2px solid rgb(216, 211, 211)";
    section7.style.border = "2px solid rgb(216, 211, 211)";
    section8.style.border = "2px solid rgb(216, 211, 211)";
    section9.style.border = "2px solid rgb(216, 211, 211)";
    section10.style.border = "2px solid rgb(216, 211, 211)";
    section11.style.border = "2px solid rgb(216, 211, 211)";
    section12.style.border = "2px solid rgb(216, 211, 211)";
    section13.style.border = "2px solid rgb(216, 211, 211)";
    section14.style.border = "2px solid rgb(216, 211, 211)";
    section15.style.border = "2px solid rgb(216, 211, 211)";
    section16.style.border = "3px solid black";
    section17.style.border = "2px solid rgb(216, 211, 211)";
    section18.style.border = "2px solid rgb(216, 211, 211)";
    section19.style.border = "2px solid rgb(216, 211, 211)";
    section20.style.border = "2px solid rgb(216, 211, 211)";
    section21.style.border = "2px solid rgb(216, 211, 211)";
    section22.style.border = "2px solid rgb(216, 211, 211)";
    section23.style.border = "2px solid rgb(216, 211, 211)";
    section24.style.border = "2px solid rgb(216, 211, 211)";
    section25.style.border = "2px solid rgb(216, 211, 211)";
    section26.style.border = "2px solid rgb(216, 211, 211)";
    section27.style.border = "2px solid rgb(216, 211, 211)";
    section28.style.border = "2px solid rgb(216, 211, 211)";
    section29.style.border = "2px solid rgb(216, 211, 211)";
    section30.style.border = "2px solid rgb(216, 211, 211)";
    section31.style.border = "2px solid rgb(216, 211, 211)";
    section32.style.border = "2px solid rgb(216, 211, 211)";
    section33.style.border = "2px solid rgb(216, 211, 211)";
    section34.style.border = "2px solid rgb(216, 211, 211)";
    section35.style.border = "2px solid rgb(216, 211, 211)";
    section36.style.border = "2px solid rgb(216, 211, 211)";
    section37.style.backgroundColor = "black";
    section37.style.cursor = "pointer";
    section37.onmouseover = () => {
        section37.style.cursor = "pointer"
    }
    section37.onmouseout = () => {
        section37.style.cursor = "pointer"
    }
    section6.onmouseover=()=>{
        section6.style.border="3px solid black";
    }
    section6.onmouseout=()=>{
        section6.style.border="2px solid rgb(216, 211, 211)";
    }
    section7.onmouseover=()=>{
        section7.style.border="3px solid black";
    }
    section7.onmouseout=()=>{
        section7.style.border="2px solid rgb(216, 211, 211)";
    }
    section8.onmouseover=()=>{
        section8.style.border="3px solid black";
    }
    section8.onmouseout=()=>{
        section8.style.border="2px solid rgb(216, 211, 211)";
    }
    section9.onmouseover=()=>{
        section9.style.border="3px solid black";
    }
    section9.onmouseout=()=>{
        section9.style.border="2px solid rgb(216, 211, 211)";
    }
    section10.onmouseover=()=>{
        section10.style.border="3px solid black";
    }
    section10.onmouseout=()=>{
        section10.style.border="2px solid rgb(216, 211, 211)";
    }
    section11.onmouseover=()=>{
        section11.style.border="3px solid black";
    }
    section11.onmouseout=()=>{
        section11.style.border="2px solid rgb(216, 211, 211)";
    }
    section12.onmouseover=()=>{
        section12.style.border="3px solid black";
    }
    section12.onmouseout=()=>{
        section12.style.border="2px solid rgb(216, 211, 211)";
    }
    section13.onmouseover=()=>{
        section13.style.border="3px solid black";
    }
    section13.onmouseout=()=>{
        section13.style.border="2px solid rgb(216, 211, 211)";
    }
    section14.onmouseover=()=>{
        section14.style.border="3px solid black";
    }
    section14.onmouseout=()=>{
        section14.style.border="2px solid rgb(216, 211, 211)";
    }
    section15.onmouseover=()=>{
        section15.style.border="3px solid black";
    }
    section15.onmouseout=()=>{
        section15.style.border="2px solid rgb(216, 211, 211)";
    }
    section16.onmouseover=()=>{
        section16.style.border="3px solid black";
    }
    section16.onmouseout=()=>{
        section16.style.border="3px solid black";
    }
    section17.onmouseover=()=>{
        section17.style.border="3px solid black";
    }
    section17.onmouseout=()=>{
        section17.style.border="2px solid rgb(216, 211, 211)";
    }
    section18.onmouseover=()=>{
        section18.style.border="3px solid black";
    }
    section18.onmouseout=()=>{
        section18.style.border="2px solid rgb(216, 211, 211)";
    }
    section19.onmouseover=()=>{
        section19.style.border="3px solid black";
    }
    section19.onmouseout=()=>{
        section19.style.border="2px solid rgb(216, 211, 211)";
    }
    section20.onmouseover=()=>{
        section20.style.border="3px solid black";
    }
    section20.onmouseout=()=>{
        section20.style.border="2px solid rgb(216, 211, 211)";
    }
    section21.onmouseover=()=>{
        section21.style.border="3px solid black";
    }
    section21.onmouseout=()=>{
        section21.style.border="2px solid rgb(216, 211, 211)";
    }
    section22.onmouseover=()=>{
        section22.style.border="3px solid black";
    }
    section22.onmouseout=()=>{
        section22.style.border="2px solid rgb(216, 211, 211)";
    }
    section23.onmouseover=()=>{
        section23.style.border="3px solid black";
    }
    section23.onmouseout=()=>{
        section23.style.border="2px solid rgb(216, 211, 211)";
    }
    section24.onmouseover=()=>{
        section24.style.border="3px solid black";
    }
    section24.onmouseout=()=>{
        section24.style.border="2px solid rgb(216, 211, 211)";
    }
    section25.onmouseover=()=>{
        section25.style.border="3px solid black";
    }
    section25.onmouseout=()=>{
        section25.style.border="2px solid rgb(216, 211, 211)";
    }
    section26.onmouseover=()=>{
        section26.style.border="3px solid black";
    }
    section26.onmouseout=()=>{
        section26.style.border="2px solid rgb(216, 211, 211)";
    }
    section27.onmouseover=()=>{
        section27.style.border="3px solid black";
    }
    section27.onmouseout=()=>{
        section27.style.border="2px solid rgb(216, 211, 211)";
    }
    section28.onmouseover=()=>{
        section28.style.border="3px solid black";
    }
    section28.onmouseout=()=>{
        section28.style.border="2px solid rgb(216, 211, 211)";
    }
    section29.onmouseover=()=>{
        section29.style.border="3px solid black";
    }
    section29.onmouseout=()=>{
        section29.style.border="2px solid rgb(216, 211, 211)";
    }
    section30.onmouseover=()=>{
        section30.style.border="3px solid black";
    }
    section30.onmouseout=()=>{
        section30.style.border="2px solid rgb(216, 211, 211)";
    }
    section31.onmouseover=()=>{
        section31.style.border="3px solid black";
    }
    section31.onmouseout=()=>{
        section31.style.border="2px solid rgb(216, 211, 211)";
    }
    section32.onmouseover=()=>{
        section32.style.border="3px solid black";
    }
    section32.onmouseout=()=>{
        section32.style.border="2px solid rgb(216, 211, 211)";
    }
    section33.onmouseover=()=>{
        section33.style.border="3px solid black";
    }
    section33.onmouseout=()=>{
        section33.style.border="2px solid rgb(216, 211, 211)";
    }
    section34.onmouseover=()=>{
        section34.style.border="3px solid black";
    }
    section34.onmouseout=()=>{
        section34.style.border="2px solid rgb(216, 211, 211)";
    }
    section35.onmouseover=()=>{
        section35.style.border="3px solid black";
    }
    section35.onmouseout=()=>{
        section35.style.border="2px solid rgb(216, 211, 211)";
    }
    section36.onmouseover=()=>{
        section36.style.border="3px solid black";
    }
    section36.onmouseout=()=>{
        section36.style.border="2px solid rgb(216, 211, 211)";
    }
}
function fun12() {
    const section6 = document.getElementById("section6");
    const section7 = document.getElementById("section7");
    const section8 = document.getElementById("section8");
    const section9 = document.getElementById("section9");
    const section10 = document.getElementById("section10");
    const section11 = document.getElementById("section11");
    const section12 = document.getElementById("section12");
    const section13 = document.getElementById("section13");
    const section14 = document.getElementById("section14");
    const section15 = document.getElementById("section15");
    const section16 = document.getElementById("section16");
    const section17 = document.getElementById("section17");
    const section18 = document.getElementById("section18");
    const section19 = document.getElementById("section19");
    const section20 = document.getElementById("section20");
    const section21 = document.getElementById("section21");
    const section22 = document.getElementById("section22");
    const section23 = document.getElementById("section23");
    const section24 = document.getElementById("section24");
    const section25 = document.getElementById("section25");
    const section26 = document.getElementById("section26");
    const section27 = document.getElementById("section27");
    const section28 = document.getElementById("section28");
    const section29 = document.getElementById("section29");
    const section30 = document.getElementById("section30");
    const section31 = document.getElementById("section31");
    const section32 = document.getElementById("section32");
    const section33 = document.getElementById("section33");
    const section34 = document.getElementById("section34");
    const section35 = document.getElementById("section35");
    const section36 = document.getElementById("section36");
    const section37 = document.getElementsByClassName("section37")[0];
    section6.style.border = "2px solid rgb(216, 211, 211)";
    section7.style.border = "2px solid rgb(216, 211, 211)";
    section8.style.border = "2px solid rgb(216, 211, 211)";
    section9.style.border = "2px solid rgb(216, 211, 211)";
    section10.style.border = "2px solid rgb(216, 211, 211)";
    section11.style.border = "2px solid rgb(216, 211, 211)";
    section12.style.border = "2px solid rgb(216, 211, 211)";
    section13.style.border = "2px solid rgb(216, 211, 211)";
    section14.style.border = "2px solid rgb(216, 211, 211)";
    section15.style.border = "2px solid rgb(216, 211, 211)";
    section16.style.border = "2px solid rgb(216, 211, 211)";
    section17.style.border = "3px solid black";
    section18.style.border = "2px solid rgb(216, 211, 211)";
    section19.style.border = "2px solid rgb(216, 211, 211)";
    section20.style.border = "2px solid rgb(216, 211, 211)";
    section21.style.border = "2px solid rgb(216, 211, 211)";
    section22.style.border = "2px solid rgb(216, 211, 211)";
    section23.style.border = "2px solid rgb(216, 211, 211)";
    section24.style.border = "2px solid rgb(216, 211, 211)";
    section25.style.border = "2px solid rgb(216, 211, 211)";
    section26.style.border = "2px solid rgb(216, 211, 211)";
    section27.style.border = "2px solid rgb(216, 211, 211)";
    section28.style.border = "2px solid rgb(216, 211, 211)";
    section29.style.border = "2px solid rgb(216, 211, 211)";
    section30.style.border = "2px solid rgb(216, 211, 211)";
    section31.style.border = "2px solid rgb(216, 211, 211)";
    section32.style.border = "2px solid rgb(216, 211, 211)";
    section33.style.border = "2px solid rgb(216, 211, 211)";
    section34.style.border = "2px solid rgb(216, 211, 211)";
    section35.style.border = "2px solid rgb(216, 211, 211)";
    section36.style.border = "2px solid rgb(216, 211, 211)";
    section37.style.backgroundColor = "black";
    section37.style.cursor = "pointer";
    section37.onmouseover = () => {
        section37.style.cursor = "pointer"
    }
    section37.onmouseout = () => {
        section37.style.cursor = "pointer"
    }
    section6.onmouseover=()=>{
        section6.style.border="3px solid black";
    }
    section6.onmouseout=()=>{
        section6.style.border="2px solid rgb(216, 211, 211)";
    }
    section7.onmouseover=()=>{
        section7.style.border="3px solid black";
    }
    section7.onmouseout=()=>{
        section7.style.border="2px solid rgb(216, 211, 211)";
    }
    section8.onmouseover=()=>{
        section8.style.border="3px solid black";
    }
    section8.onmouseout=()=>{
        section8.style.border="2px solid rgb(216, 211, 211)";
    }
    section9.onmouseover=()=>{
        section9.style.border="3px solid black";
    }
    section9.onmouseout=()=>{
        section9.style.border="2px solid rgb(216, 211, 211)";
    }
    section10.onmouseover=()=>{
        section10.style.border="3px solid black";
    }
    section10.onmouseout=()=>{
        section10.style.border="2px solid rgb(216, 211, 211)";
    }
    section11.onmouseover=()=>{
        section11.style.border="3px solid black";
    }
    section11.onmouseout=()=>{
        section11.style.border="2px solid rgb(216, 211, 211)";
    }
    section12.onmouseover=()=>{
        section12.style.border="3px solid black";
    }
    section12.onmouseout=()=>{
        section12.style.border="2px solid rgb(216, 211, 211)";
    }
    section13.onmouseover=()=>{
        section13.style.border="3px solid black";
    }
    section13.onmouseout=()=>{
        section13.style.border="2px solid rgb(216, 211, 211)";
    }
    section14.onmouseover=()=>{
        section14.style.border="3px solid black";
    }
    section14.onmouseout=()=>{
        section14.style.border="2px solid rgb(216, 211, 211)";
    }
    section15.onmouseover=()=>{
        section15.style.border="3px solid black";
    }
    section15.onmouseout=()=>{
        section15.style.border="2px solid rgb(216, 211, 211)";
    }
    section16.onmouseover=()=>{
        section16.style.border="3px solid black";
    }
    section16.onmouseout=()=>{
        section16.style.border="2px solid rgb(216, 211, 211)";
    }
    section17.onmouseover=()=>{
        section17.style.border="3px solid black";
    }
    section17.onmouseout=()=>{
        section17.style.border="3px solid black";
    }
    section18.onmouseover=()=>{
        section18.style.border="3px solid black";
    }
    section18.onmouseout=()=>{
        section18.style.border="2px solid rgb(216, 211, 211)";
    }
    section19.onmouseover=()=>{
        section19.style.border="3px solid black";
    }
    section19.onmouseout=()=>{
        section19.style.border="2px solid rgb(216, 211, 211)";
    }
    section20.onmouseover=()=>{
        section20.style.border="3px solid black";
    }
    section20.onmouseout=()=>{
        section20.style.border="2px solid rgb(216, 211, 211)";
    }
    section21.onmouseover=()=>{
        section21.style.border="3px solid black";
    }
    section21.onmouseout=()=>{
        section21.style.border="2px solid rgb(216, 211, 211)";
    }
    section22.onmouseover=()=>{
        section22.style.border="3px solid black";
    }
    section22.onmouseout=()=>{
        section22.style.border="2px solid rgb(216, 211, 211)";
    }
    section23.onmouseover=()=>{
        section23.style.border="3px solid black";
    }
    section23.onmouseout=()=>{
        section23.style.border="2px solid rgb(216, 211, 211)";
    }
    section24.onmouseover=()=>{
        section24.style.border="3px solid black";
    }
    section24.onmouseout=()=>{
        section24.style.border="2px solid rgb(216, 211, 211)";
    }
    section25.onmouseover=()=>{
        section25.style.border="3px solid black";
    }
    section25.onmouseout=()=>{
        section25.style.border="2px solid rgb(216, 211, 211)";
    }
    section26.onmouseover=()=>{
        section26.style.border="3px solid black";
    }
    section26.onmouseout=()=>{
        section26.style.border="2px solid rgb(216, 211, 211)";
    }
    section27.onmouseover=()=>{
        section27.style.border="3px solid black";
    }
    section27.onmouseout=()=>{
        section27.style.border="2px solid rgb(216, 211, 211)";
    }
    section28.onmouseover=()=>{
        section28.style.border="3px solid black";
    }
    section28.onmouseout=()=>{
        section28.style.border="2px solid rgb(216, 211, 211)";
    }
    section29.onmouseover=()=>{
        section29.style.border="3px solid black";
    }
    section29.onmouseout=()=>{
        section29.style.border="2px solid rgb(216, 211, 211)";
    }
    section30.onmouseover=()=>{
        section30.style.border="3px solid black";
    }
    section30.onmouseout=()=>{
        section30.style.border="2px solid rgb(216, 211, 211)";
    }
    section31.onmouseover=()=>{
        section31.style.border="3px solid black";
    }
    section31.onmouseout=()=>{
        section31.style.border="2px solid rgb(216, 211, 211)";
    }
    section32.onmouseover=()=>{
        section32.style.border="3px solid black";
    }
    section32.onmouseout=()=>{
        section32.style.border="2px solid rgb(216, 211, 211)";
    }
    section33.onmouseover=()=>{
        section33.style.border="3px solid black";
    }
    section33.onmouseout=()=>{
        section33.style.border="2px solid rgb(216, 211, 211)";
    }
    section34.onmouseover=()=>{
        section34.style.border="3px solid black";
    }
    section34.onmouseout=()=>{
        section34.style.border="2px solid rgb(216, 211, 211)";
    }
    section35.onmouseover=()=>{
        section35.style.border="3px solid black";
    }
    section35.onmouseout=()=>{
        section35.style.border="2px solid rgb(216, 211, 211)";
    }
    section36.onmouseover=()=>{
        section36.style.border="3px solid black";
    }
    section36.onmouseout=()=>{
        section36.style.border="2px solid rgb(216, 211, 211)";
    }
}
function fun13() {
    const section6 = document.getElementById("section6");
    const section7 = document.getElementById("section7");
    const section8 = document.getElementById("section8");
    const section9 = document.getElementById("section9");
    const section10 = document.getElementById("section10");
    const section11 = document.getElementById("section11");
    const section12 = document.getElementById("section12");
    const section13 = document.getElementById("section13");
    const section14 = document.getElementById("section14");
    const section15 = document.getElementById("section15");
    const section16 = document.getElementById("section16");
    const section17 = document.getElementById("section17");
    const section18 = document.getElementById("section18");
    const section19 = document.getElementById("section19");
    const section20 = document.getElementById("section20");
    const section21 = document.getElementById("section21");
    const section22 = document.getElementById("section22");
    const section23 = document.getElementById("section23");
    const section24 = document.getElementById("section24");
    const section25 = document.getElementById("section25");
    const section26 = document.getElementById("section26");
    const section27 = document.getElementById("section27");
    const section28 = document.getElementById("section28");
    const section29 = document.getElementById("section29");
    const section30 = document.getElementById("section30");
    const section31 = document.getElementById("section31");
    const section32 = document.getElementById("section32");
    const section33 = document.getElementById("section33");
    const section34 = document.getElementById("section34");
    const section35 = document.getElementById("section35");
    const section36 = document.getElementById("section36");
    const section37 = document.getElementsByClassName("section37")[0];
    section6.style.border = "2px solid rgb(216, 211, 211)";
    section7.style.border = "2px solid rgb(216, 211, 211)";
    section8.style.border = "2px solid rgb(216, 211, 211)";
    section9.style.border = "2px solid rgb(216, 211, 211)";
    section10.style.border = "2px solid rgb(216, 211, 211)";
    section11.style.border = "2px solid rgb(216, 211, 211)";
    section12.style.border = "2px solid rgb(216, 211, 211)";
    section13.style.border = "2px solid rgb(216, 211, 211)";
    section14.style.border = "2px solid rgb(216, 211, 211)";
    section15.style.border = "2px solid rgb(216, 211, 211)";
    section16.style.border = "2px solid rgb(216, 211, 211)";
    section17.style.border = "2px solid rgb(216, 211, 211)";
    section18.style.border = "3px solid black";
    section19.style.border = "2px solid rgb(216, 211, 211)";
    section20.style.border = "2px solid rgb(216, 211, 211)";
    section21.style.border = "2px solid rgb(216, 211, 211)";
    section22.style.border = "2px solid rgb(216, 211, 211)";
    section23.style.border = "2px solid rgb(216, 211, 211)";
    section24.style.border = "2px solid rgb(216, 211, 211)";
    section25.style.border = "2px solid rgb(216, 211, 211)";
    section26.style.border = "2px solid rgb(216, 211, 211)";
    section27.style.border = "2px solid rgb(216, 211, 211)";
    section28.style.border = "2px solid rgb(216, 211, 211)";
    section29.style.border = "2px solid rgb(216, 211, 211)";
    section30.style.border = "2px solid rgb(216, 211, 211)";
    section31.style.border = "2px solid rgb(216, 211, 211)";
    section32.style.border = "2px solid rgb(216, 211, 211)";
    section33.style.border = "2px solid rgb(216, 211, 211)";
    section34.style.border = "2px solid rgb(216, 211, 211)";
    section35.style.border = "2px solid rgb(216, 211, 211)";
    section36.style.border = "2px solid rgb(216, 211, 211)";
    section37.style.backgroundColor = "black";
    section37.style.cursor = "pointer";
    section37.onmouseover = () => {
        section37.style.cursor = "pointer"
    }
    section37.onmouseout = () => {
        section37.style.cursor = "pointer"
    }
    section6.onmouseover=()=>{
        section6.style.border="3px solid black";
    }
    section6.onmouseout=()=>{
        section6.style.border="2px solid rgb(216, 211, 211)";
    }
    section7.onmouseover=()=>{
        section7.style.border="3px solid black";
    }
    section7.onmouseout=()=>{
        section7.style.border="2px solid rgb(216, 211, 211)";
    }
    section8.onmouseover=()=>{
        section8.style.border="3px solid black";
    }
    section8.onmouseout=()=>{
        section8.style.border="2px solid rgb(216, 211, 211)";
    }
    section9.onmouseover=()=>{
        section9.style.border="3px solid black";
    }
    section9.onmouseout=()=>{
        section9.style.border="2px solid rgb(216, 211, 211)";
    }
    section10.onmouseover=()=>{
        section10.style.border="3px solid black";
    }
    section10.onmouseout=()=>{
        section10.style.border="2px solid rgb(216, 211, 211)";
    }
    section11.onmouseover=()=>{
        section11.style.border="3px solid black";
    }
    section11.onmouseout=()=>{
        section11.style.border="2px solid rgb(216, 211, 211)";
    }
    section12.onmouseover=()=>{
        section12.style.border="3px solid black";
    }
    section12.onmouseout=()=>{
        section12.style.border="2px solid rgb(216, 211, 211)";
    }
    section13.onmouseover=()=>{
        section13.style.border="3px solid black";
    }
    section13.onmouseout=()=>{
        section13.style.border="2px solid rgb(216, 211, 211)";
    }
    section14.onmouseover=()=>{
        section14.style.border="3px solid black";
    }
    section14.onmouseout=()=>{
        section14.style.border="2px solid rgb(216, 211, 211)";
    }
    section15.onmouseover=()=>{
        section15.style.border="3px solid black";
    }
    section15.onmouseout=()=>{
        section15.style.border="2px solid rgb(216, 211, 211)";
    }
    section16.onmouseover=()=>{
        section16.style.border="3px solid black";
    }
    section16.onmouseout=()=>{
        section16.style.border="2px solid rgb(216, 211, 211)";
    }
    section17.onmouseover=()=>{
        section17.style.border="3px solid black";
    }
    section17.onmouseout=()=>{
        section17.style.border="2px solid rgb(216, 211, 211)";
    }
    section18.onmouseover=()=>{
        section18.style.border="3px solid black";
    }
    section18.onmouseout=()=>{
        section18.style.border="3px solid black";
    }
    section19.onmouseover=()=>{
        section19.style.border="3px solid black";
    }
    section19.onmouseout=()=>{
        section19.style.border="2px solid rgb(216, 211, 211)";
    }
    section20.onmouseover=()=>{
        section20.style.border="3px solid black";
    }
    section20.onmouseout=()=>{
        section20.style.border="2px solid rgb(216, 211, 211)";
    }
    section21.onmouseover=()=>{
        section21.style.border="3px solid black";
    }
    section21.onmouseout=()=>{
        section21.style.border="2px solid rgb(216, 211, 211)";
    }
    section22.onmouseover=()=>{
        section22.style.border="3px solid black";
    }
    section22.onmouseout=()=>{
        section22.style.border="2px solid rgb(216, 211, 211)";
    }
    section23.onmouseover=()=>{
        section23.style.border="3px solid black";
    }
    section23.onmouseout=()=>{
        section23.style.border="2px solid rgb(216, 211, 211)";
    }
    section24.onmouseover=()=>{
        section24.style.border="3px solid black";
    }
    section24.onmouseout=()=>{
        section24.style.border="2px solid rgb(216, 211, 211)";
    }
    section25.onmouseover=()=>{
        section25.style.border="3px solid black";
    }
    section25.onmouseout=()=>{
        section25.style.border="2px solid rgb(216, 211, 211)";
    }
    section26.onmouseover=()=>{
        section26.style.border="3px solid black";
    }
    section26.onmouseout=()=>{
        section26.style.border="2px solid rgb(216, 211, 211)";
    }
    section27.onmouseover=()=>{
        section27.style.border="3px solid black";
    }
    section27.onmouseout=()=>{
        section27.style.border="2px solid rgb(216, 211, 211)";
    }
    section28.onmouseover=()=>{
        section28.style.border="3px solid black";
    }
    section28.onmouseout=()=>{
        section28.style.border="2px solid rgb(216, 211, 211)";
    }
    section29.onmouseover=()=>{
        section29.style.border="3px solid black";
    }
    section29.onmouseout=()=>{
        section29.style.border="2px solid rgb(216, 211, 211)";
    }
    section30.onmouseover=()=>{
        section30.style.border="3px solid black";
    }
    section30.onmouseout=()=>{
        section30.style.border="2px solid rgb(216, 211, 211)";
    }
    section31.onmouseover=()=>{
        section31.style.border="3px solid black";
    }
    section31.onmouseout=()=>{
        section31.style.border="2px solid rgb(216, 211, 211)";
    }
    section32.onmouseover=()=>{
        section32.style.border="3px solid black";
    }
    section32.onmouseout=()=>{
        section32.style.border="2px solid rgb(216, 211, 211)";
    }
    section33.onmouseover=()=>{
        section33.style.border="3px solid black";
    }
    section33.onmouseout=()=>{
        section33.style.border="2px solid rgb(216, 211, 211)";
    }
    section34.onmouseover=()=>{
        section34.style.border="3px solid black";
    }
    section34.onmouseout=()=>{
        section34.style.border="2px solid rgb(216, 211, 211)";
    }
    section35.onmouseover=()=>{
        section35.style.border="3px solid black";
    }
    section35.onmouseout=()=>{
        section35.style.border="2px solid rgb(216, 211, 211)";
    }
    section36.onmouseover=()=>{
        section36.style.border="3px solid black";
    }
    section36.onmouseout=()=>{
        section36.style.border="2px solid rgb(216, 211, 211)";
    }
}
function fun14() {
    const section6 = document.getElementById("section6");
    const section7 = document.getElementById("section7");
    const section8 = document.getElementById("section8");
    const section9 = document.getElementById("section9");
    const section10 = document.getElementById("section10");
    const section11 = document.getElementById("section11");
    const section12 = document.getElementById("section12");
    const section13 = document.getElementById("section13");
    const section14 = document.getElementById("section14");
    const section15 = document.getElementById("section15");
    const section16 = document.getElementById("section16");
    const section17 = document.getElementById("section17");
    const section18 = document.getElementById("section18");
    const section19 = document.getElementById("section19");
    const section20 = document.getElementById("section20");
    const section21 = document.getElementById("section21");
    const section22 = document.getElementById("section22");
    const section23 = document.getElementById("section23");
    const section24 = document.getElementById("section24");
    const section25 = document.getElementById("section25");
    const section26 = document.getElementById("section26");
    const section27 = document.getElementById("section27");
    const section28 = document.getElementById("section28");
    const section29 = document.getElementById("section29");
    const section30 = document.getElementById("section30");
    const section31 = document.getElementById("section31");
    const section32 = document.getElementById("section32");
    const section33 = document.getElementById("section33");
    const section34 = document.getElementById("section34");
    const section35 = document.getElementById("section35");
    const section36 = document.getElementById("section36");
    const section37 = document.getElementsByClassName("section37")[0];
    section6.style.border = "2px solid rgb(216, 211, 211)";
    section7.style.border = "2px solid rgb(216, 211, 211)";
    section8.style.border = "2px solid rgb(216, 211, 211)";
    section9.style.border = "2px solid rgb(216, 211, 211)";
    section10.style.border = "2px solid rgb(216, 211, 211)";
    section11.style.border = "2px solid rgb(216, 211, 211)";
    section12.style.border = "2px solid rgb(216, 211, 211)";
    section13.style.border = "2px solid rgb(216, 211, 211)";
    section14.style.border = "2px solid rgb(216, 211, 211)";
    section15.style.border = "2px solid rgb(216, 211, 211)";
    section16.style.border = "2px solid rgb(216, 211, 211)";
    section17.style.border = "2px solid rgb(216, 211, 211)";
    section18.style.border = "2px solid rgb(216, 211, 211)";
    section19.style.border = "3px solid black";
    section20.style.border = "2px solid rgb(216, 211, 211)";
    section21.style.border = "2px solid rgb(216, 211, 211)";
    section22.style.border = "2px solid rgb(216, 211, 211)";
    section23.style.border = "2px solid rgb(216, 211, 211)";
    section24.style.border = "2px solid rgb(216, 211, 211)";
    section25.style.border = "2px solid rgb(216, 211, 211)";
    section26.style.border = "2px solid rgb(216, 211, 211)";
    section27.style.border = "2px solid rgb(216, 211, 211)";
    section28.style.border = "2px solid rgb(216, 211, 211)";
    section29.style.border = "2px solid rgb(216, 211, 211)";
    section30.style.border = "2px solid rgb(216, 211, 211)";
    section31.style.border = "2px solid rgb(216, 211, 211)";
    section32.style.border = "2px solid rgb(216, 211, 211)";
    section33.style.border = "2px solid rgb(216, 211, 211)";
    section34.style.border = "2px solid rgb(216, 211, 211)";
    section35.style.border = "2px solid rgb(216, 211, 211)";
    section36.style.border = "2px solid rgb(216, 211, 211)";
    section37.style.backgroundColor = "black";
    section37.style.cursor = "pointer";
    section37.onmouseover = () => {
        section37.style.cursor = "pointer"
    }
    section37.onmouseout = () => {
        section37.style.cursor = "pointer"
    }
    section6.onmouseover=()=>{
        section6.style.border="3px solid black";
    }
    section6.onmouseout=()=>{
        section6.style.border="2px solid rgb(216, 211, 211)";
    }
    section7.onmouseover=()=>{
        section7.style.border="3px solid black";
    }
    section7.onmouseout=()=>{
        section7.style.border="2px solid rgb(216, 211, 211)";
    }
    section8.onmouseover=()=>{
        section8.style.border="3px solid black";
    }
    section8.onmouseout=()=>{
        section8.style.border="2px solid rgb(216, 211, 211)";
    }
    section9.onmouseover=()=>{
        section9.style.border="3px solid black";
    }
    section9.onmouseout=()=>{
        section9.style.border="2px solid rgb(216, 211, 211)";
    }
    section10.onmouseover=()=>{
        section10.style.border="3px solid black";
    }
    section10.onmouseout=()=>{
        section10.style.border="2px solid rgb(216, 211, 211)";
    }
    section11.onmouseover=()=>{
        section11.style.border="3px solid black";
    }
    section11.onmouseout=()=>{
        section11.style.border="2px solid rgb(216, 211, 211)";
    }
    section12.onmouseover=()=>{
        section12.style.border="3px solid black";
    }
    section12.onmouseout=()=>{
        section12.style.border="2px solid rgb(216, 211, 211)";
    }
    section13.onmouseover=()=>{
        section13.style.border="3px solid black";
    }
    section13.onmouseout=()=>{
        section13.style.border="2px solid rgb(216, 211, 211)";
    }
    section14.onmouseover=()=>{
        section14.style.border="3px solid black";
    }
    section14.onmouseout=()=>{
        section14.style.border="2px solid rgb(216, 211, 211)";
    }
    section15.onmouseover=()=>{
        section15.style.border="3px solid black";
    }
    section15.onmouseout=()=>{
        section15.style.border="2px solid rgb(216, 211, 211)";
    }
    section16.onmouseover=()=>{
        section16.style.border="3px solid black";
    }
    section16.onmouseout=()=>{
        section16.style.border="2px solid rgb(216, 211, 211)";
    }
    section17.onmouseover=()=>{
        section17.style.border="3px solid black";
    }
    section17.onmouseout=()=>{
        section17.style.border="2px solid rgb(216, 211, 211)";
    }
    section18.onmouseover=()=>{
        section18.style.border="3px solid black";
    }
    section18.onmouseout=()=>{
        section18.style.border="2px solid rgb(216, 211, 211)";
    }
    section19.onmouseover=()=>{
        section19.style.border="3px solid black";
    }
    section19.onmouseout=()=>{
        section19.style.border="3px solid black";
    }
    section20.onmouseover=()=>{
        section20.style.border="3px solid black";
    }
    section20.onmouseout=()=>{
        section20.style.border="2px solid rgb(216, 211, 211)";
    }
    section21.onmouseover=()=>{
        section21.style.border="3px solid black";
    }
    section21.onmouseout=()=>{
        section21.style.border="2px solid rgb(216, 211, 211)";
    }
    section22.onmouseover=()=>{
        section22.style.border="3px solid black";
    }
    section22.onmouseout=()=>{
        section22.style.border="2px solid rgb(216, 211, 211)";
    }
    section23.onmouseover=()=>{
        section23.style.border="3px solid black";
    }
    section23.onmouseout=()=>{
        section23.style.border="2px solid rgb(216, 211, 211)";
    }
    section24.onmouseover=()=>{
        section24.style.border="3px solid black";
    }
    section24.onmouseout=()=>{
        section24.style.border="2px solid rgb(216, 211, 211)";
    }
    section25.onmouseover=()=>{
        section25.style.border="3px solid black";
    }
    section25.onmouseout=()=>{
        section25.style.border="2px solid rgb(216, 211, 211)";
    }
    section26.onmouseover=()=>{
        section26.style.border="3px solid black";
    }
    section26.onmouseout=()=>{
        section26.style.border="2px solid rgb(216, 211, 211)";
    }
    section27.onmouseover=()=>{
        section27.style.border="3px solid black";
    }
    section27.onmouseout=()=>{
        section27.style.border="2px solid rgb(216, 211, 211)";
    }
    section28.onmouseover=()=>{
        section28.style.border="3px solid black";
    }
    section28.onmouseout=()=>{
        section28.style.border="2px solid rgb(216, 211, 211)";
    }
    section29.onmouseover=()=>{
        section29.style.border="3px solid black";
    }
    section29.onmouseout=()=>{
        section29.style.border="2px solid rgb(216, 211, 211)";
    }
    section30.onmouseover=()=>{
        section30.style.border="3px solid black";
    }
    section30.onmouseout=()=>{
        section30.style.border="2px solid rgb(216, 211, 211)";
    }
    section31.onmouseover=()=>{
        section31.style.border="3px solid black";
    }
    section31.onmouseout=()=>{
        section31.style.border="2px solid rgb(216, 211, 211)";
    }
    section32.onmouseover=()=>{
        section32.style.border="3px solid black";
    }
    section32.onmouseout=()=>{
        section32.style.border="2px solid rgb(216, 211, 211)";
    }
    section33.onmouseover=()=>{
        section33.style.border="3px solid black";
    }
    section33.onmouseout=()=>{
        section33.style.border="2px solid rgb(216, 211, 211)";
    }
    section34.onmouseover=()=>{
        section34.style.border="3px solid black";
    }
    section34.onmouseout=()=>{
        section34.style.border="2px solid rgb(216, 211, 211)";
    }
    section35.onmouseover=()=>{
        section35.style.border="3px solid black";
    }
    section35.onmouseout=()=>{
        section35.style.border="2px solid rgb(216, 211, 211)";
    }
    section36.onmouseover=()=>{
        section36.style.border="3px solid black";
    }
    section36.onmouseout=()=>{
        section36.style.border="2px solid rgb(216, 211, 211)";
    }
}
function fun15() {
    const section6 = document.getElementById("section6");
    const section7 = document.getElementById("section7");
    const section8 = document.getElementById("section8");
    const section9 = document.getElementById("section9");
    const section10 = document.getElementById("section10");
    const section11 = document.getElementById("section11");
    const section12 = document.getElementById("section12");
    const section13 = document.getElementById("section13");
    const section14 = document.getElementById("section14");
    const section15 = document.getElementById("section15");
    const section16 = document.getElementById("section16");
    const section17 = document.getElementById("section17");
    const section18 = document.getElementById("section18");
    const section19 = document.getElementById("section19");
    const section20 = document.getElementById("section20");
    const section21 = document.getElementById("section21");
    const section22 = document.getElementById("section22");
    const section23 = document.getElementById("section23");
    const section24 = document.getElementById("section24");
    const section25 = document.getElementById("section25");
    const section26 = document.getElementById("section26");
    const section27 = document.getElementById("section27");
    const section28 = document.getElementById("section28");
    const section29 = document.getElementById("section29");
    const section30 = document.getElementById("section30");
    const section31 = document.getElementById("section31");
    const section32 = document.getElementById("section32");
    const section33 = document.getElementById("section33");
    const section34 = document.getElementById("section34");
    const section35 = document.getElementById("section35");
    const section36 = document.getElementById("section36");
    const section37 = document.getElementsByClassName("section37")[0];
    section6.style.border = "2px solid rgb(216, 211, 211)";
    section7.style.border = "2px solid rgb(216, 211, 211)";
    section8.style.border = "2px solid rgb(216, 211, 211)";
    section9.style.border = "2px solid rgb(216, 211, 211)";
    section10.style.border = "2px solid rgb(216, 211, 211)";
    section11.style.border = "2px solid rgb(216, 211, 211)";
    section12.style.border = "2px solid rgb(216, 211, 211)";
    section13.style.border = "2px solid rgb(216, 211, 211)";
    section14.style.border = "2px solid rgb(216, 211, 211)";
    section15.style.border = "2px solid rgb(216, 211, 211)";
    section16.style.border = "2px solid rgb(216, 211, 211)";
    section17.style.border = "2px solid rgb(216, 211, 211)";
    section18.style.border = "2px solid rgb(216, 211, 211)";
    section19.style.border = "2px solid rgb(216, 211, 211)";
    section20.style.border = "3px solid black";
    section21.style.border = "2px solid rgb(216, 211, 211)";
    section22.style.border = "2px solid rgb(216, 211, 211)";
    section23.style.border = "2px solid rgb(216, 211, 211)";
    section24.style.border = "2px solid rgb(216, 211, 211)";
    section25.style.border = "2px solid rgb(216, 211, 211)";
    section26.style.border = "2px solid rgb(216, 211, 211)";
    section27.style.border = "2px solid rgb(216, 211, 211)";
    section28.style.border = "2px solid rgb(216, 211, 211)";
    section29.style.border = "2px solid rgb(216, 211, 211)";
    section30.style.border = "2px solid rgb(216, 211, 211)";
    section31.style.border = "2px solid rgb(216, 211, 211)";
    section32.style.border = "2px solid rgb(216, 211, 211)";
    section33.style.border = "2px solid rgb(216, 211, 211)";
    section34.style.border = "2px solid rgb(216, 211, 211)";
    section35.style.border = "2px solid rgb(216, 211, 211)";
    section36.style.border = "2px solid rgb(216, 211, 211)";
    section37.style.backgroundColor = "black";
    section37.style.cursor = "pointer";
    section37.onmouseover = () => {
        section37.style.cursor = "pointer"
    }
    section37.onmouseout = () => {
        section37.style.cursor = "pointer"
    }
    section6.onmouseover=()=>{
        section6.style.border="3px solid black";
    }
    section6.onmouseout=()=>{
        section6.style.border="2px solid rgb(216, 211, 211)";
    }
    section7.onmouseover=()=>{
        section7.style.border="3px solid black";
    }
    section7.onmouseout=()=>{
        section7.style.border="2px solid rgb(216, 211, 211)";
    }
    section8.onmouseover=()=>{
        section8.style.border="3px solid black";
    }
    section8.onmouseout=()=>{
        section8.style.border="2px solid rgb(216, 211, 211)";
    }
    section9.onmouseover=()=>{
        section9.style.border="3px solid black";
    }
    section9.onmouseout=()=>{
        section9.style.border="2px solid rgb(216, 211, 211)";
    }
    section10.onmouseover=()=>{
        section10.style.border="3px solid black";
    }
    section10.onmouseout=()=>{
        section10.style.border="2px solid rgb(216, 211, 211)";
    }
    section11.onmouseover=()=>{
        section11.style.border="3px solid black";
    }
    section11.onmouseout=()=>{
        section11.style.border="2px solid rgb(216, 211, 211)";
    }
    section12.onmouseover=()=>{
        section12.style.border="3px solid black";
    }
    section12.onmouseout=()=>{
        section12.style.border="2px solid rgb(216, 211, 211)";
    }
    section13.onmouseover=()=>{
        section13.style.border="3px solid black";
    }
    section13.onmouseout=()=>{
        section13.style.border="2px solid rgb(216, 211, 211)";
    }
    section14.onmouseover=()=>{
        section14.style.border="3px solid black";
    }
    section14.onmouseout=()=>{
        section14.style.border="2px solid rgb(216, 211, 211)";
    }
    section15.onmouseover=()=>{
        section15.style.border="3px solid black";
    }
    section15.onmouseout=()=>{
        section15.style.border="2px solid rgb(216, 211, 211)";
    }
    section16.onmouseover=()=>{
        section16.style.border="3px solid black";
    }
    section16.onmouseout=()=>{
        section16.style.border="2px solid rgb(216, 211, 211)";
    }
    section17.onmouseover=()=>{
        section17.style.border="3px solid black";
    }
    section17.onmouseout=()=>{
        section17.style.border="2px solid rgb(216, 211, 211)";
    }
    section18.onmouseover=()=>{
        section18.style.border="3px solid black";
    }
    section18.onmouseout=()=>{
        section18.style.border="2px solid rgb(216, 211, 211)";
    }
    section19.onmouseover=()=>{
        section19.style.border="3px solid black";
    }
    section19.onmouseout=()=>{
        section19.style.border="2px solid rgb(216, 211, 211)";
    }
    section20.onmouseover=()=>{
        section20.style.border="3px solid black";
    }
    section20.onmouseout=()=>{
        section20.style.border="3px solid black";
    }
    section21.onmouseover=()=>{
        section21.style.border="3px solid black";
    }
    section21.onmouseout=()=>{
        section21.style.border="2px solid rgb(216, 211, 211)";
    }
    section22.onmouseover=()=>{
        section22.style.border="3px solid black";
    }
    section22.onmouseout=()=>{
        section22.style.border="2px solid rgb(216, 211, 211)";
    }
    section23.onmouseover=()=>{
        section23.style.border="3px solid black";
    }
    section23.onmouseout=()=>{
        section23.style.border="2px solid rgb(216, 211, 211)";
    }
    section24.onmouseover=()=>{
        section24.style.border="3px solid black";
    }
    section24.onmouseout=()=>{
        section24.style.border="2px solid rgb(216, 211, 211)";
    }
    section25.onmouseover=()=>{
        section25.style.border="3px solid black";
    }
    section25.onmouseout=()=>{
        section25.style.border="2px solid rgb(216, 211, 211)";
    }
    section26.onmouseover=()=>{
        section26.style.border="3px solid black";
    }
    section26.onmouseout=()=>{
        section26.style.border="2px solid rgb(216, 211, 211)";
    }
    section27.onmouseover=()=>{
        section27.style.border="3px solid black";
    }
    section27.onmouseout=()=>{
        section27.style.border="2px solid rgb(216, 211, 211)";
    }
    section28.onmouseover=()=>{
        section28.style.border="3px solid black";
    }
    section28.onmouseout=()=>{
        section28.style.border="2px solid rgb(216, 211, 211)";
    }
    section29.onmouseover=()=>{
        section29.style.border="3px solid black";
    }
    section29.onmouseout=()=>{
        section29.style.border="2px solid rgb(216, 211, 211)";
    }
    section30.onmouseover=()=>{
        section30.style.border="3px solid black";
    }
    section30.onmouseout=()=>{
        section30.style.border="2px solid rgb(216, 211, 211)";
    }
    section31.onmouseover=()=>{
        section31.style.border="3px solid black";
    }
    section31.onmouseout=()=>{
        section31.style.border="2px solid rgb(216, 211, 211)";
    }
    section32.onmouseover=()=>{
        section32.style.border="3px solid black";
    }
    section32.onmouseout=()=>{
        section32.style.border="2px solid rgb(216, 211, 211)";
    }
    section33.onmouseover=()=>{
        section33.style.border="3px solid black";
    }
    section33.onmouseout=()=>{
        section33.style.border="2px solid rgb(216, 211, 211)";
    }
    section34.onmouseover=()=>{
        section34.style.border="3px solid black";
    }
    section34.onmouseout=()=>{
        section34.style.border="2px solid rgb(216, 211, 211)";
    }
    section35.onmouseover=()=>{
        section35.style.border="3px solid black";
    }
    section35.onmouseout=()=>{
        section35.style.border="2px solid rgb(216, 211, 211)";
    }
    section36.onmouseover=()=>{
        section36.style.border="3px solid black";
    }
    section36.onmouseout=()=>{
        section36.style.border="2px solid rgb(216, 211, 211)";
    }
}
function fun16() {
    const section6 = document.getElementById("section6");
    const section7 = document.getElementById("section7");
    const section8 = document.getElementById("section8");
    const section9 = document.getElementById("section9");
    const section10 = document.getElementById("section10");
    const section11 = document.getElementById("section11");
    const section12 = document.getElementById("section12");
    const section13 = document.getElementById("section13");
    const section14 = document.getElementById("section14");
    const section15 = document.getElementById("section15");
    const section16 = document.getElementById("section16");
    const section17 = document.getElementById("section17");
    const section18 = document.getElementById("section18");
    const section19 = document.getElementById("section19");
    const section20 = document.getElementById("section20");
    const section21 = document.getElementById("section21");
    const section22 = document.getElementById("section22");
    const section23 = document.getElementById("section23");
    const section24 = document.getElementById("section24");
    const section25 = document.getElementById("section25");
    const section26 = document.getElementById("section26");
    const section27 = document.getElementById("section27");
    const section28 = document.getElementById("section28");
    const section29 = document.getElementById("section29");
    const section30 = document.getElementById("section30");
    const section31 = document.getElementById("section31");
    const section32 = document.getElementById("section32");
    const section33 = document.getElementById("section33");
    const section34 = document.getElementById("section34");
    const section35 = document.getElementById("section35");
    const section36 = document.getElementById("section36");
    const section37 = document.getElementsByClassName("section37")[0];
    section6.style.border = "2px solid rgb(216, 211, 211)";
    section7.style.border = "2px solid rgb(216, 211, 211)";
    section8.style.border = "2px solid rgb(216, 211, 211)";
    section9.style.border = "2px solid rgb(216, 211, 211)";
    section10.style.border = "2px solid rgb(216, 211, 211)";
    section11.style.border = "2px solid rgb(216, 211, 211)";
    section12.style.border = "2px solid rgb(216, 211, 211)";
    section13.style.border = "2px solid rgb(216, 211, 211)";
    section14.style.border = "2px solid rgb(216, 211, 211)";
    section15.style.border = "2px solid rgb(216, 211, 211)";
    section16.style.border = "2px solid rgb(216, 211, 211)";
    section17.style.border = "2px solid rgb(216, 211, 211)";
    section18.style.border = "2px solid rgb(216, 211, 211)";
    section19.style.border = "2px solid rgb(216, 211, 211)";
    section20.style.border = "2px solid rgb(216, 211, 211)";
    section21.style.border = "3px solid black";
    section22.style.border = "2px solid rgb(216, 211, 211)";
    section23.style.border = "2px solid rgb(216, 211, 211)";
    section24.style.border = "2px solid rgb(216, 211, 211)";
    section25.style.border = "2px solid rgb(216, 211, 211)";
    section26.style.border = "2px solid rgb(216, 211, 211)";
    section27.style.border = "2px solid rgb(216, 211, 211)";
    section28.style.border = "2px solid rgb(216, 211, 211)";
    section29.style.border = "2px solid rgb(216, 211, 211)";
    section30.style.border = "2px solid rgb(216, 211, 211)";
    section31.style.border = "2px solid rgb(216, 211, 211)";
    section32.style.border = "2px solid rgb(216, 211, 211)";
    section33.style.border = "2px solid rgb(216, 211, 211)";
    section34.style.border = "2px solid rgb(216, 211, 211)";
    section35.style.border = "2px solid rgb(216, 211, 211)";
    section36.style.border = "2px solid rgb(216, 211, 211)";
    section37.style.backgroundColor = "black";
    section37.style.cursor = "pointer";
    section37.onmouseover = () => {
        section37.style.cursor = "pointer"
    }
    section37.onmouseout = () => {
        section37.style.cursor = "pointer"
    }
    section6.onmouseover=()=>{
        section6.style.border="3px solid black";
    }
    section6.onmouseout=()=>{
        section6.style.border="2px solid rgb(216, 211, 211)";
    }
    section7.onmouseover=()=>{
        section7.style.border="3px solid black";
    }
    section7.onmouseout=()=>{
        section7.style.border="2px solid rgb(216, 211, 211)";
    }
    section8.onmouseover=()=>{
        section8.style.border="3px solid black";
    }
    section8.onmouseout=()=>{
        section8.style.border="2px solid rgb(216, 211, 211)";
    }
    section9.onmouseover=()=>{
        section9.style.border="3px solid black";
    }
    section9.onmouseout=()=>{
        section9.style.border="2px solid rgb(216, 211, 211)";
    }
    section10.onmouseover=()=>{
        section10.style.border="3px solid black";
    }
    section10.onmouseout=()=>{
        section10.style.border="2px solid rgb(216, 211, 211)";
    }
    section11.onmouseover=()=>{
        section11.style.border="3px solid black";
    }
    section11.onmouseout=()=>{
        section11.style.border="2px solid rgb(216, 211, 211)";
    }
    section12.onmouseover=()=>{
        section12.style.border="3px solid black";
    }
    section12.onmouseout=()=>{
        section12.style.border="2px solid rgb(216, 211, 211)";
    }
    section13.onmouseover=()=>{
        section13.style.border="3px solid black";
    }
    section13.onmouseout=()=>{
        section13.style.border="2px solid rgb(216, 211, 211)";
    }
    section14.onmouseover=()=>{
        section14.style.border="3px solid black";
    }
    section14.onmouseout=()=>{
        section14.style.border="2px solid rgb(216, 211, 211)";
    }
    section15.onmouseover=()=>{
        section15.style.border="3px solid black";
    }
    section15.onmouseout=()=>{
        section15.style.border="2px solid rgb(216, 211, 211)";
    }
    section16.onmouseover=()=>{
        section16.style.border="3px solid black";
    }
    section16.onmouseout=()=>{
        section16.style.border="2px solid rgb(216, 211, 211)";
    }
    section17.onmouseover=()=>{
        section17.style.border="3px solid black";
    }
    section17.onmouseout=()=>{
        section17.style.border="2px solid rgb(216, 211, 211)";
    }
    section18.onmouseover=()=>{
        section18.style.border="3px solid black";
    }
    section18.onmouseout=()=>{
        section18.style.border="2px solid rgb(216, 211, 211)";
    }
    section19.onmouseover=()=>{
        section19.style.border="3px solid black";
    }
    section19.onmouseout=()=>{
        section19.style.border="2px solid rgb(216, 211, 211)";
    }
    section20.onmouseover=()=>{
        section20.style.border="3px solid black";
    }
    section20.onmouseout=()=>{
        section20.style.border="2px solid rgb(216, 211, 211)";
    }
    section21.onmouseover=()=>{
        section21.style.border="3px solid black";
    }
    section21.onmouseout=()=>{
        section21.style.border="3px solid black";
    }
    section22.onmouseover=()=>{
        section22.style.border="3px solid black";
    }
    section22.onmouseout=()=>{
        section22.style.border="2px solid rgb(216, 211, 211)";
    }
    section23.onmouseover=()=>{
        section23.style.border="3px solid black";
    }
    section23.onmouseout=()=>{
        section23.style.border="2px solid rgb(216, 211, 211)";
    }
    section24.onmouseover=()=>{
        section24.style.border="3px solid black";
    }
    section24.onmouseout=()=>{
        section24.style.border="2px solid rgb(216, 211, 211)";
    }
    section25.onmouseover=()=>{
        section25.style.border="3px solid black";
    }
    section25.onmouseout=()=>{
        section25.style.border="2px solid rgb(216, 211, 211)";
    }
    section26.onmouseover=()=>{
        section26.style.border="3px solid black";
    }
    section26.onmouseout=()=>{
        section26.style.border="2px solid rgb(216, 211, 211)";
    }
    section27.onmouseover=()=>{
        section27.style.border="3px solid black";
    }
    section27.onmouseout=()=>{
        section27.style.border="2px solid rgb(216, 211, 211)";
    }
    section28.onmouseover=()=>{
        section28.style.border="3px solid black";
    }
    section28.onmouseout=()=>{
        section28.style.border="2px solid rgb(216, 211, 211)";
    }
    section29.onmouseover=()=>{
        section29.style.border="3px solid black";
    }
    section29.onmouseout=()=>{
        section29.style.border="2px solid rgb(216, 211, 211)";
    }
    section30.onmouseover=()=>{
        section30.style.border="3px solid black";
    }
    section30.onmouseout=()=>{
        section30.style.border="2px solid rgb(216, 211, 211)";
    }
    section31.onmouseover=()=>{
        section31.style.border="3px solid black";
    }
    section31.onmouseout=()=>{
        section31.style.border="2px solid rgb(216, 211, 211)";
    }
    section32.onmouseover=()=>{
        section32.style.border="3px solid black";
    }
    section32.onmouseout=()=>{
        section32.style.border="2px solid rgb(216, 211, 211)";
    }
    section33.onmouseover=()=>{
        section33.style.border="3px solid black";
    }
    section33.onmouseout=()=>{
        section33.style.border="2px solid rgb(216, 211, 211)";
    }
    section34.onmouseover=()=>{
        section34.style.border="3px solid black";
    }
    section34.onmouseout=()=>{
        section34.style.border="2px solid rgb(216, 211, 211)";
    }
    section35.onmouseover=()=>{
        section35.style.border="3px solid black";
    }
    section35.onmouseout=()=>{
        section35.style.border="2px solid rgb(216, 211, 211)";
    }
    section36.onmouseover=()=>{
        section36.style.border="3px solid black";
    }
    section36.onmouseout=()=>{
        section36.style.border="2px solid rgb(216, 211, 211)";
    }
}
function fun17() {
    const section6 = document.getElementById("section6");
    const section7 = document.getElementById("section7");
    const section8 = document.getElementById("section8");
    const section9 = document.getElementById("section9");
    const section10 = document.getElementById("section10");
    const section11 = document.getElementById("section11");
    const section12 = document.getElementById("section12");
    const section13 = document.getElementById("section13");
    const section14 = document.getElementById("section14");
    const section15 = document.getElementById("section15");
    const section16 = document.getElementById("section16");
    const section17 = document.getElementById("section17");
    const section18 = document.getElementById("section18");
    const section19 = document.getElementById("section19");
    const section20 = document.getElementById("section20");
    const section21 = document.getElementById("section21");
    const section22 = document.getElementById("section22");
    const section23 = document.getElementById("section23");
    const section24 = document.getElementById("section24");
    const section25 = document.getElementById("section25");
    const section26 = document.getElementById("section26");
    const section27 = document.getElementById("section27");
    const section28 = document.getElementById("section28");
    const section29 = document.getElementById("section29");
    const section30 = document.getElementById("section30");
    const section31 = document.getElementById("section31");
    const section32 = document.getElementById("section32");
    const section33 = document.getElementById("section33");
    const section34 = document.getElementById("section34");
    const section35 = document.getElementById("section35");
    const section36 = document.getElementById("section36");
    const section37 = document.getElementsByClassName("section37")[0];
    section6.style.border = "2px solid rgb(216, 211, 211)";
    section7.style.border = "2px solid rgb(216, 211, 211)";
    section8.style.border = "2px solid rgb(216, 211, 211)";
    section9.style.border = "2px solid rgb(216, 211, 211)";
    section10.style.border = "2px solid rgb(216, 211, 211)";
    section11.style.border = "2px solid rgb(216, 211, 211)";
    section12.style.border = "2px solid rgb(216, 211, 211)";
    section13.style.border = "2px solid rgb(216, 211, 211)";
    section14.style.border = "2px solid rgb(216, 211, 211)";
    section15.style.border = "2px solid rgb(216, 211, 211)";
    section16.style.border = "2px solid rgb(216, 211, 211)";
    section17.style.border = "2px solid rgb(216, 211, 211)";
    section18.style.border = "2px solid rgb(216, 211, 211)";
    section19.style.border = "2px solid rgb(216, 211, 211)";
    section20.style.border = "2px solid rgb(216, 211, 211)";
    section21.style.border = "2px solid rgb(216, 211, 211)";
    section22.style.border = "3px solid black";
    section23.style.border = "2px solid rgb(216, 211, 211)";
    section24.style.border = "2px solid rgb(216, 211, 211)";
    section25.style.border = "2px solid rgb(216, 211, 211)";
    section26.style.border = "2px solid rgb(216, 211, 211)";
    section27.style.border = "2px solid rgb(216, 211, 211)";
    section28.style.border = "2px solid rgb(216, 211, 211)";
    section29.style.border = "2px solid rgb(216, 211, 211)";
    section30.style.border = "2px solid rgb(216, 211, 211)";
    section31.style.border = "2px solid rgb(216, 211, 211)";
    section32.style.border = "2px solid rgb(216, 211, 211)";
    section33.style.border = "2px solid rgb(216, 211, 211)";
    section34.style.border = "2px solid rgb(216, 211, 211)";
    section35.style.border = "2px solid rgb(216, 211, 211)";
    section36.style.border = "2px solid rgb(216, 211, 211)";
    section37.style.backgroundColor = "black";
    section37.style.cursor = "pointer";
    section37.onmouseover = () => {
        section37.style.cursor = "pointer"
    }
    section37.onmouseout = () => {
        section37.style.cursor = "pointer"
    }
    section6.onmouseover=()=>{
        section6.style.border="3px solid black";
    }
    section6.onmouseout=()=>{
        section6.style.border="2px solid rgb(216, 211, 211)";
    }
    section7.onmouseover=()=>{
        section7.style.border="3px solid black";
    }
    section7.onmouseout=()=>{
        section7.style.border="2px solid rgb(216, 211, 211)";
    }
    section8.onmouseover=()=>{
        section8.style.border="3px solid black";
    }
    section8.onmouseout=()=>{
        section8.style.border="2px solid rgb(216, 211, 211)";
    }
    section9.onmouseover=()=>{
        section9.style.border="3px solid black";
    }
    section9.onmouseout=()=>{
        section9.style.border="2px solid rgb(216, 211, 211)";
    }
    section10.onmouseover=()=>{
        section10.style.border="3px solid black";
    }
    section10.onmouseout=()=>{
        section10.style.border="2px solid rgb(216, 211, 211)";
    }
    section11.onmouseover=()=>{
        section11.style.border="3px solid black";
    }
    section11.onmouseout=()=>{
        section11.style.border="2px solid rgb(216, 211, 211)";
    }
    section12.onmouseover=()=>{
        section12.style.border="3px solid black";
    }
    section12.onmouseout=()=>{
        section12.style.border="2px solid rgb(216, 211, 211)";
    }
    section13.onmouseover=()=>{
        section13.style.border="3px solid black";
    }
    section13.onmouseout=()=>{
        section13.style.border="2px solid rgb(216, 211, 211)";
    }
    section14.onmouseover=()=>{
        section14.style.border="3px solid black";
    }
    section14.onmouseout=()=>{
        section14.style.border="2px solid rgb(216, 211, 211)";
    }
    section15.onmouseover=()=>{
        section15.style.border="3px solid black";
    }
    section15.onmouseout=()=>{
        section15.style.border="2px solid rgb(216, 211, 211)";
    }
    section16.onmouseover=()=>{
        section16.style.border="3px solid black";
    }
    section16.onmouseout=()=>{
        section16.style.border="2px solid rgb(216, 211, 211)";
    }
    section17.onmouseover=()=>{
        section17.style.border="3px solid black";
    }
    section17.onmouseout=()=>{
        section17.style.border="2px solid rgb(216, 211, 211)";
    }
    section18.onmouseover=()=>{
        section18.style.border="3px solid black";
    }
    section18.onmouseout=()=>{
        section18.style.border="2px solid rgb(216, 211, 211)";
    }
    section19.onmouseover=()=>{
        section19.style.border="3px solid black";
    }
    section19.onmouseout=()=>{
        section19.style.border="2px solid rgb(216, 211, 211)";
    }
    section20.onmouseover=()=>{
        section20.style.border="3px solid black";
    }
    section20.onmouseout=()=>{
        section20.style.border="2px solid rgb(216, 211, 211)";
    }
    section21.onmouseover=()=>{
        section21.style.border="3px solid black";
    }
    section21.onmouseout=()=>{
        section21.style.border="2px solid rgb(216, 211, 211)";
    }
    section22.onmouseover=()=>{
        section22.style.border="3px solid black";
    }
    section22.onmouseout=()=>{
        section22.style.border="3px solid black";
    }
    section23.onmouseover=()=>{
        section23.style.border="3px solid black";
    }
    section23.onmouseout=()=>{
        section23.style.border="2px solid rgb(216, 211, 211)";
    }
    section24.onmouseover=()=>{
        section24.style.border="3px solid black";
    }
    section24.onmouseout=()=>{
        section24.style.border="2px solid rgb(216, 211, 211)";
    }
    section25.onmouseover=()=>{
        section25.style.border="3px solid black";
    }
    section25.onmouseout=()=>{
        section25.style.border="2px solid rgb(216, 211, 211)";
    }
    section26.onmouseover=()=>{
        section26.style.border="3px solid black";
    }
    section26.onmouseout=()=>{
        section26.style.border="2px solid rgb(216, 211, 211)";
    }
    section27.onmouseover=()=>{
        section27.style.border="3px solid black";
    }
    section27.onmouseout=()=>{
        section27.style.border="2px solid rgb(216, 211, 211)";
    }
    section28.onmouseover=()=>{
        section28.style.border="3px solid black";
    }
    section28.onmouseout=()=>{
        section28.style.border="2px solid rgb(216, 211, 211)";
    }
    section29.onmouseover=()=>{
        section29.style.border="3px solid black";
    }
    section29.onmouseout=()=>{
        section29.style.border="2px solid rgb(216, 211, 211)";
    }
    section30.onmouseover=()=>{
        section30.style.border="3px solid black";
    }
    section30.onmouseout=()=>{
        section30.style.border="2px solid rgb(216, 211, 211)";
    }
    section31.onmouseover=()=>{
        section31.style.border="3px solid black";
    }
    section31.onmouseout=()=>{
        section31.style.border="2px solid rgb(216, 211, 211)";
    }
    section32.onmouseover=()=>{
        section32.style.border="3px solid black";
    }
    section32.onmouseout=()=>{
        section32.style.border="2px solid rgb(216, 211, 211)";
    }
    section33.onmouseover=()=>{
        section33.style.border="3px solid black";
    }
    section33.onmouseout=()=>{
        section33.style.border="2px solid rgb(216, 211, 211)";
    }
    section34.onmouseover=()=>{
        section34.style.border="3px solid black";
    }
    section34.onmouseout=()=>{
        section34.style.border="2px solid rgb(216, 211, 211)";
    }
    section35.onmouseover=()=>{
        section35.style.border="3px solid black";
    }
    section35.onmouseout=()=>{
        section35.style.border="2px solid rgb(216, 211, 211)";
    }
    section36.onmouseover=()=>{
        section36.style.border="3px solid black";
    }
    section36.onmouseout=()=>{
        section36.style.border="2px solid rgb(216, 211, 211)";
    }
}
function fun18() {
    const section6 = document.getElementById("section6");
    const section7 = document.getElementById("section7");
    const section8 = document.getElementById("section8");
    const section9 = document.getElementById("section9");
    const section10 = document.getElementById("section10");
    const section11 = document.getElementById("section11");
    const section12 = document.getElementById("section12");
    const section13 = document.getElementById("section13");
    const section14 = document.getElementById("section14");
    const section15 = document.getElementById("section15");
    const section16 = document.getElementById("section16");
    const section17 = document.getElementById("section17");
    const section18 = document.getElementById("section18");
    const section19 = document.getElementById("section19");
    const section20 = document.getElementById("section20");
    const section21 = document.getElementById("section21");
    const section22 = document.getElementById("section22");
    const section23 = document.getElementById("section23");
    const section24 = document.getElementById("section24");
    const section25 = document.getElementById("section25");
    const section26 = document.getElementById("section26");
    const section27 = document.getElementById("section27");
    const section28 = document.getElementById("section28");
    const section29 = document.getElementById("section29");
    const section30 = document.getElementById("section30");
    const section31 = document.getElementById("section31");
    const section32 = document.getElementById("section32");
    const section33 = document.getElementById("section33");
    const section34 = document.getElementById("section34");
    const section35 = document.getElementById("section35");
    const section36 = document.getElementById("section36");
    const section37 = document.getElementsByClassName("section37")[0];
    section6.style.border = "2px solid rgb(216, 211, 211)";
    section7.style.border = "2px solid rgb(216, 211, 211)";
    section8.style.border = "2px solid rgb(216, 211, 211)";
    section9.style.border = "2px solid rgb(216, 211, 211)";
    section10.style.border = "2px solid rgb(216, 211, 211)";
    section11.style.border = "2px solid rgb(216, 211, 211)";
    section12.style.border = "2px solid rgb(216, 211, 211)";
    section13.style.border = "2px solid rgb(216, 211, 211)";
    section14.style.border = "2px solid rgb(216, 211, 211)";
    section15.style.border = "2px solid rgb(216, 211, 211)";
    section16.style.border = "2px solid rgb(216, 211, 211)";
    section17.style.border = "2px solid rgb(216, 211, 211)";
    section18.style.border = "2px solid rgb(216, 211, 211)";
    section19.style.border = "2px solid rgb(216, 211, 211)";
    section20.style.border = "2px solid rgb(216, 211, 211)";
    section21.style.border = "2px solid rgb(216, 211, 211)";
    section22.style.border = "2px solid rgb(216, 211, 211)";
    section23.style.border = "3px solid black";
    section24.style.border = "2px solid rgb(216, 211, 211)";
    section25.style.border = "2px solid rgb(216, 211, 211)";
    section26.style.border = "2px solid rgb(216, 211, 211)";
    section27.style.border = "2px solid rgb(216, 211, 211)";
    section28.style.border = "2px solid rgb(216, 211, 211)";
    section29.style.border = "2px solid rgb(216, 211, 211)";
    section30.style.border = "2px solid rgb(216, 211, 211)";
    section31.style.border = "2px solid rgb(216, 211, 211)";
    section32.style.border = "2px solid rgb(216, 211, 211)";
    section33.style.border = "2px solid rgb(216, 211, 211)";
    section34.style.border = "2px solid rgb(216, 211, 211)";
    section35.style.border = "2px solid rgb(216, 211, 211)";
    section36.style.border = "2px solid rgb(216, 211, 211)";
    section37.style.backgroundColor = "black";
    section37.style.cursor = "pointer";
    section37.onmouseover = () => {
        section37.style.cursor = "pointer"
    }
    section37.onmouseout = () => {
        section37.style.cursor = "pointer"
    }
    section6.onmouseover=()=>{
        section6.style.border="3px solid black";
    }
    section6.onmouseout=()=>{
        section6.style.border="2px solid rgb(216, 211, 211)";
    }
    section7.onmouseover=()=>{
        section7.style.border="3px solid black";
    }
    section7.onmouseout=()=>{
        section7.style.border="2px solid rgb(216, 211, 211)";
    }
    section8.onmouseover=()=>{
        section8.style.border="3px solid black";
    }
    section8.onmouseout=()=>{
        section8.style.border="2px solid rgb(216, 211, 211)";
    }
    section9.onmouseover=()=>{
        section9.style.border="3px solid black";
    }
    section9.onmouseout=()=>{
        section9.style.border="2px solid rgb(216, 211, 211)";
    }
    section10.onmouseover=()=>{
        section10.style.border="3px solid black";
    }
    section10.onmouseout=()=>{
        section10.style.border="2px solid rgb(216, 211, 211)";
    }
    section11.onmouseover=()=>{
        section11.style.border="3px solid black";
    }
    section11.onmouseout=()=>{
        section11.style.border="2px solid rgb(216, 211, 211)";
    }
    section12.onmouseover=()=>{
        section12.style.border="3px solid black";
    }
    section12.onmouseout=()=>{
        section12.style.border="2px solid rgb(216, 211, 211)";
    }
    section13.onmouseover=()=>{
        section13.style.border="3px solid black";
    }
    section13.onmouseout=()=>{
        section13.style.border="2px solid rgb(216, 211, 211)";
    }
    section14.onmouseover=()=>{
        section14.style.border="3px solid black";
    }
    section14.onmouseout=()=>{
        section14.style.border="2px solid rgb(216, 211, 211)";
    }
    section15.onmouseover=()=>{
        section15.style.border="3px solid black";
    }
    section15.onmouseout=()=>{
        section15.style.border="2px solid rgb(216, 211, 211)";
    }
    section16.onmouseover=()=>{
        section16.style.border="3px solid black";
    }
    section16.onmouseout=()=>{
        section16.style.border="2px solid rgb(216, 211, 211)";
    }
    section17.onmouseover=()=>{
        section17.style.border="3px solid black";
    }
    section17.onmouseout=()=>{
        section17.style.border="2px solid rgb(216, 211, 211)";
    }
    section18.onmouseover=()=>{
        section18.style.border="3px solid black";
    }
    section18.onmouseout=()=>{
        section18.style.border="2px solid rgb(216, 211, 211)";
    }
    section19.onmouseover=()=>{
        section19.style.border="3px solid black";
    }
    section19.onmouseout=()=>{
        section19.style.border="2px solid rgb(216, 211, 211)";
    }
    section20.onmouseover=()=>{
        section20.style.border="3px solid black";
    }
    section20.onmouseout=()=>{
        section20.style.border="2px solid rgb(216, 211, 211)";
    }
    section21.onmouseover=()=>{
        section21.style.border="3px solid black";
    }
    section21.onmouseout=()=>{
        section21.style.border="2px solid rgb(216, 211, 211)";
    }
    section22.onmouseover=()=>{
        section22.style.border="3px solid black";
    }
    section22.onmouseout=()=>{
        section22.style.border="2px solid rgb(216, 211, 211)";
    }
    section23.onmouseover=()=>{
        section23.style.border="3px solid black";
    }
    section23.onmouseout=()=>{
        section23.style.border="3px solid black";
    }
    section24.onmouseover=()=>{
        section24.style.border="3px solid black";
    }
    section24.onmouseout=()=>{
        section24.style.border="2px solid rgb(216, 211, 211)";
    }
    section25.onmouseover=()=>{
        section25.style.border="3px solid black";
    }
    section25.onmouseout=()=>{
        section25.style.border="2px solid rgb(216, 211, 211)";
    }
    section26.onmouseover=()=>{
        section26.style.border="3px solid black";
    }
    section26.onmouseout=()=>{
        section26.style.border="2px solid rgb(216, 211, 211)";
    }
    section27.onmouseover=()=>{
        section27.style.border="3px solid black";
    }
    section27.onmouseout=()=>{
        section27.style.border="2px solid rgb(216, 211, 211)";
    }
    section28.onmouseover=()=>{
        section28.style.border="3px solid black";
    }
    section28.onmouseout=()=>{
        section28.style.border="2px solid rgb(216, 211, 211)";
    }
    section29.onmouseover=()=>{
        section29.style.border="3px solid black";
    }
    section29.onmouseout=()=>{
        section29.style.border="2px solid rgb(216, 211, 211)";
    }
    section30.onmouseover=()=>{
        section30.style.border="3px solid black";
    }
    section30.onmouseout=()=>{
        section30.style.border="2px solid rgb(216, 211, 211)";
    }
    section31.onmouseover=()=>{
        section31.style.border="3px solid black";
    }
    section31.onmouseout=()=>{
        section31.style.border="2px solid rgb(216, 211, 211)";
    }
    section32.onmouseover=()=>{
        section32.style.border="3px solid black";
    }
    section32.onmouseout=()=>{
        section32.style.border="2px solid rgb(216, 211, 211)";
    }
    section33.onmouseover=()=>{
        section33.style.border="3px solid black";
    }
    section33.onmouseout=()=>{
        section33.style.border="2px solid rgb(216, 211, 211)";
    }
    section34.onmouseover=()=>{
        section34.style.border="3px solid black";
    }
    section34.onmouseout=()=>{
        section34.style.border="2px solid rgb(216, 211, 211)";
    }
    section35.onmouseover=()=>{
        section35.style.border="3px solid black";
    }
    section35.onmouseout=()=>{
        section35.style.border="2px solid rgb(216, 211, 211)";
    }
    section36.onmouseover=()=>{
        section36.style.border="3px solid black";
    }
    section36.onmouseout=()=>{
        section36.style.border="2px solid rgb(216, 211, 211)";
    }
}
function fun19() {
    const section6 = document.getElementById("section6");
    const section7 = document.getElementById("section7");
    const section8 = document.getElementById("section8");
    const section9 = document.getElementById("section9");
    const section10 = document.getElementById("section10");
    const section11 = document.getElementById("section11");
    const section12 = document.getElementById("section12");
    const section13 = document.getElementById("section13");
    const section14 = document.getElementById("section14");
    const section15 = document.getElementById("section15");
    const section16 = document.getElementById("section16");
    const section17 = document.getElementById("section17");
    const section18 = document.getElementById("section18");
    const section19 = document.getElementById("section19");
    const section20 = document.getElementById("section20");
    const section21 = document.getElementById("section21");
    const section22 = document.getElementById("section22");
    const section23 = document.getElementById("section23");
    const section24 = document.getElementById("section24");
    const section25 = document.getElementById("section25");
    const section26 = document.getElementById("section26");
    const section27 = document.getElementById("section27");
    const section28 = document.getElementById("section28");
    const section29 = document.getElementById("section29");
    const section30 = document.getElementById("section30");
    const section31 = document.getElementById("section31");
    const section32 = document.getElementById("section32");
    const section33 = document.getElementById("section33");
    const section34 = document.getElementById("section34");
    const section35 = document.getElementById("section35");
    const section36 = document.getElementById("section36");
    const section37 = document.getElementsByClassName("section37")[0];
    section6.style.border = "2px solid rgb(216, 211, 211)";
    section7.style.border = "2px solid rgb(216, 211, 211)";
    section8.style.border = "2px solid rgb(216, 211, 211)";
    section9.style.border = "2px solid rgb(216, 211, 211)";
    section10.style.border = "2px solid rgb(216, 211, 211)";
    section11.style.border = "2px solid rgb(216, 211, 211)";
    section12.style.border = "2px solid rgb(216, 211, 211)";
    section13.style.border = "2px solid rgb(216, 211, 211)";
    section14.style.border = "2px solid rgb(216, 211, 211)";
    section15.style.border = "2px solid rgb(216, 211, 211)";
    section16.style.border = "2px solid rgb(216, 211, 211)";
    section17.style.border = "2px solid rgb(216, 211, 211)";
    section18.style.border = "2px solid rgb(216, 211, 211)";
    section19.style.border = "2px solid rgb(216, 211, 211)";
    section20.style.border = "2px solid rgb(216, 211, 211)";
    section21.style.border = "2px solid rgb(216, 211, 211)";
    section22.style.border = "2px solid rgb(216, 211, 211)";
    section23.style.border = "2px solid rgb(216, 211, 211)";
    section24.style.border = "3px solid black";
    section25.style.border = "2px solid rgb(216, 211, 211)";
    section26.style.border = "2px solid rgb(216, 211, 211)";
    section27.style.border = "2px solid rgb(216, 211, 211)";
    section28.style.border = "2px solid rgb(216, 211, 211)";
    section29.style.border = "2px solid rgb(216, 211, 211)";
    section30.style.border = "2px solid rgb(216, 211, 211)";
    section31.style.border = "2px solid rgb(216, 211, 211)";
    section32.style.border = "2px solid rgb(216, 211, 211)";
    section33.style.border = "2px solid rgb(216, 211, 211)";
    section34.style.border = "2px solid rgb(216, 211, 211)";
    section35.style.border = "2px solid rgb(216, 211, 211)";
    section36.style.border = "2px solid rgb(216, 211, 211)";
    section37.style.backgroundColor = "black";
    section37.style.cursor = "pointer";
    section37.onmouseover = () => {
        section37.style.cursor = "pointer"
    }
    section37.onmouseout = () => {
        section37.style.cursor = "pointer"
    }
    section6.onmouseover=()=>{
        section6.style.border="3px solid black";
    }
    section6.onmouseout=()=>{
        section6.style.border="2px solid rgb(216, 211, 211)";
    }
    section7.onmouseover=()=>{
        section7.style.border="3px solid black";
    }
    section7.onmouseout=()=>{
        section7.style.border="2px solid rgb(216, 211, 211)";
    }
    section8.onmouseover=()=>{
        section8.style.border="3px solid black";
    }
    section8.onmouseout=()=>{
        section8.style.border="2px solid rgb(216, 211, 211)";
    }
    section9.onmouseover=()=>{
        section9.style.border="3px solid black";
    }
    section9.onmouseout=()=>{
        section9.style.border="2px solid rgb(216, 211, 211)";
    }
    section10.onmouseover=()=>{
        section10.style.border="3px solid black";
    }
    section10.onmouseout=()=>{
        section10.style.border="2px solid rgb(216, 211, 211)";
    }
    section11.onmouseover=()=>{
        section11.style.border="3px solid black";
    }
    section11.onmouseout=()=>{
        section11.style.border="2px solid rgb(216, 211, 211)";
    }
    section12.onmouseover=()=>{
        section12.style.border="3px solid black";
    }
    section12.onmouseout=()=>{
        section12.style.border="2px solid rgb(216, 211, 211)";
    }
    section13.onmouseover=()=>{
        section13.style.border="3px solid black";
    }
    section13.onmouseout=()=>{
        section13.style.border="2px solid rgb(216, 211, 211)";
    }
    section14.onmouseover=()=>{
        section14.style.border="3px solid black";
    }
    section14.onmouseout=()=>{
        section14.style.border="2px solid rgb(216, 211, 211)";
    }
    section15.onmouseover=()=>{
        section15.style.border="3px solid black";
    }
    section15.onmouseout=()=>{
        section15.style.border="2px solid rgb(216, 211, 211)";
    }
    section16.onmouseover=()=>{
        section16.style.border="3px solid black";
    }
    section16.onmouseout=()=>{
        section16.style.border="2px solid rgb(216, 211, 211)";
    }
    section17.onmouseover=()=>{
        section17.style.border="3px solid black";
    }
    section17.onmouseout=()=>{
        section17.style.border="2px solid rgb(216, 211, 211)";
    }
    section18.onmouseover=()=>{
        section18.style.border="3px solid black";
    }
    section18.onmouseout=()=>{
        section18.style.border="2px solid rgb(216, 211, 211)";
    }
    section19.onmouseover=()=>{
        section19.style.border="3px solid black";
    }
    section19.onmouseout=()=>{
        section19.style.border="2px solid rgb(216, 211, 211)";
    }
    section20.onmouseover=()=>{
        section20.style.border="3px solid black";
    }
    section20.onmouseout=()=>{
        section20.style.border="2px solid rgb(216, 211, 211)";
    }
    section21.onmouseover=()=>{
        section21.style.border="3px solid black";
    }
    section21.onmouseout=()=>{
        section21.style.border="2px solid rgb(216, 211, 211)";
    }
    section22.onmouseover=()=>{
        section22.style.border="3px solid black";
    }
    section22.onmouseout=()=>{
        section22.style.border="2px solid rgb(216, 211, 211)";
    }
    section23.onmouseover=()=>{
        section23.style.border="3px solid black";
    }
    section23.onmouseout=()=>{
        section23.style.border="2px solid rgb(216, 211, 211)";
    }
    section24.onmouseover=()=>{
        section24.style.border="3px solid black";
    }
    section24.onmouseout=()=>{
        section24.style.border="3px solid black";
    }
    section25.onmouseover=()=>{
        section25.style.border="3px solid black";
    }
    section25.onmouseout=()=>{
        section25.style.border="2px solid rgb(216, 211, 211)";
    }
    section26.onmouseover=()=>{
        section26.style.border="3px solid black";
    }
    section26.onmouseout=()=>{
        section26.style.border="2px solid rgb(216, 211, 211)";
    }
    section27.onmouseover=()=>{
        section27.style.border="3px solid black";
    }
    section27.onmouseout=()=>{
        section27.style.border="2px solid rgb(216, 211, 211)";
    }
    section28.onmouseover=()=>{
        section28.style.border="3px solid black";
    }
    section28.onmouseout=()=>{
        section28.style.border="2px solid rgb(216, 211, 211)";
    }
    section29.onmouseover=()=>{
        section29.style.border="3px solid black";
    }
    section29.onmouseout=()=>{
        section29.style.border="2px solid rgb(216, 211, 211)";
    }
    section30.onmouseover=()=>{
        section30.style.border="3px solid black";
    }
    section30.onmouseout=()=>{
        section30.style.border="2px solid rgb(216, 211, 211)";
    }
    section31.onmouseover=()=>{
        section31.style.border="3px solid black";
    }
    section31.onmouseout=()=>{
        section31.style.border="2px solid rgb(216, 211, 211)";
    }
    section32.onmouseover=()=>{
        section32.style.border="3px solid black";
    }
    section32.onmouseout=()=>{
        section32.style.border="2px solid rgb(216, 211, 211)";
    }
    section33.onmouseover=()=>{
        section33.style.border="3px solid black";
    }
    section33.onmouseout=()=>{
        section33.style.border="2px solid rgb(216, 211, 211)";
    }
    section34.onmouseover=()=>{
        section34.style.border="3px solid black";
    }
    section34.onmouseout=()=>{
        section34.style.border="2px solid rgb(216, 211, 211)";
    }
    section35.onmouseover=()=>{
        section35.style.border="3px solid black";
    }
    section35.onmouseout=()=>{
        section35.style.border="2px solid rgb(216, 211, 211)";
    }
    section36.onmouseover=()=>{
        section36.style.border="3px solid black";
    }
    section36.onmouseout=()=>{
        section36.style.border="2px solid rgb(216, 211, 211)";
    }
}
function fun20() {
    const section6 = document.getElementById("section6");
    const section7 = document.getElementById("section7");
    const section8 = document.getElementById("section8");
    const section9 = document.getElementById("section9");
    const section10 = document.getElementById("section10");
    const section11 = document.getElementById("section11");
    const section12 = document.getElementById("section12");
    const section13 = document.getElementById("section13");
    const section14 = document.getElementById("section14");
    const section15 = document.getElementById("section15");
    const section16 = document.getElementById("section16");
    const section17 = document.getElementById("section17");
    const section18 = document.getElementById("section18");
    const section19 = document.getElementById("section19");
    const section20 = document.getElementById("section20");
    const section21 = document.getElementById("section21");
    const section22 = document.getElementById("section22");
    const section23 = document.getElementById("section23");
    const section24 = document.getElementById("section24");
    const section25 = document.getElementById("section25");
    const section26 = document.getElementById("section26");
    const section27 = document.getElementById("section27");
    const section28 = document.getElementById("section28");
    const section29 = document.getElementById("section29");
    const section30 = document.getElementById("section30");
    const section31 = document.getElementById("section31");
    const section32 = document.getElementById("section32");
    const section33 = document.getElementById("section33");
    const section34 = document.getElementById("section34");
    const section35 = document.getElementById("section35");
    const section36 = document.getElementById("section36");
    const section37 = document.getElementsByClassName("section37")[0];
    section6.style.border = "2px solid rgb(216, 211, 211)";
    section7.style.border = "2px solid rgb(216, 211, 211)";
    section8.style.border = "2px solid rgb(216, 211, 211)";
    section9.style.border = "2px solid rgb(216, 211, 211)";
    section10.style.border = "2px solid rgb(216, 211, 211)";
    section11.style.border = "2px solid rgb(216, 211, 211)";
    section12.style.border = "2px solid rgb(216, 211, 211)";
    section13.style.border = "2px solid rgb(216, 211, 211)";
    section14.style.border = "2px solid rgb(216, 211, 211)";
    section15.style.border = "2px solid rgb(216, 211, 211)";
    section16.style.border = "2px solid rgb(216, 211, 211)";
    section17.style.border = "2px solid rgb(216, 211, 211)";
    section18.style.border = "2px solid rgb(216, 211, 211)";
    section19.style.border = "2px solid rgb(216, 211, 211)";
    section20.style.border = "2px solid rgb(216, 211, 211)";
    section21.style.border = "2px solid rgb(216, 211, 211)";
    section22.style.border = "2px solid rgb(216, 211, 211)";
    section23.style.border = "2px solid rgb(216, 211, 211)";
    section24.style.border = "2px solid rgb(216, 211, 211)";
    section25.style.border = "3px solid black";
    section26.style.border = "2px solid rgb(216, 211, 211)";
    section27.style.border = "2px solid rgb(216, 211, 211)";
    section28.style.border = "2px solid rgb(216, 211, 211)";
    section29.style.border = "2px solid rgb(216, 211, 211)";
    section30.style.border = "2px solid rgb(216, 211, 211)";
    section31.style.border = "2px solid rgb(216, 211, 211)";
    section32.style.border = "2px solid rgb(216, 211, 211)";
    section33.style.border = "2px solid rgb(216, 211, 211)";
    section34.style.border = "2px solid rgb(216, 211, 211)";
    section35.style.border = "2px solid rgb(216, 211, 211)";
    section36.style.border = "2px solid rgb(216, 211, 211)";
    section37.style.backgroundColor = "black";
    section37.style.cursor = "pointer";
    section37.onmouseover = () => {
        section37.style.cursor = "pointer"
    }
    section37.onmouseout = () => {
        section37.style.cursor = "pointer"
    }
    section6.onmouseover=()=>{
        section6.style.border="3px solid black";
    }
    section6.onmouseout=()=>{
        section6.style.border="2px solid rgb(216, 211, 211)";
    }
    section7.onmouseover=()=>{
        section7.style.border="3px solid black";
    }
    section7.onmouseout=()=>{
        section7.style.border="2px solid rgb(216, 211, 211)";
    }
    section8.onmouseover=()=>{
        section8.style.border="3px solid black";
    }
    section8.onmouseout=()=>{
        section8.style.border="2px solid rgb(216, 211, 211)";
    }
    section9.onmouseover=()=>{
        section9.style.border="3px solid black";
    }
    section9.onmouseout=()=>{
        section9.style.border="2px solid rgb(216, 211, 211)";
    }
    section10.onmouseover=()=>{
        section10.style.border="3px solid black";
    }
    section10.onmouseout=()=>{
        section10.style.border="2px solid rgb(216, 211, 211)";
    }
    section11.onmouseover=()=>{
        section11.style.border="3px solid black";
    }
    section11.onmouseout=()=>{
        section11.style.border="2px solid rgb(216, 211, 211)";
    }
    section12.onmouseover=()=>{
        section12.style.border="3px solid black";
    }
    section12.onmouseout=()=>{
        section12.style.border="2px solid rgb(216, 211, 211)";
    }
    section13.onmouseover=()=>{
        section13.style.border="3px solid black";
    }
    section13.onmouseout=()=>{
        section13.style.border="2px solid rgb(216, 211, 211)";
    }
    section14.onmouseover=()=>{
        section14.style.border="3px solid black";
    }
    section14.onmouseout=()=>{
        section14.style.border="2px solid rgb(216, 211, 211)";
    }
    section15.onmouseover=()=>{
        section15.style.border="3px solid black";
    }
    section15.onmouseout=()=>{
        section15.style.border="2px solid rgb(216, 211, 211)";
    }
    section16.onmouseover=()=>{
        section16.style.border="3px solid black";
    }
    section16.onmouseout=()=>{
        section16.style.border="2px solid rgb(216, 211, 211)";
    }
    section17.onmouseover=()=>{
        section17.style.border="3px solid black";
    }
    section17.onmouseout=()=>{
        section17.style.border="2px solid rgb(216, 211, 211)";
    }
    section18.onmouseover=()=>{
        section18.style.border="3px solid black";
    }
    section18.onmouseout=()=>{
        section18.style.border="2px solid rgb(216, 211, 211)";
    }
    section19.onmouseover=()=>{
        section19.style.border="3px solid black";
    }
    section19.onmouseout=()=>{
        section19.style.border="2px solid rgb(216, 211, 211)";
    }
    section20.onmouseover=()=>{
        section20.style.border="3px solid black";
    }
    section20.onmouseout=()=>{
        section20.style.border="2px solid rgb(216, 211, 211)";
    }
    section21.onmouseover=()=>{
        section21.style.border="3px solid black";
    }
    section21.onmouseout=()=>{
        section21.style.border="2px solid rgb(216, 211, 211)";
    }
    section22.onmouseover=()=>{
        section22.style.border="3px solid black";
    }
    section22.onmouseout=()=>{
        section22.style.border="2px solid rgb(216, 211, 211)";
    }
    section23.onmouseover=()=>{
        section23.style.border="3px solid black";
    }
    section23.onmouseout=()=>{
        section23.style.border="2px solid rgb(216, 211, 211)";
    }
    section24.onmouseover=()=>{
        section24.style.border="3px solid black";
    }
    section24.onmouseout=()=>{
        section24.style.border="2px solid rgb(216, 211, 211)";
    }
    section25.onmouseover=()=>{
        section25.style.border="3px solid black";
    }
    section25.onmouseout=()=>{
        section25.style.border="3px solid black";
    }
    section26.onmouseover=()=>{
        section26.style.border="3px solid black";
    }
    section26.onmouseout=()=>{
        section26.style.border="2px solid rgb(216, 211, 211)";
    }
    section27.onmouseover=()=>{
        section27.style.border="3px solid black";
    }
    section27.onmouseout=()=>{
        section27.style.border="2px solid rgb(216, 211, 211)";
    }
    section28.onmouseover=()=>{
        section28.style.border="3px solid black";
    }
    section28.onmouseout=()=>{
        section28.style.border="2px solid rgb(216, 211, 211)";
    }
    section29.onmouseover=()=>{
        section29.style.border="3px solid black";
    }
    section29.onmouseout=()=>{
        section29.style.border="2px solid rgb(216, 211, 211)";
    }
    section30.onmouseover=()=>{
        section30.style.border="3px solid black";
    }
    section30.onmouseout=()=>{
        section30.style.border="2px solid rgb(216, 211, 211)";
    }
    section31.onmouseover=()=>{
        section31.style.border="3px solid black";
    }
    section31.onmouseout=()=>{
        section31.style.border="2px solid rgb(216, 211, 211)";
    }
    section32.onmouseover=()=>{
        section32.style.border="3px solid black";
    }
    section32.onmouseout=()=>{
        section32.style.border="2px solid rgb(216, 211, 211)";
    }
    section33.onmouseover=()=>{
        section33.style.border="3px solid black";
    }
    section33.onmouseout=()=>{
        section33.style.border="2px solid rgb(216, 211, 211)";
    }
    section34.onmouseover=()=>{
        section34.style.border="3px solid black";
    }
    section34.onmouseout=()=>{
        section34.style.border="2px solid rgb(216, 211, 211)";
    }
    section35.onmouseover=()=>{
        section35.style.border="3px solid black";
    }
    section35.onmouseout=()=>{
        section35.style.border="2px solid rgb(216, 211, 211)";
    }
    section36.onmouseover=()=>{
        section36.style.border="3px solid black";
    }
    section36.onmouseout=()=>{
        section36.style.border="2px solid rgb(216, 211, 211)";
    }
}
function fun21() {
    const section6 = document.getElementById("section6");
    const section7 = document.getElementById("section7");
    const section8 = document.getElementById("section8");
    const section9 = document.getElementById("section9");
    const section10 = document.getElementById("section10");
    const section11 = document.getElementById("section11");
    const section12 = document.getElementById("section12");
    const section13 = document.getElementById("section13");
    const section14 = document.getElementById("section14");
    const section15 = document.getElementById("section15");
    const section16 = document.getElementById("section16");
    const section17 = document.getElementById("section17");
    const section18 = document.getElementById("section18");
    const section19 = document.getElementById("section19");
    const section20 = document.getElementById("section20");
    const section21 = document.getElementById("section21");
    const section22 = document.getElementById("section22");
    const section23 = document.getElementById("section23");
    const section24 = document.getElementById("section24");
    const section25 = document.getElementById("section25");
    const section26 = document.getElementById("section26");
    const section27 = document.getElementById("section27");
    const section28 = document.getElementById("section28");
    const section29 = document.getElementById("section29");
    const section30 = document.getElementById("section30");
    const section31 = document.getElementById("section31");
    const section32 = document.getElementById("section32");
    const section33 = document.getElementById("section33");
    const section34 = document.getElementById("section34");
    const section35 = document.getElementById("section35");
    const section36 = document.getElementById("section36");
    const section37 = document.getElementsByClassName("section37")[0];
    section6.style.border = "2px solid rgb(216, 211, 211)";
    section7.style.border = "2px solid rgb(216, 211, 211)";
    section8.style.border = "2px solid rgb(216, 211, 211)";
    section9.style.border = "2px solid rgb(216, 211, 211)";
    section10.style.border = "2px solid rgb(216, 211, 211)";
    section11.style.border = "2px solid rgb(216, 211, 211)";
    section12.style.border = "2px solid rgb(216, 211, 211)";
    section13.style.border = "2px solid rgb(216, 211, 211)";
    section14.style.border = "2px solid rgb(216, 211, 211)";
    section15.style.border = "2px solid rgb(216, 211, 211)";
    section16.style.border = "2px solid rgb(216, 211, 211)";
    section17.style.border = "2px solid rgb(216, 211, 211)";
    section18.style.border = "2px solid rgb(216, 211, 211)";
    section19.style.border = "2px solid rgb(216, 211, 211)";
    section20.style.border = "2px solid rgb(216, 211, 211)";
    section21.style.border = "2px solid rgb(216, 211, 211)";
    section22.style.border = "2px solid rgb(216, 211, 211)";
    section23.style.border = "2px solid rgb(216, 211, 211)";
    section24.style.border = "2px solid rgb(216, 211, 211)";
    section25.style.border = "2px solid rgb(216, 211, 211)";
    section26.style.border = "3px solid black";
    section27.style.border = "2px solid rgb(216, 211, 211)";
    section28.style.border = "2px solid rgb(216, 211, 211)";
    section29.style.border = "2px solid rgb(216, 211, 211)";
    section30.style.border = "2px solid rgb(216, 211, 211)";
    section31.style.border = "2px solid rgb(216, 211, 211)";
    section32.style.border = "2px solid rgb(216, 211, 211)";
    section33.style.border = "2px solid rgb(216, 211, 211)";
    section34.style.border = "2px solid rgb(216, 211, 211)";
    section35.style.border = "2px solid rgb(216, 211, 211)";
    section36.style.border = "2px solid rgb(216, 211, 211)";
    section37.style.backgroundColor = "black";
    section37.style.cursor = "pointer";
    section37.onmouseover = () => {
        section37.style.cursor = "pointer"
    }
    section37.onmouseout = () => {
        section37.style.cursor = "pointer"
    }
    section6.onmouseover=()=>{
        section6.style.border="3px solid black";
    }
    section6.onmouseout=()=>{
        section6.style.border="2px solid rgb(216, 211, 211)";
    }
    section7.onmouseover=()=>{
        section7.style.border="3px solid black";
    }
    section7.onmouseout=()=>{
        section7.style.border="2px solid rgb(216, 211, 211)";
    }
    section8.onmouseover=()=>{
        section8.style.border="3px solid black";
    }
    section8.onmouseout=()=>{
        section8.style.border="2px solid rgb(216, 211, 211)";
    }
    section9.onmouseover=()=>{
        section9.style.border="3px solid black";
    }
    section9.onmouseout=()=>{
        section9.style.border="2px solid rgb(216, 211, 211)";
    }
    section10.onmouseover=()=>{
        section10.style.border="3px solid black";
    }
    section10.onmouseout=()=>{
        section10.style.border="2px solid rgb(216, 211, 211)";
    }
    section11.onmouseover=()=>{
        section11.style.border="3px solid black";
    }
    section11.onmouseout=()=>{
        section11.style.border="2px solid rgb(216, 211, 211)";
    }
    section12.onmouseover=()=>{
        section12.style.border="3px solid black";
    }
    section12.onmouseout=()=>{
        section12.style.border="2px solid rgb(216, 211, 211)";
    }
    section13.onmouseover=()=>{
        section13.style.border="3px solid black";
    }
    section13.onmouseout=()=>{
        section13.style.border="2px solid rgb(216, 211, 211)";
    }
    section14.onmouseover=()=>{
        section14.style.border="3px solid black";
    }
    section14.onmouseout=()=>{
        section14.style.border="2px solid rgb(216, 211, 211)";
    }
    section15.onmouseover=()=>{
        section15.style.border="3px solid black";
    }
    section15.onmouseout=()=>{
        section15.style.border="2px solid rgb(216, 211, 211)";
    }
    section16.onmouseover=()=>{
        section16.style.border="3px solid black";
    }
    section16.onmouseout=()=>{
        section16.style.border="2px solid rgb(216, 211, 211)";
    }
    section17.onmouseover=()=>{
        section17.style.border="3px solid black";
    }
    section17.onmouseout=()=>{
        section17.style.border="2px solid rgb(216, 211, 211)";
    }
    section18.onmouseover=()=>{
        section18.style.border="3px solid black";
    }
    section18.onmouseout=()=>{
        section18.style.border="2px solid rgb(216, 211, 211)";
    }
    section19.onmouseover=()=>{
        section19.style.border="3px solid black";
    }
    section19.onmouseout=()=>{
        section19.style.border="2px solid rgb(216, 211, 211)";
    }
    section20.onmouseover=()=>{
        section20.style.border="3px solid black";
    }
    section20.onmouseout=()=>{
        section20.style.border="2px solid rgb(216, 211, 211)";
    }
    section21.onmouseover=()=>{
        section21.style.border="3px solid black";
    }
    section21.onmouseout=()=>{
        section21.style.border="2px solid rgb(216, 211, 211)";
    }
    section22.onmouseover=()=>{
        section22.style.border="3px solid black";
    }
    section22.onmouseout=()=>{
        section22.style.border="2px solid rgb(216, 211, 211)";
    }
    section23.onmouseover=()=>{
        section23.style.border="3px solid black";
    }
    section23.onmouseout=()=>{
        section23.style.border="2px solid rgb(216, 211, 211)";
    }
    section24.onmouseover=()=>{
        section24.style.border="3px solid black";
    }
    section24.onmouseout=()=>{
        section24.style.border="2px solid rgb(216, 211, 211)";
    }
    section25.onmouseover=()=>{
        section25.style.border="3px solid black";
    }
    section25.onmouseout=()=>{
        section25.style.border="2px solid rgb(216, 211, 211)";
    }
    section26.onmouseover=()=>{
        section26.style.border="3px solid black";
    }
    section26.onmouseout=()=>{
        section26.style.border="3px solid black";
    }
    section27.onmouseover=()=>{
        section27.style.border="3px solid black";
    }
    section27.onmouseout=()=>{
        section27.style.border="2px solid rgb(216, 211, 211)";
    }
    section28.onmouseover=()=>{
        section28.style.border="3px solid black";
    }
    section28.onmouseout=()=>{
        section28.style.border="2px solid rgb(216, 211, 211)";
    }
    section29.onmouseover=()=>{
        section29.style.border="3px solid black";
    }
    section29.onmouseout=()=>{
        section29.style.border="2px solid rgb(216, 211, 211)";
    }
    section30.onmouseover=()=>{
        section30.style.border="3px solid black";
    }
    section30.onmouseout=()=>{
        section30.style.border="2px solid rgb(216, 211, 211)";
    }
    section31.onmouseover=()=>{
        section31.style.border="3px solid black";
    }
    section31.onmouseout=()=>{
        section31.style.border="2px solid rgb(216, 211, 211)";
    }
    section32.onmouseover=()=>{
        section32.style.border="3px solid black";
    }
    section32.onmouseout=()=>{
        section32.style.border="2px solid rgb(216, 211, 211)";
    }
    section33.onmouseover=()=>{
        section33.style.border="3px solid black";
    }
    section33.onmouseout=()=>{
        section33.style.border="2px solid rgb(216, 211, 211)";
    }
    section34.onmouseover=()=>{
        section34.style.border="3px solid black";
    }
    section34.onmouseout=()=>{
        section34.style.border="2px solid rgb(216, 211, 211)";
    }
    section35.onmouseover=()=>{
        section35.style.border="3px solid black";
    }
    section35.onmouseout=()=>{
        section35.style.border="2px solid rgb(216, 211, 211)";
    }
    section36.onmouseover=()=>{
        section36.style.border="3px solid black";
    }
    section36.onmouseout=()=>{
        section36.style.border="2px solid rgb(216, 211, 211)";
    }
}
function fun22() {
    const section6 = document.getElementById("section6");
    const section7 = document.getElementById("section7");
    const section8 = document.getElementById("section8");
    const section9 = document.getElementById("section9");
    const section10 = document.getElementById("section10");
    const section11 = document.getElementById("section11");
    const section12 = document.getElementById("section12");
    const section13 = document.getElementById("section13");
    const section14 = document.getElementById("section14");
    const section15 = document.getElementById("section15");
    const section16 = document.getElementById("section16");
    const section17 = document.getElementById("section17");
    const section18 = document.getElementById("section18");
    const section19 = document.getElementById("section19");
    const section20 = document.getElementById("section20");
    const section21 = document.getElementById("section21");
    const section22 = document.getElementById("section22");
    const section23 = document.getElementById("section23");
    const section24 = document.getElementById("section24");
    const section25 = document.getElementById("section25");
    const section26 = document.getElementById("section26");
    const section27 = document.getElementById("section27");
    const section28 = document.getElementById("section28");
    const section29 = document.getElementById("section29");
    const section30 = document.getElementById("section30");
    const section31 = document.getElementById("section31");
    const section32 = document.getElementById("section32");
    const section33 = document.getElementById("section33");
    const section34 = document.getElementById("section34");
    const section35 = document.getElementById("section35");
    const section36 = document.getElementById("section36");
    const section37 = document.getElementsByClassName("section37")[0];
    section6.style.border = "2px solid rgb(216, 211, 211)";
    section7.style.border = "2px solid rgb(216, 211, 211)";
    section8.style.border = "2px solid rgb(216, 211, 211)";
    section9.style.border = "2px solid rgb(216, 211, 211)";
    section10.style.border = "2px solid rgb(216, 211, 211)";
    section11.style.border = "2px solid rgb(216, 211, 211)";
    section12.style.border = "2px solid rgb(216, 211, 211)";
    section13.style.border = "2px solid rgb(216, 211, 211)";
    section14.style.border = "2px solid rgb(216, 211, 211)";
    section15.style.border = "2px solid rgb(216, 211, 211)";
    section16.style.border = "2px solid rgb(216, 211, 211)";
    section17.style.border = "2px solid rgb(216, 211, 211)";
    section18.style.border = "2px solid rgb(216, 211, 211)";
    section19.style.border = "2px solid rgb(216, 211, 211)";
    section20.style.border = "2px solid rgb(216, 211, 211)";
    section21.style.border = "2px solid rgb(216, 211, 211)";
    section22.style.border = "2px solid rgb(216, 211, 211)";
    section23.style.border = "2px solid rgb(216, 211, 211)";
    section24.style.border = "2px solid rgb(216, 211, 211)";
    section25.style.border = "2px solid rgb(216, 211, 211)";
    section26.style.border = "2px solid rgb(216, 211, 211)";
    section27.style.border = "3px solid black";
    section28.style.border = "2px solid rgb(216, 211, 211)";
    section29.style.border = "2px solid rgb(216, 211, 211)";
    section30.style.border = "2px solid rgb(216, 211, 211)";
    section31.style.border = "2px solid rgb(216, 211, 211)";
    section32.style.border = "2px solid rgb(216, 211, 211)";
    section33.style.border = "2px solid rgb(216, 211, 211)";
    section34.style.border = "2px solid rgb(216, 211, 211)";
    section35.style.border = "2px solid rgb(216, 211, 211)";
    section36.style.border = "2px solid rgb(216, 211, 211)";
    section37.style.backgroundColor = "black";
    section37.style.cursor = "pointer";
    section37.onmouseover = () => {
        section37.style.cursor = "pointer"
    }
    section37.onmouseout = () => {
        section37.style.cursor = "pointer"
    }
    section6.onmouseover=()=>{
        section6.style.border="3px solid black";
    }
    section6.onmouseout=()=>{
        section6.style.border="2px solid rgb(216, 211, 211)";
    }
    section7.onmouseover=()=>{
        section7.style.border="3px solid black";
    }
    section7.onmouseout=()=>{
        section7.style.border="2px solid rgb(216, 211, 211)";
    }
    section8.onmouseover=()=>{
        section8.style.border="3px solid black";
    }
    section8.onmouseout=()=>{
        section8.style.border="2px solid rgb(216, 211, 211)";
    }
    section9.onmouseover=()=>{
        section9.style.border="3px solid black";
    }
    section9.onmouseout=()=>{
        section9.style.border="2px solid rgb(216, 211, 211)";
    }
    section10.onmouseover=()=>{
        section10.style.border="3px solid black";
    }
    section10.onmouseout=()=>{
        section10.style.border="2px solid rgb(216, 211, 211)";
    }
    section11.onmouseover=()=>{
        section11.style.border="3px solid black";
    }
    section11.onmouseout=()=>{
        section11.style.border="2px solid rgb(216, 211, 211)";
    }
    section12.onmouseover=()=>{
        section12.style.border="3px solid black";
    }
    section12.onmouseout=()=>{
        section12.style.border="2px solid rgb(216, 211, 211)";
    }
    section13.onmouseover=()=>{
        section13.style.border="3px solid black";
    }
    section13.onmouseout=()=>{
        section13.style.border="2px solid rgb(216, 211, 211)";
    }
    section14.onmouseover=()=>{
        section14.style.border="3px solid black";
    }
    section14.onmouseout=()=>{
        section14.style.border="2px solid rgb(216, 211, 211)";
    }
    section15.onmouseover=()=>{
        section15.style.border="3px solid black";
    }
    section15.onmouseout=()=>{
        section15.style.border="2px solid rgb(216, 211, 211)";
    }
    section16.onmouseover=()=>{
        section16.style.border="3px solid black";
    }
    section16.onmouseout=()=>{
        section16.style.border="2px solid rgb(216, 211, 211)";
    }
    section17.onmouseover=()=>{
        section17.style.border="3px solid black";
    }
    section17.onmouseout=()=>{
        section17.style.border="2px solid rgb(216, 211, 211)";
    }
    section18.onmouseover=()=>{
        section18.style.border="3px solid black";
    }
    section18.onmouseout=()=>{
        section18.style.border="2px solid rgb(216, 211, 211)";
    }
    section19.onmouseover=()=>{
        section19.style.border="3px solid black";
    }
    section19.onmouseout=()=>{
        section19.style.border="2px solid rgb(216, 211, 211)";
    }
    section20.onmouseover=()=>{
        section20.style.border="3px solid black";
    }
    section20.onmouseout=()=>{
        section20.style.border="2px solid rgb(216, 211, 211)";
    }
    section21.onmouseover=()=>{
        section21.style.border="3px solid black";
    }
    section21.onmouseout=()=>{
        section21.style.border="2px solid rgb(216, 211, 211)";
    }
    section22.onmouseover=()=>{
        section22.style.border="3px solid black";
    }
    section22.onmouseout=()=>{
        section22.style.border="2px solid rgb(216, 211, 211)";
    }
    section23.onmouseover=()=>{
        section23.style.border="3px solid black";
    }
    section23.onmouseout=()=>{
        section23.style.border="2px solid rgb(216, 211, 211)";
    }
    section24.onmouseover=()=>{
        section24.style.border="3px solid black";
    }
    section24.onmouseout=()=>{
        section24.style.border="2px solid rgb(216, 211, 211)";
    }
    section25.onmouseover=()=>{
        section25.style.border="3px solid black";
    }
    section25.onmouseout=()=>{
        section25.style.border="2px solid rgb(216, 211, 211)";
    }
    section26.onmouseover=()=>{
        section26.style.border="3px solid black";
    }
    section26.onmouseout=()=>{
        section26.style.border="2px solid rgb(216, 211, 211)";
    }
    section27.onmouseover=()=>{
        section27.style.border="3px solid black";
    }
    section27.onmouseout=()=>{
        section27.style.border="3px solid black";
    }
    section28.onmouseover=()=>{
        section28.style.border="3px solid black";
    }
    section28.onmouseout=()=>{
        section28.style.border="2px solid rgb(216, 211, 211)";
    }
    section29.onmouseover=()=>{
        section29.style.border="3px solid black";
    }
    section29.onmouseout=()=>{
        section29.style.border="2px solid rgb(216, 211, 211)";
    }
    section30.onmouseover=()=>{
        section30.style.border="3px solid black";
    }
    section30.onmouseout=()=>{
        section30.style.border="2px solid rgb(216, 211, 211)";
    }
    section31.onmouseover=()=>{
        section31.style.border="3px solid black";
    }
    section31.onmouseout=()=>{
        section31.style.border="2px solid rgb(216, 211, 211)";
    }
    section32.onmouseover=()=>{
        section32.style.border="3px solid black";
    }
    section32.onmouseout=()=>{
        section32.style.border="2px solid rgb(216, 211, 211)";
    }
    section33.onmouseover=()=>{
        section33.style.border="3px solid black";
    }
    section33.onmouseout=()=>{
        section33.style.border="2px solid rgb(216, 211, 211)";
    }
    section34.onmouseover=()=>{
        section34.style.border="3px solid black";
    }
    section34.onmouseout=()=>{
        section34.style.border="2px solid rgb(216, 211, 211)";
    }
    section35.onmouseover=()=>{
        section35.style.border="3px solid black";
    }
    section35.onmouseout=()=>{
        section35.style.border="2px solid rgb(216, 211, 211)";
    }
    section36.onmouseover=()=>{
        section36.style.border="3px solid black";
    }
    section36.onmouseout=()=>{
        section36.style.border="2px solid rgb(216, 211, 211)";
    }
}
function fun23() {
    const section6 = document.getElementById("section6");
    const section7 = document.getElementById("section7");
    const section8 = document.getElementById("section8");
    const section9 = document.getElementById("section9");
    const section10 = document.getElementById("section10");
    const section11 = document.getElementById("section11");
    const section12 = document.getElementById("section12");
    const section13 = document.getElementById("section13");
    const section14 = document.getElementById("section14");
    const section15 = document.getElementById("section15");
    const section16 = document.getElementById("section16");
    const section17 = document.getElementById("section17");
    const section18 = document.getElementById("section18");
    const section19 = document.getElementById("section19");
    const section20 = document.getElementById("section20");
    const section21 = document.getElementById("section21");
    const section22 = document.getElementById("section22");
    const section23 = document.getElementById("section23");
    const section24 = document.getElementById("section24");
    const section25 = document.getElementById("section25");
    const section26 = document.getElementById("section26");
    const section27 = document.getElementById("section27");
    const section28 = document.getElementById("section28");
    const section29 = document.getElementById("section29");
    const section30 = document.getElementById("section30");
    const section31 = document.getElementById("section31");
    const section32 = document.getElementById("section32");
    const section33 = document.getElementById("section33");
    const section34 = document.getElementById("section34");
    const section35 = document.getElementById("section35");
    const section36 = document.getElementById("section36");
    const section37 = document.getElementsByClassName("section37")[0];
    section6.style.border = "2px solid rgb(216, 211, 211)";
    section7.style.border = "2px solid rgb(216, 211, 211)";
    section8.style.border = "2px solid rgb(216, 211, 211)";
    section9.style.border = "2px solid rgb(216, 211, 211)";
    section10.style.border = "2px solid rgb(216, 211, 211)";
    section11.style.border = "2px solid rgb(216, 211, 211)";
    section12.style.border = "2px solid rgb(216, 211, 211)";
    section13.style.border = "2px solid rgb(216, 211, 211)";
    section14.style.border = "2px solid rgb(216, 211, 211)";
    section15.style.border = "2px solid rgb(216, 211, 211)";
    section16.style.border = "2px solid rgb(216, 211, 211)";
    section17.style.border = "2px solid rgb(216, 211, 211)";
    section18.style.border = "2px solid rgb(216, 211, 211)";
    section19.style.border = "2px solid rgb(216, 211, 211)";
    section20.style.border = "2px solid rgb(216, 211, 211)";
    section21.style.border = "2px solid rgb(216, 211, 211)";
    section22.style.border = "2px solid rgb(216, 211, 211)";
    section23.style.border = "2px solid rgb(216, 211, 211)";
    section24.style.border = "2px solid rgb(216, 211, 211)";
    section25.style.border = "2px solid rgb(216, 211, 211)";
    section26.style.border = "2px solid rgb(216, 211, 211)";
    section27.style.border = "2px solid rgb(216, 211, 211)";
    section28.style.border = "3px solid black";
    section29.style.border = "2px solid rgb(216, 211, 211)";
    section30.style.border = "2px solid rgb(216, 211, 211)";
    section31.style.border = "2px solid rgb(216, 211, 211)";
    section32.style.border = "2px solid rgb(216, 211, 211)";
    section33.style.border = "2px solid rgb(216, 211, 211)";
    section34.style.border = "2px solid rgb(216, 211, 211)";
    section35.style.border = "2px solid rgb(216, 211, 211)";
    section36.style.border = "2px solid rgb(216, 211, 211)";
    section37.style.backgroundColor = "black";
    section37.style.cursor = "pointer";
    section37.onmouseover = () => {
        section37.style.cursor = "pointer"
    }
    section37.onmouseout = () => {
        section37.style.cursor = "pointer"
    }
    section6.onmouseover=()=>{
        section6.style.border="3px solid black";
    }
    section6.onmouseout=()=>{
        section6.style.border="2px solid rgb(216, 211, 211)";
    }
    section7.onmouseover=()=>{
        section7.style.border="3px solid black";
    }
    section7.onmouseout=()=>{
        section7.style.border="2px solid rgb(216, 211, 211)";
    }
    section8.onmouseover=()=>{
        section8.style.border="3px solid black";
    }
    section8.onmouseout=()=>{
        section8.style.border="2px solid rgb(216, 211, 211)";
    }
    section9.onmouseover=()=>{
        section9.style.border="3px solid black";
    }
    section9.onmouseout=()=>{
        section9.style.border="2px solid rgb(216, 211, 211)";
    }
    section10.onmouseover=()=>{
        section10.style.border="3px solid black";
    }
    section10.onmouseout=()=>{
        section10.style.border="2px solid rgb(216, 211, 211)";
    }
    section11.onmouseover=()=>{
        section11.style.border="3px solid black";
    }
    section11.onmouseout=()=>{
        section11.style.border="2px solid rgb(216, 211, 211)";
    }
    section12.onmouseover=()=>{
        section12.style.border="3px solid black";
    }
    section12.onmouseout=()=>{
        section12.style.border="2px solid rgb(216, 211, 211)";
    }
    section13.onmouseover=()=>{
        section13.style.border="3px solid black";
    }
    section13.onmouseout=()=>{
        section13.style.border="2px solid rgb(216, 211, 211)";
    }
    section14.onmouseover=()=>{
        section14.style.border="3px solid black";
    }
    section14.onmouseout=()=>{
        section14.style.border="2px solid rgb(216, 211, 211)";
    }
    section15.onmouseover=()=>{
        section15.style.border="3px solid black";
    }
    section15.onmouseout=()=>{
        section15.style.border="2px solid rgb(216, 211, 211)";
    }
    section16.onmouseover=()=>{
        section16.style.border="3px solid black";
    }
    section16.onmouseout=()=>{
        section16.style.border="2px solid rgb(216, 211, 211)";
    }
    section17.onmouseover=()=>{
        section17.style.border="3px solid black";
    }
    section17.onmouseout=()=>{
        section17.style.border="2px solid rgb(216, 211, 211)";
    }
    section18.onmouseover=()=>{
        section18.style.border="3px solid black";
    }
    section18.onmouseout=()=>{
        section18.style.border="2px solid rgb(216, 211, 211)";
    }
    section19.onmouseover=()=>{
        section19.style.border="3px solid black";
    }
    section19.onmouseout=()=>{
        section19.style.border="2px solid rgb(216, 211, 211)";
    }
    section20.onmouseover=()=>{
        section20.style.border="3px solid black";
    }
    section20.onmouseout=()=>{
        section20.style.border="2px solid rgb(216, 211, 211)";
    }
    section21.onmouseover=()=>{
        section21.style.border="3px solid black";
    }
    section21.onmouseout=()=>{
        section21.style.border="2px solid rgb(216, 211, 211)";
    }
    section22.onmouseover=()=>{
        section22.style.border="3px solid black";
    }
    section22.onmouseout=()=>{
        section22.style.border="2px solid rgb(216, 211, 211)";
    }
    section23.onmouseover=()=>{
        section23.style.border="3px solid black";
    }
    section23.onmouseout=()=>{
        section23.style.border="2px solid rgb(216, 211, 211)";
    }
    section24.onmouseover=()=>{
        section24.style.border="3px solid black";
    }
    section24.onmouseout=()=>{
        section24.style.border="2px solid rgb(216, 211, 211)";
    }
    section25.onmouseover=()=>{
        section25.style.border="3px solid black";
    }
    section25.onmouseout=()=>{
        section25.style.border="2px solid rgb(216, 211, 211)";
    }
    section26.onmouseover=()=>{
        section26.style.border="3px solid black";
    }
    section26.onmouseout=()=>{
        section26.style.border="2px solid rgb(216, 211, 211)";
    }
    section27.onmouseover=()=>{
        section27.style.border="3px solid black";
    }
    section27.onmouseout=()=>{
        section27.style.border="2px solid rgb(216, 211, 211)";
    }
    section28.onmouseover=()=>{
        section28.style.border="3px solid black";
    }
    section28.onmouseout=()=>{
        section28.style.border="3px solid black";
    }
    section29.onmouseover=()=>{
        section29.style.border="3px solid black";
    }
    section29.onmouseout=()=>{
        section29.style.border="2px solid rgb(216, 211, 211)";
    }
    section30.onmouseover=()=>{
        section30.style.border="3px solid black";
    }
    section30.onmouseout=()=>{
        section30.style.border="2px solid rgb(216, 211, 211)";
    }
    section31.onmouseover=()=>{
        section31.style.border="3px solid black";
    }
    section31.onmouseout=()=>{
        section31.style.border="2px solid rgb(216, 211, 211)";
    }
    section32.onmouseover=()=>{
        section32.style.border="3px solid black";
    }
    section32.onmouseout=()=>{
        section32.style.border="2px solid rgb(216, 211, 211)";
    }
    section33.onmouseover=()=>{
        section33.style.border="3px solid black";
    }
    section33.onmouseout=()=>{
        section33.style.border="2px solid rgb(216, 211, 211)";
    }
    section34.onmouseover=()=>{
        section34.style.border="3px solid black";
    }
    section34.onmouseout=()=>{
        section34.style.border="2px solid rgb(216, 211, 211)";
    }
    section35.onmouseover=()=>{
        section35.style.border="3px solid black";
    }
    section35.onmouseout=()=>{
        section35.style.border="2px solid rgb(216, 211, 211)";
    }
    section36.onmouseover=()=>{
        section36.style.border="3px solid black";
    }
    section36.onmouseout=()=>{
        section36.style.border="2px solid rgb(216, 211, 211)";
    }
}
function fun24() {
    const section6 = document.getElementById("section6");
    const section7 = document.getElementById("section7");
    const section8 = document.getElementById("section8");
    const section9 = document.getElementById("section9");
    const section10 = document.getElementById("section10");
    const section11 = document.getElementById("section11");
    const section12 = document.getElementById("section12");
    const section13 = document.getElementById("section13");
    const section14 = document.getElementById("section14");
    const section15 = document.getElementById("section15");
    const section16 = document.getElementById("section16");
    const section17 = document.getElementById("section17");
    const section18 = document.getElementById("section18");
    const section19 = document.getElementById("section19");
    const section20 = document.getElementById("section20");
    const section21 = document.getElementById("section21");
    const section22 = document.getElementById("section22");
    const section23 = document.getElementById("section23");
    const section24 = document.getElementById("section24");
    const section25 = document.getElementById("section25");
    const section26 = document.getElementById("section26");
    const section27 = document.getElementById("section27");
    const section28 = document.getElementById("section28");
    const section29 = document.getElementById("section29");
    const section30 = document.getElementById("section30");
    const section31 = document.getElementById("section31");
    const section32 = document.getElementById("section32");
    const section33 = document.getElementById("section33");
    const section34 = document.getElementById("section34");
    const section35 = document.getElementById("section35");
    const section36 = document.getElementById("section36");
    const section37 = document.getElementsByClassName("section37")[0];
    section6.style.border = "2px solid rgb(216, 211, 211)";
    section7.style.border = "2px solid rgb(216, 211, 211)";
    section8.style.border = "2px solid rgb(216, 211, 211)";
    section9.style.border = "2px solid rgb(216, 211, 211)";
    section10.style.border = "2px solid rgb(216, 211, 211)";
    section11.style.border = "2px solid rgb(216, 211, 211)";
    section12.style.border = "2px solid rgb(216, 211, 211)";
    section13.style.border = "2px solid rgb(216, 211, 211)";
    section14.style.border = "2px solid rgb(216, 211, 211)";
    section15.style.border = "2px solid rgb(216, 211, 211)";
    section16.style.border = "2px solid rgb(216, 211, 211)";
    section17.style.border = "2px solid rgb(216, 211, 211)";
    section18.style.border = "2px solid rgb(216, 211, 211)";
    section19.style.border = "2px solid rgb(216, 211, 211)";
    section20.style.border = "2px solid rgb(216, 211, 211)";
    section21.style.border = "2px solid rgb(216, 211, 211)";
    section22.style.border = "2px solid rgb(216, 211, 211)";
    section23.style.border = "2px solid rgb(216, 211, 211)";
    section24.style.border = "2px solid rgb(216, 211, 211)";
    section25.style.border = "2px solid rgb(216, 211, 211)";
    section26.style.border = "2px solid rgb(216, 211, 211)";
    section27.style.border = "2px solid rgb(216, 211, 211)";
    section28.style.border = "2px solid rgb(216, 211, 211)";
    section29.style.border = "3px solid black";
    section30.style.border = "2px solid rgb(216, 211, 211)";
    section31.style.border = "2px solid rgb(216, 211, 211)";
    section32.style.border = "2px solid rgb(216, 211, 211)";
    section33.style.border = "2px solid rgb(216, 211, 211)";
    section34.style.border = "2px solid rgb(216, 211, 211)";
    section35.style.border = "2px solid rgb(216, 211, 211)";
    section36.style.border = "2px solid rgb(216, 211, 211)";
    section37.style.backgroundColor = "black";
    section37.style.cursor = "pointer";
    section37.onmouseover = () => {
        section37.style.cursor = "pointer"
    }
    section37.onmouseout = () => {
        section37.style.cursor = "pointer"
    }
    section6.onmouseover=()=>{
        section6.style.border="3px solid black";
    }
    section6.onmouseout=()=>{
        section6.style.border="2px solid rgb(216, 211, 211)";
    }
    section7.onmouseover=()=>{
        section7.style.border="3px solid black";
    }
    section7.onmouseout=()=>{
        section7.style.border="2px solid rgb(216, 211, 211)";
    }
    section8.onmouseover=()=>{
        section8.style.border="3px solid black";
    }
    section8.onmouseout=()=>{
        section8.style.border="2px solid rgb(216, 211, 211)";
    }
    section9.onmouseover=()=>{
        section9.style.border="3px solid black";
    }
    section9.onmouseout=()=>{
        section9.style.border="2px solid rgb(216, 211, 211)";
    }
    section10.onmouseover=()=>{
        section10.style.border="3px solid black";
    }
    section10.onmouseout=()=>{
        section10.style.border="2px solid rgb(216, 211, 211)";
    }
    section11.onmouseover=()=>{
        section11.style.border="3px solid black";
    }
    section11.onmouseout=()=>{
        section11.style.border="2px solid rgb(216, 211, 211)";
    }
    section12.onmouseover=()=>{
        section12.style.border="3px solid black";
    }
    section12.onmouseout=()=>{
        section12.style.border="2px solid rgb(216, 211, 211)";
    }
    section13.onmouseover=()=>{
        section13.style.border="3px solid black";
    }
    section13.onmouseout=()=>{
        section13.style.border="2px solid rgb(216, 211, 211)";
    }
    section14.onmouseover=()=>{
        section14.style.border="3px solid black";
    }
    section14.onmouseout=()=>{
        section14.style.border="2px solid rgb(216, 211, 211)";
    }
    section15.onmouseover=()=>{
        section15.style.border="3px solid black";
    }
    section15.onmouseout=()=>{
        section15.style.border="2px solid rgb(216, 211, 211)";
    }
    section16.onmouseover=()=>{
        section16.style.border="3px solid black";
    }
    section16.onmouseout=()=>{
        section16.style.border="2px solid rgb(216, 211, 211)";
    }
    section17.onmouseover=()=>{
        section17.style.border="3px solid black";
    }
    section17.onmouseout=()=>{
        section17.style.border="2px solid rgb(216, 211, 211)";
    }
    section18.onmouseover=()=>{
        section18.style.border="3px solid black";
    }
    section18.onmouseout=()=>{
        section18.style.border="2px solid rgb(216, 211, 211)";
    }
    section19.onmouseover=()=>{
        section19.style.border="3px solid black";
    }
    section19.onmouseout=()=>{
        section19.style.border="2px solid rgb(216, 211, 211)";
    }
    section20.onmouseover=()=>{
        section20.style.border="3px solid black";
    }
    section20.onmouseout=()=>{
        section20.style.border="2px solid rgb(216, 211, 211)";
    }
    section21.onmouseover=()=>{
        section21.style.border="3px solid black";
    }
    section21.onmouseout=()=>{
        section21.style.border="2px solid rgb(216, 211, 211)";
    }
    section22.onmouseover=()=>{
        section22.style.border="3px solid black";
    }
    section22.onmouseout=()=>{
        section22.style.border="2px solid rgb(216, 211, 211)";
    }
    section23.onmouseover=()=>{
        section23.style.border="3px solid black";
    }
    section23.onmouseout=()=>{
        section23.style.border="2px solid rgb(216, 211, 211)";
    }
    section24.onmouseover=()=>{
        section24.style.border="3px solid black";
    }
    section24.onmouseout=()=>{
        section24.style.border="2px solid rgb(216, 211, 211)";
    }
    section25.onmouseover=()=>{
        section25.style.border="3px solid black";
    }
    section25.onmouseout=()=>{
        section25.style.border="2px solid rgb(216, 211, 211)";
    }
    section26.onmouseover=()=>{
        section26.style.border="3px solid black";
    }
    section26.onmouseout=()=>{
        section26.style.border="2px solid rgb(216, 211, 211)";
    }
    section27.onmouseover=()=>{
        section27.style.border="3px solid black";
    }
    section27.onmouseout=()=>{
        section27.style.border="2px solid rgb(216, 211, 211)";
    }
    section28.onmouseover=()=>{
        section28.style.border="3px solid black";
    }
    section28.onmouseout=()=>{
        section28.style.border="2px solid rgb(216, 211, 211)";
    }
    section29.onmouseover=()=>{
        section29.style.border="3px solid black";
    }
    section29.onmouseout=()=>{
        section29.style.border="3px solid black";
    }
    section30.onmouseover=()=>{
        section30.style.border="3px solid black";
    }
    section30.onmouseout=()=>{
        section30.style.border="2px solid rgb(216, 211, 211)";
    }
    section31.onmouseover=()=>{
        section31.style.border="3px solid black";
    }
    section31.onmouseout=()=>{
        section31.style.border="2px solid rgb(216, 211, 211)";
    }
    section32.onmouseover=()=>{
        section32.style.border="3px solid black";
    }
    section32.onmouseout=()=>{
        section32.style.border="2px solid rgb(216, 211, 211)";
    }
    section33.onmouseover=()=>{
        section33.style.border="3px solid black";
    }
    section33.onmouseout=()=>{
        section33.style.border="2px solid rgb(216, 211, 211)";
    }
    section34.onmouseover=()=>{
        section34.style.border="3px solid black";
    }
    section34.onmouseout=()=>{
        section34.style.border="2px solid rgb(216, 211, 211)";
    }
    section35.onmouseover=()=>{
        section35.style.border="3px solid black";
    }
    section35.onmouseout=()=>{
        section35.style.border="2px solid rgb(216, 211, 211)";
    }
    section36.onmouseover=()=>{
        section36.style.border="3px solid black";
    }
    section36.onmouseout=()=>{
        section36.style.border="2px solid rgb(216, 211, 211)";
    }
}
function fun25() {
    const section6 = document.getElementById("section6");
    const section7 = document.getElementById("section7");
    const section8 = document.getElementById("section8");
    const section9 = document.getElementById("section9");
    const section10 = document.getElementById("section10");
    const section11 = document.getElementById("section11");
    const section12 = document.getElementById("section12");
    const section13 = document.getElementById("section13");
    const section14 = document.getElementById("section14");
    const section15 = document.getElementById("section15");
    const section16 = document.getElementById("section16");
    const section17 = document.getElementById("section17");
    const section18 = document.getElementById("section18");
    const section19 = document.getElementById("section19");
    const section20 = document.getElementById("section20");
    const section21 = document.getElementById("section21");
    const section22 = document.getElementById("section22");
    const section23 = document.getElementById("section23");
    const section24 = document.getElementById("section24");
    const section25 = document.getElementById("section25");
    const section26 = document.getElementById("section26");
    const section27 = document.getElementById("section27");
    const section28 = document.getElementById("section28");
    const section29 = document.getElementById("section29");
    const section30 = document.getElementById("section30");
    const section31 = document.getElementById("section31");
    const section32 = document.getElementById("section32");
    const section33 = document.getElementById("section33");
    const section34 = document.getElementById("section34");
    const section35 = document.getElementById("section35");
    const section36 = document.getElementById("section36");
    const section37 = document.getElementsByClassName("section37")[0];
    section6.style.border = "2px solid rgb(216, 211, 211)";
    section7.style.border = "2px solid rgb(216, 211, 211)";
    section8.style.border = "2px solid rgb(216, 211, 211)";
    section9.style.border = "2px solid rgb(216, 211, 211)";
    section10.style.border = "2px solid rgb(216, 211, 211)";
    section11.style.border = "2px solid rgb(216, 211, 211)";
    section12.style.border = "2px solid rgb(216, 211, 211)";
    section13.style.border = "2px solid rgb(216, 211, 211)";
    section14.style.border = "2px solid rgb(216, 211, 211)";
    section15.style.border = "2px solid rgb(216, 211, 211)";
    section16.style.border = "2px solid rgb(216, 211, 211)";
    section17.style.border = "2px solid rgb(216, 211, 211)";
    section18.style.border = "2px solid rgb(216, 211, 211)";
    section19.style.border = "2px solid rgb(216, 211, 211)";
    section20.style.border = "2px solid rgb(216, 211, 211)";
    section21.style.border = "2px solid rgb(216, 211, 211)";
    section22.style.border = "2px solid rgb(216, 211, 211)";
    section23.style.border = "2px solid rgb(216, 211, 211)";
    section24.style.border = "2px solid rgb(216, 211, 211)";
    section25.style.border = "2px solid rgb(216, 211, 211)";
    section26.style.border = "2px solid rgb(216, 211, 211)";
    section27.style.border = "2px solid rgb(216, 211, 211)";
    section28.style.border = "2px solid rgb(216, 211, 211)";
    section29.style.border = "2px solid rgb(216, 211, 211)";
    section30.style.border = "3px solid black";
    section31.style.border = "2px solid rgb(216, 211, 211)";
    section32.style.border = "2px solid rgb(216, 211, 211)";
    section33.style.border = "2px solid rgb(216, 211, 211)";
    section34.style.border = "2px solid rgb(216, 211, 211)";
    section35.style.border = "2px solid rgb(216, 211, 211)";
    section36.style.border = "2px solid rgb(216, 211, 211)";
    section37.style.backgroundColor = "black";
    section37.style.cursor = "pointer";
    section37.onmouseover = () => {
        section37.style.cursor = "pointer"
    }
    section37.onmouseout = () => {
        section37.style.cursor = "pointer"
    }
    section6.onmouseover=()=>{
        section6.style.border="3px solid black";
    }
    section6.onmouseout=()=>{
        section6.style.border="2px solid rgb(216, 211, 211)";
    }
    section7.onmouseover=()=>{
        section7.style.border="3px solid black";
    }
    section7.onmouseout=()=>{
        section7.style.border="2px solid rgb(216, 211, 211)";
    }
    section8.onmouseover=()=>{
        section8.style.border="3px solid black";
    }
    section8.onmouseout=()=>{
        section8.style.border="2px solid rgb(216, 211, 211)";
    }
    section9.onmouseover=()=>{
        section9.style.border="3px solid black";
    }
    section9.onmouseout=()=>{
        section9.style.border="2px solid rgb(216, 211, 211)";
    }
    section10.onmouseover=()=>{
        section10.style.border="3px solid black";
    }
    section10.onmouseout=()=>{
        section10.style.border="2px solid rgb(216, 211, 211)";
    }
    section11.onmouseover=()=>{
        section11.style.border="3px solid black";
    }
    section11.onmouseout=()=>{
        section11.style.border="2px solid rgb(216, 211, 211)";
    }
    section12.onmouseover=()=>{
        section12.style.border="3px solid black";
    }
    section12.onmouseout=()=>{
        section12.style.border="2px solid rgb(216, 211, 211)";
    }
    section13.onmouseover=()=>{
        section13.style.border="3px solid black";
    }
    section13.onmouseout=()=>{
        section13.style.border="2px solid rgb(216, 211, 211)";
    }
    section14.onmouseover=()=>{
        section14.style.border="3px solid black";
    }
    section14.onmouseout=()=>{
        section14.style.border="2px solid rgb(216, 211, 211)";
    }
    section15.onmouseover=()=>{
        section15.style.border="3px solid black";
    }
    section15.onmouseout=()=>{
        section15.style.border="2px solid rgb(216, 211, 211)";
    }
    section16.onmouseover=()=>{
        section16.style.border="3px solid black";
    }
    section16.onmouseout=()=>{
        section16.style.border="2px solid rgb(216, 211, 211)";
    }
    section17.onmouseover=()=>{
        section17.style.border="3px solid black";
    }
    section17.onmouseout=()=>{
        section17.style.border="2px solid rgb(216, 211, 211)";
    }
    section18.onmouseover=()=>{
        section18.style.border="3px solid black";
    }
    section18.onmouseout=()=>{
        section18.style.border="2px solid rgb(216, 211, 211)";
    }
    section19.onmouseover=()=>{
        section19.style.border="3px solid black";
    }
    section19.onmouseout=()=>{
        section19.style.border="2px solid rgb(216, 211, 211)";
    }
    section20.onmouseover=()=>{
        section20.style.border="3px solid black";
    }
    section20.onmouseout=()=>{
        section20.style.border="2px solid rgb(216, 211, 211)";
    }
    section21.onmouseover=()=>{
        section21.style.border="3px solid black";
    }
    section21.onmouseout=()=>{
        section21.style.border="2px solid rgb(216, 211, 211)";
    }
    section22.onmouseover=()=>{
        section22.style.border="3px solid black";
    }
    section22.onmouseout=()=>{
        section22.style.border="2px solid rgb(216, 211, 211)";
    }
    section23.onmouseover=()=>{
        section23.style.border="3px solid black";
    }
    section23.onmouseout=()=>{
        section23.style.border="2px solid rgb(216, 211, 211)";
    }
    section24.onmouseover=()=>{
        section24.style.border="3px solid black";
    }
    section24.onmouseout=()=>{
        section24.style.border="2px solid rgb(216, 211, 211)";
    }
    section25.onmouseover=()=>{
        section25.style.border="3px solid black";
    }
    section25.onmouseout=()=>{
        section25.style.border="2px solid rgb(216, 211, 211)";
    }
    section26.onmouseover=()=>{
        section26.style.border="3px solid black";
    }
    section26.onmouseout=()=>{
        section26.style.border="2px solid rgb(216, 211, 211)";
    }
    section27.onmouseover=()=>{
        section27.style.border="3px solid black";
    }
    section27.onmouseout=()=>{
        section27.style.border="2px solid rgb(216, 211, 211)";
    }
    section28.onmouseover=()=>{
        section28.style.border="3px solid black";
    }
    section28.onmouseout=()=>{
        section28.style.border="2px solid rgb(216, 211, 211)";
    }
    section29.onmouseover=()=>{
        section29.style.border="3px solid black";
    }
    section29.onmouseout=()=>{
        section29.style.border="2px solid rgb(216, 211, 211)";
    }
    section30.onmouseover=()=>{
        section30.style.border="3px solid black";
    }
    section30.onmouseout=()=>{
        section30.style.border="3px solid black";
    }
    section31.onmouseover=()=>{
        section31.style.border="3px solid black";
    }
    section31.onmouseout=()=>{
        section31.style.border="2px solid rgb(216, 211, 211)";
    }
    section32.onmouseover=()=>{
        section32.style.border="3px solid black";
    }
    section32.onmouseout=()=>{
        section32.style.border="2px solid rgb(216, 211, 211)";
    }
    section33.onmouseover=()=>{
        section33.style.border="3px solid black";
    }
    section33.onmouseout=()=>{
        section33.style.border="2px solid rgb(216, 211, 211)";
    }
    section34.onmouseover=()=>{
        section34.style.border="3px solid black";
    }
    section34.onmouseout=()=>{
        section34.style.border="2px solid rgb(216, 211, 211)";
    }
    section35.onmouseover=()=>{
        section35.style.border="3px solid black";
    }
    section35.onmouseout=()=>{
        section35.style.border="2px solid rgb(216, 211, 211)";
    }
    section36.onmouseover=()=>{
        section36.style.border="3px solid black";
    }
    section36.onmouseout=()=>{
        section36.style.border="2px solid rgb(216, 211, 211)";
    }
}
function fun26() {
    const section6 = document.getElementById("section6");
    const section7 = document.getElementById("section7");
    const section8 = document.getElementById("section8");
    const section9 = document.getElementById("section9");
    const section10 = document.getElementById("section10");
    const section11 = document.getElementById("section11");
    const section12 = document.getElementById("section12");
    const section13 = document.getElementById("section13");
    const section14 = document.getElementById("section14");
    const section15 = document.getElementById("section15");
    const section16 = document.getElementById("section16");
    const section17 = document.getElementById("section17");
    const section18 = document.getElementById("section18");
    const section19 = document.getElementById("section19");
    const section20 = document.getElementById("section20");
    const section21 = document.getElementById("section21");
    const section22 = document.getElementById("section22");
    const section23 = document.getElementById("section23");
    const section24 = document.getElementById("section24");
    const section25 = document.getElementById("section25");
    const section26 = document.getElementById("section26");
    const section27 = document.getElementById("section27");
    const section28 = document.getElementById("section28");
    const section29 = document.getElementById("section29");
    const section30 = document.getElementById("section30");
    const section31 = document.getElementById("section31");
    const section32 = document.getElementById("section32");
    const section33 = document.getElementById("section33");
    const section34 = document.getElementById("section34");
    const section35 = document.getElementById("section35");
    const section36 = document.getElementById("section36");
    const section37 = document.getElementsByClassName("section37")[0];
    section6.style.border = "2px solid rgb(216, 211, 211)";
    section7.style.border = "2px solid rgb(216, 211, 211)";
    section8.style.border = "2px solid rgb(216, 211, 211)";
    section9.style.border = "2px solid rgb(216, 211, 211)";
    section10.style.border = "2px solid rgb(216, 211, 211)";
    section11.style.border = "2px solid rgb(216, 211, 211)";
    section12.style.border = "2px solid rgb(216, 211, 211)";
    section13.style.border = "2px solid rgb(216, 211, 211)";
    section14.style.border = "2px solid rgb(216, 211, 211)";
    section15.style.border = "2px solid rgb(216, 211, 211)";
    section16.style.border = "2px solid rgb(216, 211, 211)";
    section17.style.border = "2px solid rgb(216, 211, 211)";
    section18.style.border = "2px solid rgb(216, 211, 211)";
    section19.style.border = "2px solid rgb(216, 211, 211)";
    section20.style.border = "2px solid rgb(216, 211, 211)";
    section21.style.border = "2px solid rgb(216, 211, 211)";
    section22.style.border = "2px solid rgb(216, 211, 211)";
    section23.style.border = "2px solid rgb(216, 211, 211)";
    section24.style.border = "2px solid rgb(216, 211, 211)";
    section25.style.border = "2px solid rgb(216, 211, 211)";
    section26.style.border = "2px solid rgb(216, 211, 211)";
    section27.style.border = "2px solid rgb(216, 211, 211)";
    section28.style.border = "2px solid rgb(216, 211, 211)";
    section29.style.border = "2px solid rgb(216, 211, 211)";
    section30.style.border = "2px solid rgb(216, 211, 211)";
    section31.style.border = "3px solid black";
    section32.style.border = "2px solid rgb(216, 211, 211)";
    section33.style.border = "2px solid rgb(216, 211, 211)";
    section34.style.border = "2px solid rgb(216, 211, 211)";
    section35.style.border = "2px solid rgb(216, 211, 211)";
    section36.style.border = "2px solid rgb(216, 211, 211)";
    section37.style.backgroundColor = "black";
    section37.style.cursor = "pointer";
    section37.onmouseover = () => {
        section37.style.cursor = "pointer"
    }
    section37.onmouseout = () => {
        section37.style.cursor = "pointer"
    }
    section6.onmouseover=()=>{
        section6.style.border="3px solid black";
    }
    section6.onmouseout=()=>{
        section6.style.border="2px solid rgb(216, 211, 211)";
    }
    section7.onmouseover=()=>{
        section7.style.border="3px solid black";
    }
    section7.onmouseout=()=>{
        section7.style.border="2px solid rgb(216, 211, 211)";
    }
    section8.onmouseover=()=>{
        section8.style.border="3px solid black";
    }
    section8.onmouseout=()=>{
        section8.style.border="2px solid rgb(216, 211, 211)";
    }
    section9.onmouseover=()=>{
        section9.style.border="3px solid black";
    }
    section9.onmouseout=()=>{
        section9.style.border="2px solid rgb(216, 211, 211)";
    }
    section10.onmouseover=()=>{
        section10.style.border="3px solid black";
    }
    section10.onmouseout=()=>{
        section10.style.border="2px solid rgb(216, 211, 211)";
    }
    section11.onmouseover=()=>{
        section11.style.border="3px solid black";
    }
    section11.onmouseout=()=>{
        section11.style.border="2px solid rgb(216, 211, 211)";
    }
    section12.onmouseover=()=>{
        section12.style.border="3px solid black";
    }
    section12.onmouseout=()=>{
        section12.style.border="2px solid rgb(216, 211, 211)";
    }
    section13.onmouseover=()=>{
        section13.style.border="3px solid black";
    }
    section13.onmouseout=()=>{
        section13.style.border="2px solid rgb(216, 211, 211)";
    }
    section14.onmouseover=()=>{
        section14.style.border="3px solid black";
    }
    section14.onmouseout=()=>{
        section14.style.border="2px solid rgb(216, 211, 211)";
    }
    section15.onmouseover=()=>{
        section15.style.border="3px solid black";
    }
    section15.onmouseout=()=>{
        section15.style.border="2px solid rgb(216, 211, 211)";
    }
    section16.onmouseover=()=>{
        section16.style.border="3px solid black";
    }
    section16.onmouseout=()=>{
        section16.style.border="2px solid rgb(216, 211, 211)";
    }
    section17.onmouseover=()=>{
        section17.style.border="3px solid black";
    }
    section17.onmouseout=()=>{
        section17.style.border="2px solid rgb(216, 211, 211)";
    }
    section18.onmouseover=()=>{
        section18.style.border="3px solid black";
    }
    section18.onmouseout=()=>{
        section18.style.border="2px solid rgb(216, 211, 211)";
    }
    section19.onmouseover=()=>{
        section19.style.border="3px solid black";
    }
    section19.onmouseout=()=>{
        section19.style.border="2px solid rgb(216, 211, 211)";
    }
    section20.onmouseover=()=>{
        section20.style.border="3px solid black";
    }
    section20.onmouseout=()=>{
        section20.style.border="2px solid rgb(216, 211, 211)";
    }
    section21.onmouseover=()=>{
        section21.style.border="3px solid black";
    }
    section21.onmouseout=()=>{
        section21.style.border="2px solid rgb(216, 211, 211)";
    }
    section22.onmouseover=()=>{
        section22.style.border="3px solid black";
    }
    section22.onmouseout=()=>{
        section22.style.border="2px solid rgb(216, 211, 211)";
    }
    section23.onmouseover=()=>{
        section23.style.border="3px solid black";
    }
    section23.onmouseout=()=>{
        section23.style.border="2px solid rgb(216, 211, 211)";
    }
    section24.onmouseover=()=>{
        section24.style.border="3px solid black";
    }
    section24.onmouseout=()=>{
        section24.style.border="2px solid rgb(216, 211, 211)";
    }
    section25.onmouseover=()=>{
        section25.style.border="3px solid black";
    }
    section25.onmouseout=()=>{
        section25.style.border="2px solid rgb(216, 211, 211)";
    }
    section26.onmouseover=()=>{
        section26.style.border="3px solid black";
    }
    section26.onmouseout=()=>{
        section26.style.border="2px solid rgb(216, 211, 211)";
    }
    section27.onmouseover=()=>{
        section27.style.border="3px solid black";
    }
    section27.onmouseout=()=>{
        section27.style.border="2px solid rgb(216, 211, 211)";
    }
    section28.onmouseover=()=>{
        section28.style.border="3px solid black";
    }
    section28.onmouseout=()=>{
        section28.style.border="2px solid rgb(216, 211, 211)";
    }
    section29.onmouseover=()=>{
        section29.style.border="3px solid black";
    }
    section29.onmouseout=()=>{
        section29.style.border="2px solid rgb(216, 211, 211)";
    }
    section30.onmouseover=()=>{
        section30.style.border="3px solid black";
    }
    section30.onmouseout=()=>{
        section30.style.border="2px solid rgb(216, 211, 211)";
    }
    section31.onmouseover=()=>{
        section31.style.border="3px solid black";
    }
    section31.onmouseout=()=>{
        section31.style.border="3px solid black";
    }
    section32.onmouseover=()=>{
        section32.style.border="3px solid black";
    }
    section32.onmouseout=()=>{
        section32.style.border="2px solid rgb(216, 211, 211)";
    }
    section33.onmouseover=()=>{
        section33.style.border="3px solid black";
    }
    section33.onmouseout=()=>{
        section33.style.border="2px solid rgb(216, 211, 211)";
    }
    section34.onmouseover=()=>{
        section34.style.border="3px solid black";
    }
    section34.onmouseout=()=>{
        section34.style.border="2px solid rgb(216, 211, 211)";
    }
    section35.onmouseover=()=>{
        section35.style.border="3px solid black";
    }
    section35.onmouseout=()=>{
        section35.style.border="2px solid rgb(216, 211, 211)";
    }
    section36.onmouseover=()=>{
        section36.style.border="3px solid black";
    }
    section36.onmouseout=()=>{
        section36.style.border="2px solid rgb(216, 211, 211)";
    }
}
function fun27() {
    const section6 = document.getElementById("section6");
    const section7 = document.getElementById("section7");
    const section8 = document.getElementById("section8");
    const section9 = document.getElementById("section9");
    const section10 = document.getElementById("section10");
    const section11 = document.getElementById("section11");
    const section12 = document.getElementById("section12");
    const section13 = document.getElementById("section13");
    const section14 = document.getElementById("section14");
    const section15 = document.getElementById("section15");
    const section16 = document.getElementById("section16");
    const section17 = document.getElementById("section17");
    const section18 = document.getElementById("section18");
    const section19 = document.getElementById("section19");
    const section20 = document.getElementById("section20");
    const section21 = document.getElementById("section21");
    const section22 = document.getElementById("section22");
    const section23 = document.getElementById("section23");
    const section24 = document.getElementById("section24");
    const section25 = document.getElementById("section25");
    const section26 = document.getElementById("section26");
    const section27 = document.getElementById("section27");
    const section28 = document.getElementById("section28");
    const section29 = document.getElementById("section29");
    const section30 = document.getElementById("section30");
    const section31 = document.getElementById("section31");
    const section32 = document.getElementById("section32");
    const section33 = document.getElementById("section33");
    const section34 = document.getElementById("section34");
    const section35 = document.getElementById("section35");
    const section36 = document.getElementById("section36");
    const section37 = document.getElementsByClassName("section37")[0];
    section6.style.border = "2px solid rgb(216, 211, 211)";
    section7.style.border = "2px solid rgb(216, 211, 211)";
    section8.style.border = "2px solid rgb(216, 211, 211)";
    section9.style.border = "2px solid rgb(216, 211, 211)";
    section10.style.border = "2px solid rgb(216, 211, 211)";
    section11.style.border = "2px solid rgb(216, 211, 211)";
    section12.style.border = "2px solid rgb(216, 211, 211)";
    section13.style.border = "2px solid rgb(216, 211, 211)";
    section14.style.border = "2px solid rgb(216, 211, 211)";
    section15.style.border = "2px solid rgb(216, 211, 211)";
    section16.style.border = "2px solid rgb(216, 211, 211)";
    section17.style.border = "2px solid rgb(216, 211, 211)";
    section18.style.border = "2px solid rgb(216, 211, 211)";
    section19.style.border = "2px solid rgb(216, 211, 211)";
    section20.style.border = "2px solid rgb(216, 211, 211)";
    section21.style.border = "2px solid rgb(216, 211, 211)";
    section22.style.border = "2px solid rgb(216, 211, 211)";
    section23.style.border = "2px solid rgb(216, 211, 211)";
    section24.style.border = "2px solid rgb(216, 211, 211)";
    section25.style.border = "2px solid rgb(216, 211, 211)";
    section26.style.border = "2px solid rgb(216, 211, 211)";
    section27.style.border = "2px solid rgb(216, 211, 211)";
    section28.style.border = "2px solid rgb(216, 211, 211)";
    section29.style.border = "2px solid rgb(216, 211, 211)";
    section30.style.border = "2px solid rgb(216, 211, 211)";
    section31.style.border = "2px solid rgb(216, 211, 211)";
    section32.style.border = "3px solid black";
    section33.style.border = "2px solid rgb(216, 211, 211)";
    section34.style.border = "2px solid rgb(216, 211, 211)";
    section35.style.border = "2px solid rgb(216, 211, 211)";
    section36.style.border = "2px solid rgb(216, 211, 211)";
    section37.style.backgroundColor = "black";
    section37.style.cursor = "pointer";
    section37.onmouseover = () => {
        section37.style.cursor = "pointer"
    }
    section37.onmouseout = () => {
        section37.style.cursor = "pointer"
    }
    section6.onmouseover=()=>{
        section6.style.border="3px solid black";
    }
    section6.onmouseout=()=>{
        section6.style.border="2px solid rgb(216, 211, 211)";
    }
    section7.onmouseover=()=>{
        section7.style.border="3px solid black";
    }
    section7.onmouseout=()=>{
        section7.style.border="2px solid rgb(216, 211, 211)";
    }
    section8.onmouseover=()=>{
        section8.style.border="3px solid black";
    }
    section8.onmouseout=()=>{
        section8.style.border="2px solid rgb(216, 211, 211)";
    }
    section9.onmouseover=()=>{
        section9.style.border="3px solid black";
    }
    section9.onmouseout=()=>{
        section9.style.border="2px solid rgb(216, 211, 211)";
    }
    section10.onmouseover=()=>{
        section10.style.border="3px solid black";
    }
    section10.onmouseout=()=>{
        section10.style.border="2px solid rgb(216, 211, 211)";
    }
    section11.onmouseover=()=>{
        section11.style.border="3px solid black";
    }
    section11.onmouseout=()=>{
        section11.style.border="2px solid rgb(216, 211, 211)";
    }
    section12.onmouseover=()=>{
        section12.style.border="3px solid black";
    }
    section12.onmouseout=()=>{
        section12.style.border="2px solid rgb(216, 211, 211)";
    }
    section13.onmouseover=()=>{
        section13.style.border="3px solid black";
    }
    section13.onmouseout=()=>{
        section13.style.border="2px solid rgb(216, 211, 211)";
    }
    section14.onmouseover=()=>{
        section14.style.border="3px solid black";
    }
    section14.onmouseout=()=>{
        section14.style.border="2px solid rgb(216, 211, 211)";
    }
    section15.onmouseover=()=>{
        section15.style.border="3px solid black";
    }
    section15.onmouseout=()=>{
        section15.style.border="2px solid rgb(216, 211, 211)";
    }
    section16.onmouseover=()=>{
        section16.style.border="3px solid black";
    }
    section16.onmouseout=()=>{
        section16.style.border="2px solid rgb(216, 211, 211)";
    }
    section17.onmouseover=()=>{
        section17.style.border="3px solid black";
    }
    section17.onmouseout=()=>{
        section17.style.border="2px solid rgb(216, 211, 211)";
    }
    section18.onmouseover=()=>{
        section18.style.border="3px solid black";
    }
    section18.onmouseout=()=>{
        section18.style.border="2px solid rgb(216, 211, 211)";
    }
    section19.onmouseover=()=>{
        section19.style.border="3px solid black";
    }
    section19.onmouseout=()=>{
        section19.style.border="2px solid rgb(216, 211, 211)";
    }
    section20.onmouseover=()=>{
        section20.style.border="3px solid black";
    }
    section20.onmouseout=()=>{
        section20.style.border="2px solid rgb(216, 211, 211)";
    }
    section21.onmouseover=()=>{
        section21.style.border="3px solid black";
    }
    section21.onmouseout=()=>{
        section21.style.border="2px solid rgb(216, 211, 211)";
    }
    section22.onmouseover=()=>{
        section22.style.border="3px solid black";
    }
    section22.onmouseout=()=>{
        section22.style.border="2px solid rgb(216, 211, 211)";
    }
    section23.onmouseover=()=>{
        section23.style.border="3px solid black";
    }
    section23.onmouseout=()=>{
        section23.style.border="2px solid rgb(216, 211, 211)";
    }
    section24.onmouseover=()=>{
        section24.style.border="3px solid black";
    }
    section24.onmouseout=()=>{
        section24.style.border="2px solid rgb(216, 211, 211)";
    }
    section25.onmouseover=()=>{
        section25.style.border="3px solid black";
    }
    section25.onmouseout=()=>{
        section25.style.border="2px solid rgb(216, 211, 211)";
    }
    section26.onmouseover=()=>{
        section26.style.border="3px solid black";
    }
    section26.onmouseout=()=>{
        section26.style.border="2px solid rgb(216, 211, 211)";
    }
    section27.onmouseover=()=>{
        section27.style.border="3px solid black";
    }
    section27.onmouseout=()=>{
        section27.style.border="2px solid rgb(216, 211, 211)";
    }
    section28.onmouseover=()=>{
        section28.style.border="3px solid black";
    }
    section28.onmouseout=()=>{
        section28.style.border="2px solid rgb(216, 211, 211)";
    }
    section29.onmouseover=()=>{
        section29.style.border="3px solid black";
    }
    section29.onmouseout=()=>{
        section29.style.border="2px solid rgb(216, 211, 211)";
    }
    section30.onmouseover=()=>{
        section30.style.border="3px solid black";
    }
    section30.onmouseout=()=>{
        section30.style.border="2px solid rgb(216, 211, 211)";
    }
    section31.onmouseover=()=>{
        section31.style.border="3px solid black";
    }
    section31.onmouseout=()=>{
        section31.style.border="2px solid rgb(216, 211, 211)";
    }
    section32.onmouseover=()=>{
        section32.style.border="3px solid black";
    }
    section32.onmouseout=()=>{
        section32.style.border="3px solid black";
    }
    section33.onmouseover=()=>{
        section33.style.border="3px solid black";
    }
    section33.onmouseout=()=>{
        section33.style.border="2px solid rgb(216, 211, 211)";
    }
    section34.onmouseover=()=>{
        section34.style.border="3px solid black";
    }
    section34.onmouseout=()=>{
        section34.style.border="2px solid rgb(216, 211, 211)";
    }
    section35.onmouseover=()=>{
        section35.style.border="3px solid black";
    }
    section35.onmouseout=()=>{
        section35.style.border="2px solid rgb(216, 211, 211)";
    }
    section36.onmouseover=()=>{
        section36.style.border="3px solid black";
    }
    section36.onmouseout=()=>{
        section36.style.border="2px solid rgb(216, 211, 211)";
    }
}
function fun28() {
    const section6 = document.getElementById("section6");
    const section7 = document.getElementById("section7");
    const section8 = document.getElementById("section8");
    const section9 = document.getElementById("section9");
    const section10 = document.getElementById("section10");
    const section11 = document.getElementById("section11");
    const section12 = document.getElementById("section12");
    const section13 = document.getElementById("section13");
    const section14 = document.getElementById("section14");
    const section15 = document.getElementById("section15");
    const section16 = document.getElementById("section16");
    const section17 = document.getElementById("section17");
    const section18 = document.getElementById("section18");
    const section19 = document.getElementById("section19");
    const section20 = document.getElementById("section20");
    const section21 = document.getElementById("section21");
    const section22 = document.getElementById("section22");
    const section23 = document.getElementById("section23");
    const section24 = document.getElementById("section24");
    const section25 = document.getElementById("section25");
    const section26 = document.getElementById("section26");
    const section27 = document.getElementById("section27");
    const section28 = document.getElementById("section28");
    const section29 = document.getElementById("section29");
    const section30 = document.getElementById("section30");
    const section31 = document.getElementById("section31");
    const section32 = document.getElementById("section32");
    const section33 = document.getElementById("section33");
    const section34 = document.getElementById("section34");
    const section35 = document.getElementById("section35");
    const section36 = document.getElementById("section36");
    const section37 = document.getElementsByClassName("section37")[0];
    section6.style.border = "2px solid rgb(216, 211, 211)";
    section7.style.border = "2px solid rgb(216, 211, 211)";
    section8.style.border = "2px solid rgb(216, 211, 211)";
    section9.style.border = "2px solid rgb(216, 211, 211)";
    section10.style.border = "2px solid rgb(216, 211, 211)";
    section11.style.border = "2px solid rgb(216, 211, 211)";
    section12.style.border = "2px solid rgb(216, 211, 211)";
    section13.style.border = "2px solid rgb(216, 211, 211)";
    section14.style.border = "2px solid rgb(216, 211, 211)";
    section15.style.border = "2px solid rgb(216, 211, 211)";
    section16.style.border = "2px solid rgb(216, 211, 211)";
    section17.style.border = "2px solid rgb(216, 211, 211)";
    section18.style.border = "2px solid rgb(216, 211, 211)";
    section19.style.border = "2px solid rgb(216, 211, 211)";
    section20.style.border = "2px solid rgb(216, 211, 211)";
    section21.style.border = "2px solid rgb(216, 211, 211)";
    section22.style.border = "2px solid rgb(216, 211, 211)";
    section23.style.border = "2px solid rgb(216, 211, 211)";
    section24.style.border = "2px solid rgb(216, 211, 211)";
    section25.style.border = "2px solid rgb(216, 211, 211)";
    section26.style.border = "2px solid rgb(216, 211, 211)";
    section27.style.border = "2px solid rgb(216, 211, 211)";
    section28.style.border = "2px solid rgb(216, 211, 211)";
    section29.style.border = "2px solid rgb(216, 211, 211)";
    section30.style.border = "2px solid rgb(216, 211, 211)";
    section31.style.border = "2px solid rgb(216, 211, 211)";
    section32.style.border = "2px solid rgb(216, 211, 211)";
    section33.style.border = "3px solid black";
    section34.style.border = "2px solid rgb(216, 211, 211)";
    section35.style.border = "2px solid rgb(216, 211, 211)";
    section36.style.border = "2px solid rgb(216, 211, 211)";
    section37.style.backgroundColor = "black";
    section37.style.cursor = "pointer";
    section37.onmouseover = () => {
        section37.style.cursor = "pointer"
    }
    section37.onmouseout = () => {
        section37.style.cursor = "pointer"
    }
    section6.onmouseover=()=>{
        section6.style.border="3px solid black";
    }
    section6.onmouseout=()=>{
        section6.style.border="2px solid rgb(216, 211, 211)";
    }
    section7.onmouseover=()=>{
        section7.style.border="3px solid black";
    }
    section7.onmouseout=()=>{
        section7.style.border="2px solid rgb(216, 211, 211)";
    }
    section8.onmouseover=()=>{
        section8.style.border="3px solid black";
    }
    section8.onmouseout=()=>{
        section8.style.border="2px solid rgb(216, 211, 211)";
    }
    section9.onmouseover=()=>{
        section9.style.border="3px solid black";
    }
    section9.onmouseout=()=>{
        section9.style.border="2px solid rgb(216, 211, 211)";
    }
    section10.onmouseover=()=>{
        section10.style.border="3px solid black";
    }
    section10.onmouseout=()=>{
        section10.style.border="2px solid rgb(216, 211, 211)";
    }
    section11.onmouseover=()=>{
        section11.style.border="3px solid black";
    }
    section11.onmouseout=()=>{
        section11.style.border="2px solid rgb(216, 211, 211)";
    }
    section12.onmouseover=()=>{
        section12.style.border="3px solid black";
    }
    section12.onmouseout=()=>{
        section12.style.border="2px solid rgb(216, 211, 211)";
    }
    section13.onmouseover=()=>{
        section13.style.border="3px solid black";
    }
    section13.onmouseout=()=>{
        section13.style.border="2px solid rgb(216, 211, 211)";
    }
    section14.onmouseover=()=>{
        section14.style.border="3px solid black";
    }
    section14.onmouseout=()=>{
        section14.style.border="2px solid rgb(216, 211, 211)";
    }
    section15.onmouseover=()=>{
        section15.style.border="3px solid black";
    }
    section15.onmouseout=()=>{
        section15.style.border="2px solid rgb(216, 211, 211)";
    }
    section16.onmouseover=()=>{
        section16.style.border="3px solid black";
    }
    section16.onmouseout=()=>{
        section16.style.border="2px solid rgb(216, 211, 211)";
    }
    section17.onmouseover=()=>{
        section17.style.border="3px solid black";
    }
    section17.onmouseout=()=>{
        section17.style.border="2px solid rgb(216, 211, 211)";
    }
    section18.onmouseover=()=>{
        section18.style.border="3px solid black";
    }
    section18.onmouseout=()=>{
        section18.style.border="2px solid rgb(216, 211, 211)";
    }
    section19.onmouseover=()=>{
        section19.style.border="3px solid black";
    }
    section19.onmouseout=()=>{
        section19.style.border="2px solid rgb(216, 211, 211)";
    }
    section20.onmouseover=()=>{
        section20.style.border="3px solid black";
    }
    section20.onmouseout=()=>{
        section20.style.border="2px solid rgb(216, 211, 211)";
    }
    section21.onmouseover=()=>{
        section21.style.border="3px solid black";
    }
    section21.onmouseout=()=>{
        section21.style.border="2px solid rgb(216, 211, 211)";
    }
    section22.onmouseover=()=>{
        section22.style.border="3px solid black";
    }
    section22.onmouseout=()=>{
        section22.style.border="2px solid rgb(216, 211, 211)";
    }
    section23.onmouseover=()=>{
        section23.style.border="3px solid black";
    }
    section23.onmouseout=()=>{
        section23.style.border="2px solid rgb(216, 211, 211)";
    }
    section24.onmouseover=()=>{
        section24.style.border="3px solid black";
    }
    section24.onmouseout=()=>{
        section24.style.border="2px solid rgb(216, 211, 211)";
    }
    section25.onmouseover=()=>{
        section25.style.border="3px solid black";
    }
    section25.onmouseout=()=>{
        section25.style.border="2px solid rgb(216, 211, 211)";
    }
    section26.onmouseover=()=>{
        section26.style.border="3px solid black";
    }
    section26.onmouseout=()=>{
        section26.style.border="2px solid rgb(216, 211, 211)";
    }
    section27.onmouseover=()=>{
        section27.style.border="3px solid black";
    }
    section27.onmouseout=()=>{
        section27.style.border="2px solid rgb(216, 211, 211)";
    }
    section28.onmouseover=()=>{
        section28.style.border="3px solid black";
    }
    section28.onmouseout=()=>{
        section28.style.border="2px solid rgb(216, 211, 211)";
    }
    section29.onmouseover=()=>{
        section29.style.border="3px solid black";
    }
    section29.onmouseout=()=>{
        section29.style.border="2px solid rgb(216, 211, 211)";
    }
    section30.onmouseover=()=>{
        section30.style.border="3px solid black";
    }
    section30.onmouseout=()=>{
        section30.style.border="2px solid rgb(216, 211, 211)";
    }
    section31.onmouseover=()=>{
        section31.style.border="3px solid black";
    }
    section31.onmouseout=()=>{
        section31.style.border="2px solid rgb(216, 211, 211)";
    }
    section32.onmouseover=()=>{
        section32.style.border="3px solid black";
    }
    section32.onmouseout=()=>{
        section32.style.border="2px solid rgb(216, 211, 211)";
    }
    section33.onmouseover=()=>{
        section33.style.border="3px solid black";
    }
    section33.onmouseout=()=>{
        section33.style.border="3px solid black";
    }
    section34.onmouseover=()=>{
        section34.style.border="3px solid black";
    }
    section34.onmouseout=()=>{
        section34.style.border="2px solid rgb(216, 211, 211)";
    }
    section35.onmouseover=()=>{
        section35.style.border="3px solid black";
    }
    section35.onmouseout=()=>{
        section35.style.border="2px solid rgb(216, 211, 211)";
    }
    section36.onmouseover=()=>{
        section36.style.border="3px solid black";
    }
    section36.onmouseout=()=>{
        section36.style.border="2px solid rgb(216, 211, 211)";
    }
}
function fun29() {
    const section6 = document.getElementById("section6");
    const section7 = document.getElementById("section7");
    const section8 = document.getElementById("section8");
    const section9 = document.getElementById("section9");
    const section10 = document.getElementById("section10");
    const section11 = document.getElementById("section11");
    const section12 = document.getElementById("section12");
    const section13 = document.getElementById("section13");
    const section14 = document.getElementById("section14");
    const section15 = document.getElementById("section15");
    const section16 = document.getElementById("section16");
    const section17 = document.getElementById("section17");
    const section18 = document.getElementById("section18");
    const section19 = document.getElementById("section19");
    const section20 = document.getElementById("section20");
    const section21 = document.getElementById("section21");
    const section22 = document.getElementById("section22");
    const section23 = document.getElementById("section23");
    const section24 = document.getElementById("section24");
    const section25 = document.getElementById("section25");
    const section26 = document.getElementById("section26");
    const section27 = document.getElementById("section27");
    const section28 = document.getElementById("section28");
    const section29 = document.getElementById("section29");
    const section30 = document.getElementById("section30");
    const section31 = document.getElementById("section31");
    const section32 = document.getElementById("section32");
    const section33 = document.getElementById("section33");
    const section34 = document.getElementById("section34");
    const section35 = document.getElementById("section35");
    const section36 = document.getElementById("section36");
    const section37 = document.getElementsByClassName("section37")[0];
    section6.style.border = "2px solid rgb(216, 211, 211)";
    section7.style.border = "2px solid rgb(216, 211, 211)";
    section8.style.border = "2px solid rgb(216, 211, 211)";
    section9.style.border = "2px solid rgb(216, 211, 211)";
    section10.style.border = "2px solid rgb(216, 211, 211)";
    section11.style.border = "2px solid rgb(216, 211, 211)";
    section12.style.border = "2px solid rgb(216, 211, 211)";
    section13.style.border = "2px solid rgb(216, 211, 211)";
    section14.style.border = "2px solid rgb(216, 211, 211)";
    section15.style.border = "2px solid rgb(216, 211, 211)";
    section16.style.border = "2px solid rgb(216, 211, 211)";
    section17.style.border = "2px solid rgb(216, 211, 211)";
    section18.style.border = "2px solid rgb(216, 211, 211)";
    section19.style.border = "2px solid rgb(216, 211, 211)";
    section20.style.border = "2px solid rgb(216, 211, 211)";
    section21.style.border = "2px solid rgb(216, 211, 211)";
    section22.style.border = "2px solid rgb(216, 211, 211)";
    section23.style.border = "2px solid rgb(216, 211, 211)";
    section24.style.border = "2px solid rgb(216, 211, 211)";
    section25.style.border = "2px solid rgb(216, 211, 211)";
    section26.style.border = "2px solid rgb(216, 211, 211)";
    section27.style.border = "2px solid rgb(216, 211, 211)";
    section28.style.border = "2px solid rgb(216, 211, 211)";
    section29.style.border = "2px solid rgb(216, 211, 211)";
    section30.style.border = "2px solid rgb(216, 211, 211)";
    section31.style.border = "2px solid rgb(216, 211, 211)";
    section32.style.border = "2px solid rgb(216, 211, 211)";
    section33.style.border = "2px solid rgb(216, 211, 211)";
    section34.style.border = "3px solid black";
    section35.style.border = "2px solid rgb(216, 211, 211)";
    section36.style.border = "2px solid rgb(216, 211, 211)";
    section37.style.backgroundColor = "black";
    section37.style.cursor = "pointer";
    section37.onmouseover = () => {
        section37.style.cursor = "pointer"
    }
    section37.onmouseout = () => {
        section37.style.cursor = "pointer"
    }
    section6.onmouseover=()=>{
        section6.style.border="3px solid black";
    }
    section6.onmouseout=()=>{
        section6.style.border="2px solid rgb(216, 211, 211)";
    }
    section7.onmouseover=()=>{
        section7.style.border="3px solid black";
    }
    section7.onmouseout=()=>{
        section7.style.border="2px solid rgb(216, 211, 211)";
    }
    section8.onmouseover=()=>{
        section8.style.border="3px solid black";
    }
    section8.onmouseout=()=>{
        section8.style.border="2px solid rgb(216, 211, 211)";
    }
    section9.onmouseover=()=>{
        section9.style.border="3px solid black";
    }
    section9.onmouseout=()=>{
        section9.style.border="2px solid rgb(216, 211, 211)";
    }
    section10.onmouseover=()=>{
        section10.style.border="3px solid black";
    }
    section10.onmouseout=()=>{
        section10.style.border="2px solid rgb(216, 211, 211)";
    }
    section11.onmouseover=()=>{
        section11.style.border="3px solid black";
    }
    section11.onmouseout=()=>{
        section11.style.border="2px solid rgb(216, 211, 211)";
    }
    section12.onmouseover=()=>{
        section12.style.border="3px solid black";
    }
    section12.onmouseout=()=>{
        section12.style.border="2px solid rgb(216, 211, 211)";
    }
    section13.onmouseover=()=>{
        section13.style.border="3px solid black";
    }
    section13.onmouseout=()=>{
        section13.style.border="2px solid rgb(216, 211, 211)";
    }
    section14.onmouseover=()=>{
        section14.style.border="3px solid black";
    }
    section14.onmouseout=()=>{
        section14.style.border="2px solid rgb(216, 211, 211)";
    }
    section15.onmouseover=()=>{
        section15.style.border="3px solid black";
    }
    section15.onmouseout=()=>{
        section15.style.border="2px solid rgb(216, 211, 211)";
    }
    section16.onmouseover=()=>{
        section16.style.border="3px solid black";
    }
    section16.onmouseout=()=>{
        section16.style.border="2px solid rgb(216, 211, 211)";
    }
    section17.onmouseover=()=>{
        section17.style.border="3px solid black";
    }
    section17.onmouseout=()=>{
        section17.style.border="2px solid rgb(216, 211, 211)";
    }
    section18.onmouseover=()=>{
        section18.style.border="3px solid black";
    }
    section18.onmouseout=()=>{
        section18.style.border="2px solid rgb(216, 211, 211)";
    }
    section19.onmouseover=()=>{
        section19.style.border="3px solid black";
    }
    section19.onmouseout=()=>{
        section19.style.border="2px solid rgb(216, 211, 211)";
    }
    section20.onmouseover=()=>{
        section20.style.border="3px solid black";
    }
    section20.onmouseout=()=>{
        section20.style.border="2px solid rgb(216, 211, 211)";
    }
    section21.onmouseover=()=>{
        section21.style.border="3px solid black";
    }
    section21.onmouseout=()=>{
        section21.style.border="2px solid rgb(216, 211, 211)";
    }
    section22.onmouseover=()=>{
        section22.style.border="3px solid black";
    }
    section22.onmouseout=()=>{
        section22.style.border="2px solid rgb(216, 211, 211)";
    }
    section23.onmouseover=()=>{
        section23.style.border="3px solid black";
    }
    section23.onmouseout=()=>{
        section23.style.border="2px solid rgb(216, 211, 211)";
    }
    section24.onmouseover=()=>{
        section24.style.border="3px solid black";
    }
    section24.onmouseout=()=>{
        section24.style.border="2px solid rgb(216, 211, 211)";
    }
    section25.onmouseover=()=>{
        section25.style.border="3px solid black";
    }
    section25.onmouseout=()=>{
        section25.style.border="2px solid rgb(216, 211, 211)";
    }
    section26.onmouseover=()=>{
        section26.style.border="3px solid black";
    }
    section26.onmouseout=()=>{
        section26.style.border="2px solid rgb(216, 211, 211)";
    }
    section27.onmouseover=()=>{
        section27.style.border="3px solid black";
    }
    section27.onmouseout=()=>{
        section27.style.border="2px solid rgb(216, 211, 211)";
    }
    section28.onmouseover=()=>{
        section28.style.border="3px solid black";
    }
    section28.onmouseout=()=>{
        section28.style.border="2px solid rgb(216, 211, 211)";
    }
    section29.onmouseover=()=>{
        section29.style.border="3px solid black";
    }
    section29.onmouseout=()=>{
        section29.style.border="2px solid rgb(216, 211, 211)";
    }
    section30.onmouseover=()=>{
        section30.style.border="3px solid black";
    }
    section30.onmouseout=()=>{
        section30.style.border="2px solid rgb(216, 211, 211)";
    }
    section31.onmouseover=()=>{
        section31.style.border="3px solid black";
    }
    section31.onmouseout=()=>{
        section31.style.border="2px solid rgb(216, 211, 211)";
    }
    section32.onmouseover=()=>{
        section32.style.border="3px solid black";
    }
    section32.onmouseout=()=>{
        section32.style.border="2px solid rgb(216, 211, 211)";
    }
    section33.onmouseover=()=>{
        section33.style.border="3px solid black";
    }
    section33.onmouseout=()=>{
        section33.style.border="2px solid rgb(216, 211, 211)";
    }
    section34.onmouseover=()=>{
        section34.style.border="3px solid black";
    }
    section34.onmouseout=()=>{
        section34.style.border="3px solid black";
    }
    section35.onmouseover=()=>{
        section35.style.border="3px solid black";
    }
    section35.onmouseout=()=>{
        section35.style.border="2px solid rgb(216, 211, 211)";
    }
    section36.onmouseover=()=>{
        section36.style.border="3px solid black";
    }
    section36.onmouseout=()=>{
        section36.style.border="2px solid rgb(216, 211, 211)";
    }
}
function fun30() {
    const section6 = document.getElementById("section6");
    const section7 = document.getElementById("section7");
    const section8 = document.getElementById("section8");
    const section9 = document.getElementById("section9");
    const section10 = document.getElementById("section10");
    const section11 = document.getElementById("section11");
    const section12 = document.getElementById("section12");
    const section13 = document.getElementById("section13");
    const section14 = document.getElementById("section14");
    const section15 = document.getElementById("section15");
    const section16 = document.getElementById("section16");
    const section17 = document.getElementById("section17");
    const section18 = document.getElementById("section18");
    const section19 = document.getElementById("section19");
    const section20 = document.getElementById("section20");
    const section21 = document.getElementById("section21");
    const section22 = document.getElementById("section22");
    const section23 = document.getElementById("section23");
    const section24 = document.getElementById("section24");
    const section25 = document.getElementById("section25");
    const section26 = document.getElementById("section26");
    const section27 = document.getElementById("section27");
    const section28 = document.getElementById("section28");
    const section29 = document.getElementById("section29");
    const section30 = document.getElementById("section30");
    const section31 = document.getElementById("section31");
    const section32 = document.getElementById("section32");
    const section33 = document.getElementById("section33");
    const section34 = document.getElementById("section34");
    const section35 = document.getElementById("section35");
    const section36 = document.getElementById("section36");
    const section37 = document.getElementsByClassName("section37")[0];
    section6.style.border = "2px solid rgb(216, 211, 211)";
    section7.style.border = "2px solid rgb(216, 211, 211)";
    section8.style.border = "2px solid rgb(216, 211, 211)";
    section9.style.border = "2px solid rgb(216, 211, 211)";
    section10.style.border = "2px solid rgb(216, 211, 211)";
    section11.style.border = "2px solid rgb(216, 211, 211)";
    section12.style.border = "2px solid rgb(216, 211, 211)";
    section13.style.border = "2px solid rgb(216, 211, 211)";
    section14.style.border = "2px solid rgb(216, 211, 211)";
    section15.style.border = "2px solid rgb(216, 211, 211)";
    section16.style.border = "2px solid rgb(216, 211, 211)";
    section17.style.border = "2px solid rgb(216, 211, 211)";
    section18.style.border = "2px solid rgb(216, 211, 211)";
    section19.style.border = "2px solid rgb(216, 211, 211)";
    section20.style.border = "2px solid rgb(216, 211, 211)";
    section21.style.border = "2px solid rgb(216, 211, 211)";
    section22.style.border = "2px solid rgb(216, 211, 211)";
    section23.style.border = "2px solid rgb(216, 211, 211)";
    section24.style.border = "2px solid rgb(216, 211, 211)";
    section25.style.border = "2px solid rgb(216, 211, 211)";
    section26.style.border = "2px solid rgb(216, 211, 211)";
    section27.style.border = "2px solid rgb(216, 211, 211)";
    section28.style.border = "2px solid rgb(216, 211, 211)";
    section29.style.border = "2px solid rgb(216, 211, 211)";
    section30.style.border = "2px solid rgb(216, 211, 211)";
    section31.style.border = "2px solid rgb(216, 211, 211)";
    section32.style.border = "2px solid rgb(216, 211, 211)";
    section33.style.border = "2px solid rgb(216, 211, 211)";
    section34.style.border = "2px solid rgb(216, 211, 211)";
    section35.style.border = "3px solid black";
    section36.style.border = "2px solid rgb(216, 211, 211)";
    section37.style.backgroundColor = "black";
    section37.style.cursor = "pointer";
    section37.onmouseover = () => {
        section37.style.cursor = "pointer"
    }
    section37.onmouseout = () => {
        section37.style.cursor = "pointer"
    }
    section6.onmouseover=()=>{
        section6.style.border="3px solid black";
    }
    section6.onmouseout=()=>{
        section6.style.border="2px solid rgb(216, 211, 211)";
    }
    section7.onmouseover=()=>{
        section7.style.border="3px solid black";
    }
    section7.onmouseout=()=>{
        section7.style.border="2px solid rgb(216, 211, 211)";
    }
    section8.onmouseover=()=>{
        section8.style.border="3px solid black";
    }
    section8.onmouseout=()=>{
        section8.style.border="2px solid rgb(216, 211, 211)";
    }
    section9.onmouseover=()=>{
        section9.style.border="3px solid black";
    }
    section9.onmouseout=()=>{
        section9.style.border="2px solid rgb(216, 211, 211)";
    }
    section10.onmouseover=()=>{
        section10.style.border="3px solid black";
    }
    section10.onmouseout=()=>{
        section10.style.border="2px solid rgb(216, 211, 211)";
    }
    section11.onmouseover=()=>{
        section11.style.border="3px solid black";
    }
    section11.onmouseout=()=>{
        section11.style.border="2px solid rgb(216, 211, 211)";
    }
    section12.onmouseover=()=>{
        section12.style.border="3px solid black";
    }
    section12.onmouseout=()=>{
        section12.style.border="2px solid rgb(216, 211, 211)";
    }
    section13.onmouseover=()=>{
        section13.style.border="3px solid black";
    }
    section13.onmouseout=()=>{
        section13.style.border="2px solid rgb(216, 211, 211)";
    }
    section14.onmouseover=()=>{
        section14.style.border="3px solid black";
    }
    section14.onmouseout=()=>{
        section14.style.border="2px solid rgb(216, 211, 211)";
    }
    section15.onmouseover=()=>{
        section15.style.border="3px solid black";
    }
    section15.onmouseout=()=>{
        section15.style.border="2px solid rgb(216, 211, 211)";
    }
    section16.onmouseover=()=>{
        section16.style.border="3px solid black";
    }
    section16.onmouseout=()=>{
        section16.style.border="2px solid rgb(216, 211, 211)";
    }
    section17.onmouseover=()=>{
        section17.style.border="3px solid black";
    }
    section17.onmouseout=()=>{
        section17.style.border="2px solid rgb(216, 211, 211)";
    }
    section18.onmouseover=()=>{
        section18.style.border="3px solid black";
    }
    section18.onmouseout=()=>{
        section18.style.border="2px solid rgb(216, 211, 211)";
    }
    section19.onmouseover=()=>{
        section19.style.border="3px solid black";
    }
    section19.onmouseout=()=>{
        section19.style.border="2px solid rgb(216, 211, 211)";
    }
    section20.onmouseover=()=>{
        section20.style.border="3px solid black";
    }
    section20.onmouseout=()=>{
        section20.style.border="2px solid rgb(216, 211, 211)";
    }
    section21.onmouseover=()=>{
        section21.style.border="3px solid black";
    }
    section21.onmouseout=()=>{
        section21.style.border="2px solid rgb(216, 211, 211)";
    }
    section22.onmouseover=()=>{
        section22.style.border="3px solid black";
    }
    section22.onmouseout=()=>{
        section22.style.border="2px solid rgb(216, 211, 211)";
    }
    section23.onmouseover=()=>{
        section23.style.border="3px solid black";
    }
    section23.onmouseout=()=>{
        section23.style.border="2px solid rgb(216, 211, 211)";
    }
    section24.onmouseover=()=>{
        section24.style.border="3px solid black";
    }
    section24.onmouseout=()=>{
        section24.style.border="2px solid rgb(216, 211, 211)";
    }
    section25.onmouseover=()=>{
        section25.style.border="3px solid black";
    }
    section25.onmouseout=()=>{
        section25.style.border="2px solid rgb(216, 211, 211)";
    }
    section26.onmouseover=()=>{
        section26.style.border="3px solid black";
    }
    section26.onmouseout=()=>{
        section26.style.border="2px solid rgb(216, 211, 211)";
    }
    section27.onmouseover=()=>{
        section27.style.border="3px solid black";
    }
    section27.onmouseout=()=>{
        section27.style.border="2px solid rgb(216, 211, 211)";
    }
    section28.onmouseover=()=>{
        section28.style.border="3px solid black";
    }
    section28.onmouseout=()=>{
        section28.style.border="2px solid rgb(216, 211, 211)";
    }
    section29.onmouseover=()=>{
        section29.style.border="3px solid black";
    }
    section29.onmouseout=()=>{
        section29.style.border="2px solid rgb(216, 211, 211)";
    }
    section30.onmouseover=()=>{
        section30.style.border="3px solid black";
    }
    section30.onmouseout=()=>{
        section30.style.border="2px solid rgb(216, 211, 211)";
    }
    section31.onmouseover=()=>{
        section31.style.border="3px solid black";
    }
    section31.onmouseout=()=>{
        section31.style.border="2px solid rgb(216, 211, 211)";
    }
    section32.onmouseover=()=>{
        section32.style.border="3px solid black";
    }
    section32.onmouseout=()=>{
        section32.style.border="2px solid rgb(216, 211, 211)";
    }
    section33.onmouseover=()=>{
        section33.style.border="3px solid black";
    }
    section33.onmouseout=()=>{
        section33.style.border="2px solid rgb(216, 211, 211)";
    }
    section34.onmouseover=()=>{
        section34.style.border="3px solid black";
    }
    section34.onmouseout=()=>{
        section34.style.border="2px solid rgb(216, 211, 211)";
    }
    section35.onmouseover=()=>{
        section35.style.border="3px solid black";
    }
    section35.onmouseout=()=>{
        section35.style.border="3px solid black";
    }
    section36.onmouseover=()=>{
        section36.style.border="3px solid black";
    }
    section36.onmouseout=()=>{
        section36.style.border="2px solid rgb(216, 211, 211)";
    }
}
function fun31() {
    const section6 = document.getElementById("section6");
    const section7 = document.getElementById("section7");
    const section8 = document.getElementById("section8");
    const section9 = document.getElementById("section9");
    const section10 = document.getElementById("section10");
    const section11 = document.getElementById("section11");
    const section12 = document.getElementById("section12");
    const section13 = document.getElementById("section13");
    const section14 = document.getElementById("section14");
    const section15 = document.getElementById("section15");
    const section16 = document.getElementById("section16");
    const section17 = document.getElementById("section17");
    const section18 = document.getElementById("section18");
    const section19 = document.getElementById("section19");
    const section20 = document.getElementById("section20");
    const section21 = document.getElementById("section21");
    const section22 = document.getElementById("section22");
    const section23 = document.getElementById("section23");
    const section24 = document.getElementById("section24");
    const section25 = document.getElementById("section25");
    const section26 = document.getElementById("section26");
    const section27 = document.getElementById("section27");
    const section28 = document.getElementById("section28");
    const section29 = document.getElementById("section29");
    const section30 = document.getElementById("section30");
    const section31 = document.getElementById("section31");
    const section32 = document.getElementById("section32");
    const section33 = document.getElementById("section33");
    const section34 = document.getElementById("section34");
    const section35 = document.getElementById("section35");
    const section36 = document.getElementById("section36");
    const section37 = document.getElementsByClassName("section37")[0];
    section6.style.border = "2px solid rgb(216, 211, 211)";
    section7.style.border = "2px solid rgb(216, 211, 211)";
    section8.style.border = "2px solid rgb(216, 211, 211)";
    section9.style.border = "2px solid rgb(216, 211, 211)";
    section10.style.border = "2px solid rgb(216, 211, 211)";
    section11.style.border = "2px solid rgb(216, 211, 211)";
    section12.style.border = "2px solid rgb(216, 211, 211)";
    section13.style.border = "2px solid rgb(216, 211, 211)";
    section14.style.border = "2px solid rgb(216, 211, 211)";
    section15.style.border = "2px solid rgb(216, 211, 211)";
    section16.style.border = "2px solid rgb(216, 211, 211)";
    section17.style.border = "2px solid rgb(216, 211, 211)";
    section18.style.border = "2px solid rgb(216, 211, 211)";
    section19.style.border = "2px solid rgb(216, 211, 211)";
    section20.style.border = "2px solid rgb(216, 211, 211)";
    section21.style.border = "2px solid rgb(216, 211, 211)";
    section22.style.border = "2px solid rgb(216, 211, 211)";
    section23.style.border = "2px solid rgb(216, 211, 211)";
    section24.style.border = "2px solid rgb(216, 211, 211)";
    section25.style.border = "2px solid rgb(216, 211, 211)";
    section26.style.border = "2px solid rgb(216, 211, 211)";
    section27.style.border = "2px solid rgb(216, 211, 211)";
    section28.style.border = "2px solid rgb(216, 211, 211)";
    section29.style.border = "2px solid rgb(216, 211, 211)";
    section30.style.border = "2px solid rgb(216, 211, 211)";
    section31.style.border = "2px solid rgb(216, 211, 211)";
    section32.style.border = "2px solid rgb(216, 211, 211)";
    section33.style.border = "2px solid rgb(216, 211, 211)";
    section34.style.border = "2px solid rgb(216, 211, 211)";
    section35.style.border = "2px solid rgb(216, 211, 211)";
    section36.style.border = "3px solid black";
    section37.style.backgroundColor = "black";
    section37.style.cursor = "pointer";
    section37.onmouseover = () => {
        section37.style.cursor = "pointer"
    }
    section37.onmouseout = () => {
        section37.style.cursor = "pointer"
    }
    section6.onmouseover=()=>{
        section6.style.border="3px solid black";
    }
    section6.onmouseout=()=>{
        section6.style.border="2px solid rgb(216, 211, 211)";
    }
    section7.onmouseover=()=>{
        section7.style.border="3px solid black";
    }
    section7.onmouseout=()=>{
        section7.style.border="2px solid rgb(216, 211, 211)";
    }
    section8.onmouseover=()=>{
        section8.style.border="3px solid black";
    }
    section8.onmouseout=()=>{
        section8.style.border="2px solid rgb(216, 211, 211)";
    }
    section9.onmouseover=()=>{
        section9.style.border="3px solid black";
    }
    section9.onmouseout=()=>{
        section9.style.border="2px solid rgb(216, 211, 211)";
    }
    section10.onmouseover=()=>{
        section10.style.border="3px solid black";
    }
    section10.onmouseout=()=>{
        section10.style.border="2px solid rgb(216, 211, 211)";
    }
    section11.onmouseover=()=>{
        section11.style.border="3px solid black";
    }
    section11.onmouseout=()=>{
        section11.style.border="2px solid rgb(216, 211, 211)";
    }
    section12.onmouseover=()=>{
        section12.style.border="3px solid black";
    }
    section12.onmouseout=()=>{
        section12.style.border="2px solid rgb(216, 211, 211)";
    }
    section13.onmouseover=()=>{
        section13.style.border="3px solid black";
    }
    section13.onmouseout=()=>{
        section13.style.border="2px solid rgb(216, 211, 211)";
    }
    section14.onmouseover=()=>{
        section14.style.border="3px solid black";
    }
    section14.onmouseout=()=>{
        section14.style.border="2px solid rgb(216, 211, 211)";
    }
    section15.onmouseover=()=>{
        section15.style.border="3px solid black";
    }
    section15.onmouseout=()=>{
        section15.style.border="2px solid rgb(216, 211, 211)";
    }
    section16.onmouseover=()=>{
        section16.style.border="3px solid black";
    }
    section16.onmouseout=()=>{
        section16.style.border="2px solid rgb(216, 211, 211)";
    }
    section17.onmouseover=()=>{
        section17.style.border="3px solid black";
    }
    section17.onmouseout=()=>{
        section17.style.border="2px solid rgb(216, 211, 211)";
    }
    section18.onmouseover=()=>{
        section18.style.border="3px solid black";
    }
    section18.onmouseout=()=>{
        section18.style.border="2px solid rgb(216, 211, 211)";
    }
    section19.onmouseover=()=>{
        section19.style.border="3px solid black";
    }
    section19.onmouseout=()=>{
        section19.style.border="2px solid rgb(216, 211, 211)";
    }
    section20.onmouseover=()=>{
        section20.style.border="3px solid black";
    }
    section20.onmouseout=()=>{
        section20.style.border="2px solid rgb(216, 211, 211)";
    }
    section21.onmouseover=()=>{
        section21.style.border="3px solid black";
    }
    section21.onmouseout=()=>{
        section21.style.border="2px solid rgb(216, 211, 211)";
    }
    section22.onmouseover=()=>{
        section22.style.border="3px solid black";
    }
    section22.onmouseout=()=>{
        section22.style.border="2px solid rgb(216, 211, 211)";
    }
    section23.onmouseover=()=>{
        section23.style.border="3px solid black";
    }
    section23.onmouseout=()=>{
        section23.style.border="2px solid rgb(216, 211, 211)";
    }
    section24.onmouseover=()=>{
        section24.style.border="3px solid black";
    }
    section24.onmouseout=()=>{
        section24.style.border="2px solid rgb(216, 211, 211)";
    }
    section25.onmouseover=()=>{
        section25.style.border="3px solid black";
    }
    section25.onmouseout=()=>{
        section25.style.border="2px solid rgb(216, 211, 211)";
    }
    section26.onmouseover=()=>{
        section26.style.border="3px solid black";
    }
    section26.onmouseout=()=>{
        section26.style.border="2px solid rgb(216, 211, 211)";
    }
    section27.onmouseover=()=>{
        section27.style.border="3px solid black";
    }
    section27.onmouseout=()=>{
        section27.style.border="2px solid rgb(216, 211, 211)";
    }
    section28.onmouseover=()=>{
        section28.style.border="3px solid black";
    }
    section28.onmouseout=()=>{
        section28.style.border="2px solid rgb(216, 211, 211)";
    }
    section29.onmouseover=()=>{
        section29.style.border="3px solid black";
    }
    section29.onmouseout=()=>{
        section29.style.border="2px solid rgb(216, 211, 211)";
    }
    section30.onmouseover=()=>{
        section30.style.border="3px solid black";
    }
    section30.onmouseout=()=>{
        section30.style.border="2px solid rgb(216, 211, 211)";
    }
    section31.onmouseover=()=>{
        section31.style.border="3px solid black";
    }
    section31.onmouseout=()=>{
        section31.style.border="2px solid rgb(216, 211, 211)";
    }
    section32.onmouseover=()=>{
        section32.style.border="3px solid black";
    }
    section32.onmouseout=()=>{
        section32.style.border="2px solid rgb(216, 211, 211)";
    }
    section33.onmouseover=()=>{
        section33.style.border="3px solid black";
    }
    section33.onmouseout=()=>{
        section33.style.border="2px solid rgb(216, 211, 211)";
    }
    section34.onmouseover=()=>{
        section34.style.border="3px solid black";
    }
    section34.onmouseout=()=>{
        section34.style.border="2px solid rgb(216, 211, 211)";
    }
    section35.onmouseover=()=>{
        section35.style.border="3px solid black";
    }
    section35.onmouseout=()=>{
        section35.style.border="2px solid rgb(216, 211, 211)";
    }
    section36.onmouseover=()=>{
        section36.style.border="3px solid black";
    }
    section36.onmouseout=()=>{
        section36.style.border="3px solid black";
    }
}
function nextbutton(event){
    event.preventDefault();
        const section37=document.getElementsByClassName("section37")[0];
        if(section37.style.backgroundColor==="black" && section37.style.cursor==="pointer"){
        fetch('/nexttwo',{
            method:'get',
            headers:{
                'Content-Type':'application/json'
            }
        })
        .then(response=>{
            if(response.redirected){
                window.location.href=response.url;
            }
            else{
                throw new Error
            }
        })
        .then(data=>{
            console.log(data)
        })
        .catch(error=>console.error(error));
    }
}
const next=document.getElementById("next");
next.addEventListener("submit",nextbutton);
function back(event){
    event.preventDefault();
    fetch('/back1',{
        method:'get',
        headers:{
            'Content-Type':'application/json'
        }
    })
    .then(response=>{
        if(response.redirected){
            window.location.href=response.url;
        }
        else{
            throw new Error
        }
    })
    .then(data=>{
        console.log(data)
    })
    .catch(error=>console.error(error));
}