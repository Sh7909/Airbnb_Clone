const point = document.getElementById('point');
const line = document.querySelector('.line');

let isDragging = false;

point.addEventListener('mousedown', startDrag);
point.addEventListener('mouseup', endDrag);
document.addEventListener('mousemove', drag);

function startDrag(e) {
    isDragging = true;
}

function endDrag(e) {
    isDragging = false;
}

function drag(e) {
    const test1 = document.getElementById("test1");
    const test2 = document.getElementById("test2");
    const test3 = document.getElementById("test3");
    const test4 = document.getElementById("test4");
    const test5 = document.getElementById("test5");
    const test6 = document.getElementById("test6");
    const test7 = document.getElementById("test7");
    const test8 = document.getElementById("test8");
    const test9 = document.getElementById("test9");
    const test10 = document.getElementById("test10");
    const test11 = document.getElementById("test11");
    const test12 = document.getElementById("test12");
    const test13 = document.getElementById("test13");
    const test14 = document.getElementById("test14");
    const test15 = document.getElementById("test15");
    const test16 = document.getElementById("test16");
    const test17 = document.getElementById("test17");
    const test18 = document.getElementById("test18");
    const test19 = document.getElementById("test19");
    const test20 = document.getElementById("test20");
    const test21 = document.getElementById("test21");
    const test22 = document.getElementById("test22");
    const test23 = document.getElementById("test23");
    const test24 = document.getElementById("test24");
    const test25 = document.getElementById("test25");
    const test26 = document.getElementById("test26");
    const test27 = document.getElementById("test27");
    const test28 = document.getElementById("test28");
    const test29 = document.getElementById("test29");
    const test30 = document.getElementById("test30");
    const nightschange1 = document.getElementById("nightschange1");
    const nightschange2 = document.getElementById("nightschange2");
    const nightschange3 = document.getElementById("nightschange3");
    const nightschange4 = document.getElementById("nightschange4");
    const nightschange5 = document.getElementById("nightschange5");
    const nightschange6 = document.getElementById("nightschange6");
    const nightschange7 = document.getElementById("nightschange7");
    const nightschange8 = document.getElementById("nightschange8");
    const nightschange9 = document.getElementById("nightschange9");
    const nightschange10 = document.getElementById("nightschange10");
    const nightschange11 = document.getElementById("nightschange11");
    const nightschange12 = document.getElementById("nightschange12");
    const nightschange13 = document.getElementById("nightschange13");
    const nightschange14 = document.getElementById("nightschange14");
    const nightschange15 = document.getElementById("nightschange15");
    const nightschange16 = document.getElementById("nightschange16");
    const nightschange17 = document.getElementById("nightschange17");
    const nightschange18 = document.getElementById("nightschange18");
    const nightschange19 = document.getElementById("nightschange19");
    const nightschange20 = document.getElementById("nightschange20");
    const nightschange21 = document.getElementById("nightschange21");
    const nightschange22 = document.getElementById("nightschange22");
    const nightschange23 = document.getElementById("nightschange23");
    const nightschange24 = document.getElementById("nightschange24");
    const nightschange25 = document.getElementById("nightschange25");
    const nightschange26 = document.getElementById("nightschange26");
    const nightschange27 = document.getElementById("nightschange27");
    const nightschange28 = document.getElementById("nightschange28");
    const nightschange29 = document.getElementById("nightschange29");
    const nightschange30 = document.getElementById("nightschange30");
    const line = document.getElementsByClassName("line")[0];
    if (isDragging) {
        const rect = line.getBoundingClientRect();
        const mouseX = e.clientX - rect.left;
        const maxX = rect.width;
        if (mouseX > 0) {
            line.style.backgroundColor = "black";
            if (mouseX == 40) {
                test1.style.display = "block";
                test2.style.display = "none";
                test3.style.display = "none";
                test4.style.display = "none";
                test5.style.display = "none";
                test6.style.display = "none";
                test7.style.display = "none";
                test8.style.display = "none";
                test9.style.display = "none";
                test10.style.display = "none";
                test11.style.display = "none";
                test12.style.display = "none";
                test13.style.display = "none";
                test14.style.display = "none";
                test15.style.display = "none";
                test16.style.display = "none";
                test17.style.display = "none";
                test18.style.display = "none";
                test19.style.display = "none";
                test20.style.display = "none";
                test21.style.display = "none";
                test22.style.display = "none";
                test23.style.display = "none";
                test24.style.display = "none";
                test25.style.display = "none";
                test26.style.display = "none";
                test27.style.display = "none";
                test28.style.display = "none";
                test29.style.display = "none";
                test30.style.display = "none";
                nightschange1.style.display = "block";
                nightschange2.style.display = "none";
                nightschange3.style.display = "none";
                nightschange4.style.display = "none";
                nightschange5.style.display = "none";
                nightschange6.style.display = "none";
                nightschange7.style.display = "none";
                nightschange8.style.display = "none";
                nightschange9.style.display = "none";
                nightschange10.style.display = "none";
                nightschange11.style.display = "none";
                nightschange12.style.display = "none";
                nightschange13.style.display = "none";
                nightschange14.style.display = "none";
                nightschange15.style.display = "none";
                nightschange16.style.display = "none";
                nightschange17.style.display = "none";
                nightschange18.style.display = "none";
                nightschange19.style.display = "none";
                nightschange20.style.display = "none";
                nightschange21.style.display = "none";
                nightschange22.style.display = "none";
                nightschange23.style.display = "none";
                nightschange24.style.display = "none";
                nightschange25.style.display = "none";
                nightschange26.style.display = "none";
                nightschange27.style.display = "none";
                nightschange28.style.display = "none";
                nightschange29.style.display = "none";
                nightschange30.style.display = "none";
            }
            if (mouseX == 80) {
                test1.style.display = "none";
                test2.style.display = "block";
                test3.style.display = "none";
                test4.style.display = "none";
                test5.style.display = "none";
                test6.style.display = "none";
                test7.style.display = "none";
                test8.style.display = "none";
                test9.style.display = "none";
                test10.style.display = "none";
                test11.style.display = "none";
                test12.style.display = "none";
                test13.style.display = "none";
                test14.style.display = "none";
                test15.style.display = "none";
                test16.style.display = "none";
                test17.style.display = "none";
                test18.style.display = "none";
                test19.style.display = "none";
                test20.style.display = "none";
                test21.style.display = "none";
                test22.style.display = "none";
                test23.style.display = "none";
                test24.style.display = "none";
                test25.style.display = "none";
                test26.style.display = "none";
                test27.style.display = "none";
                test28.style.display = "none";
                test29.style.display = "none";
                test30.style.display = "none";
                nightschange1.style.display = "none";
                nightschange2.style.display = "block";
                nightschange3.style.display = "none";
                nightschange4.style.display = "none";
                nightschange5.style.display = "none";
                nightschange6.style.display = "none";
                nightschange7.style.display = "none";
                nightschange8.style.display = "none";
                nightschange9.style.display = "none";
                nightschange10.style.display = "none";
                nightschange11.style.display = "none";
                nightschange12.style.display = "none";
                nightschange13.style.display = "none";
                nightschange14.style.display = "none";
                nightschange15.style.display = "none";
                nightschange16.style.display = "none";
                nightschange17.style.display = "none";
                nightschange18.style.display = "none";
                nightschange19.style.display = "none";
                nightschange20.style.display = "none";
                nightschange21.style.display = "none";
                nightschange22.style.display = "none";
                nightschange23.style.display = "none";
                nightschange24.style.display = "none";
                nightschange25.style.display = "none";
                nightschange26.style.display = "none";
                nightschange27.style.display = "none";
                nightschange28.style.display = "none";
                nightschange29.style.display = "none";
                nightschange30.style.display = "none";
            }
            else if (mouseX == 120) {
                test1.style.display = "none";
                test2.style.display = "none";
                test3.style.display = "block";
                test4.style.display = "none";
                test5.style.display = "none";
                test6.style.display = "none";
                test7.style.display = "none";
                test8.style.display = "none";
                test9.style.display = "none";
                test10.style.display = "none";
                test11.style.display = "none";
                test12.style.display = "none";
                test13.style.display = "none";
                test14.style.display = "none";
                test15.style.display = "none";
                test16.style.display = "none";
                test17.style.display = "none";
                test18.style.display = "none";
                test19.style.display = "none";
                test20.style.display = "none";
                test21.style.display = "none";
                test22.style.display = "none";
                test23.style.display = "none";
                test24.style.display = "none";
                test25.style.display = "none";
                test26.style.display = "none";
                test27.style.display = "none";
                test28.style.display = "none";
                test29.style.display = "none";
                test30.style.display = "none";
                nightschange1.style.display = "none";
                nightschange2.style.display = "none";
                nightschange3.style.display = "block";
                nightschange4.style.display = "none";
                nightschange5.style.display = "none";
                nightschange6.style.display = "none";
                nightschange7.style.display = "none";
                nightschange8.style.display = "none";
                nightschange9.style.display = "none";
                nightschange10.style.display = "none";
                nightschange11.style.display = "none";
                nightschange12.style.display = "none";
                nightschange13.style.display = "none";
                nightschange14.style.display = "none";
                nightschange15.style.display = "none";
                nightschange16.style.display = "none";
                nightschange17.style.display = "none";
                nightschange18.style.display = "none";
                nightschange19.style.display = "none";
                nightschange20.style.display = "none";
                nightschange21.style.display = "none";
                nightschange22.style.display = "none";
                nightschange23.style.display = "none";
                nightschange24.style.display = "none";
                nightschange25.style.display = "none";
                nightschange26.style.display = "none";
                nightschange27.style.display = "none";
                nightschange28.style.display = "none";
                nightschange29.style.display = "none";
                nightschange30.style.display = "none";
            }
            else if (mouseX == 160) {
                test1.style.display = "none";
                test2.style.display = "none";
                test3.style.display = "none";
                test4.style.display = "block";
                test5.style.display = "none";
                test6.style.display = "none";
                test7.style.display = "none";
                test8.style.display = "none";
                test9.style.display = "none";
                test10.style.display = "none";
                test11.style.display = "none";
                test12.style.display = "none";
                test13.style.display = "none";
                test14.style.display = "none";
                test15.style.display = "none";
                test16.style.display = "none";
                test17.style.display = "none";
                test18.style.display = "none";
                test19.style.display = "none";
                test20.style.display = "none";
                test21.style.display = "none";
                test22.style.display = "none";
                test23.style.display = "none";
                test24.style.display = "none";
                test25.style.display = "none";
                test26.style.display = "none";
                test27.style.display = "none";
                test28.style.display = "none";
                test29.style.display = "none";
                test30.style.display = "none";
                nightschange1.style.display = "none";
                nightschange2.style.display = "none";
                nightschange3.style.display = "none";
                nightschange4.style.display = "block";
                nightschange5.style.display = "none";
                nightschange6.style.display = "none";
                nightschange7.style.display = "none";
                nightschange8.style.display = "none";
                nightschange9.style.display = "none";
                nightschange10.style.display = "none";
                nightschange11.style.display = "none";
                nightschange12.style.display = "none";
                nightschange13.style.display = "none";
                nightschange14.style.display = "none";
                nightschange15.style.display = "none";
                nightschange16.style.display = "none";
                nightschange17.style.display = "none";
                nightschange18.style.display = "none";
                nightschange19.style.display = "none";
                nightschange20.style.display = "none";
                nightschange21.style.display = "none";
                nightschange22.style.display = "none";
                nightschange23.style.display = "none";
                nightschange24.style.display = "none";
                nightschange25.style.display = "none";
                nightschange26.style.display = "none";
                nightschange27.style.display = "none";
                nightschange28.style.display = "none";
                nightschange29.style.display = "none";
                nightschange30.style.display = "none";
            }
            else if (mouseX == 200) {
                test1.style.display = "none";
                test2.style.display = "none";
                test3.style.display = "none";
                test4.style.display = "none";
                test5.style.display = "block";
                test6.style.display = "none";
                test7.style.display = "none";
                test8.style.display = "none";
                test9.style.display = "none";
                test10.style.display = "none";
                test11.style.display = "none";
                test12.style.display = "none";
                test13.style.display = "none";
                test14.style.display = "none";
                test15.style.display = "none";
                test16.style.display = "none";
                test17.style.display = "none";
                test18.style.display = "none";
                test19.style.display = "none";
                test20.style.display = "none";
                test21.style.display = "none";
                test22.style.display = "none";
                test23.style.display = "none";
                test24.style.display = "none";
                test25.style.display = "none";
                test26.style.display = "none";
                test27.style.display = "none";
                test28.style.display = "none";
                test29.style.display = "none";
                test30.style.display = "none";
                nightschange1.style.display = "none";
                nightschange2.style.display = "none";
                nightschange3.style.display = "none";
                nightschange4.style.display = "none";
                nightschange5.style.display = "block";
                nightschange6.style.display = "none";
                nightschange7.style.display = "none";
                nightschange8.style.display = "none";
                nightschange9.style.display = "none";
                nightschange10.style.display = "none";
                nightschange11.style.display = "none";
                nightschange12.style.display = "none";
                nightschange13.style.display = "none";
                nightschange14.style.display = "none";
                nightschange15.style.display = "none";
                nightschange16.style.display = "none";
                nightschange17.style.display = "none";
                nightschange18.style.display = "none";
                nightschange19.style.display = "none";
                nightschange20.style.display = "none";
                nightschange21.style.display = "none";
                nightschange22.style.display = "none";
                nightschange23.style.display = "none";
                nightschange24.style.display = "none";
                nightschange25.style.display = "none";
                nightschange26.style.display = "none";
                nightschange27.style.display = "none";
                nightschange28.style.display = "none";
                nightschange29.style.display = "none";
                nightschange30.style.display = "none";
            }
            else if (mouseX == 240) {
                test1.style.display = "none";
                test2.style.display = "none";
                test3.style.display = "none";
                test4.style.display = "none";
                test5.style.display = "none";
                test6.style.display = "block";
                test7.style.display = "none";
                test8.style.display = "none";
                test9.style.display = "none";
                test10.style.display = "none";
                test11.style.display = "none";
                test12.style.display = "none";
                test13.style.display = "none";
                test14.style.display = "none";
                test15.style.display = "none";
                test16.style.display = "none";
                test17.style.display = "none";
                test18.style.display = "none";
                test19.style.display = "none";
                test20.style.display = "none";
                test21.style.display = "none";
                test22.style.display = "none";
                test23.style.display = "none";
                test24.style.display = "none";
                test25.style.display = "none";
                test26.style.display = "none";
                test27.style.display = "none";
                test28.style.display = "none";
                test29.style.display = "none";
                test30.style.display = "none";
                nightschange1.style.display = "none";
                nightschange2.style.display = "none";
                nightschange3.style.display = "none";
                nightschange4.style.display = "none";
                nightschange5.style.display = "none";
                nightschange6.style.display = "block";
                nightschange7.style.display = "none";
                nightschange8.style.display = "none";
                nightschange9.style.display = "none";
                nightschange10.style.display = "none";
                nightschange11.style.display = "none";
                nightschange12.style.display = "none";
                nightschange13.style.display = "none";
                nightschange14.style.display = "none";
                nightschange15.style.display = "none";
                nightschange16.style.display = "none";
                nightschange17.style.display = "none";
                nightschange18.style.display = "none";
                nightschange19.style.display = "none";
                nightschange20.style.display = "none";
                nightschange21.style.display = "none";
                nightschange22.style.display = "none";
                nightschange23.style.display = "none";
                nightschange24.style.display = "none";
                nightschange25.style.display = "none";
                nightschange26.style.display = "none";
                nightschange27.style.display = "none";
                nightschange28.style.display = "none";
                nightschange29.style.display = "none";
                nightschange30.style.display = "none";
            }
            else if (mouseX == 280) {
                test1.style.display = "none";
                test2.style.display = "none";
                test3.style.display = "none";
                test4.style.display = "none";
                test5.style.display = "none";
                test6.style.display = "none";
                test7.style.display = "block";
                test8.style.display = "none";
                test9.style.display = "none";
                test10.style.display = "none";
                test11.style.display = "none";
                test12.style.display = "none";
                test13.style.display = "none";
                test14.style.display = "none";
                test15.style.display = "none";
                test16.style.display = "none";
                test17.style.display = "none";
                test18.style.display = "none";
                test19.style.display = "none";
                test20.style.display = "none";
                test21.style.display = "none";
                test22.style.display = "none";
                test23.style.display = "none";
                test24.style.display = "none";
                test25.style.display = "none";
                test26.style.display = "none";
                test27.style.display = "none";
                test28.style.display = "none";
                test29.style.display = "none";
                test30.style.display = "none";
                nightschange1.style.display = "none";
                nightschange2.style.display = "none";
                nightschange3.style.display = "none";
                nightschange4.style.display = "none";
                nightschange5.style.display = "none";
                nightschange6.style.display = "none";
                nightschange7.style.display = "block";
                nightschange8.style.display = "none";
                nightschange9.style.display = "none";
                nightschange10.style.display = "none";
                nightschange11.style.display = "none";
                nightschange12.style.display = "none";
                nightschange13.style.display = "none";
                nightschange14.style.display = "none";
                nightschange15.style.display = "none";
                nightschange16.style.display = "none";
                nightschange17.style.display = "none";
                nightschange18.style.display = "none";
                nightschange19.style.display = "none";
                nightschange20.style.display = "none";
                nightschange21.style.display = "none";
                nightschange22.style.display = "none";
                nightschange23.style.display = "none";
                nightschange24.style.display = "none";
                nightschange25.style.display = "none";
                nightschange26.style.display = "none";
                nightschange27.style.display = "none";
                nightschange28.style.display = "none";
                nightschange29.style.display = "none";
                nightschange30.style.display = "none";
            }
            else if (mouseX == 320) {
                test1.style.display = "none";
                test2.style.display = "none";
                test3.style.display = "none";
                test4.style.display = "none";
                test5.style.display = "none";
                test6.style.display = "none";
                test7.style.display = "none";
                test8.style.display = "block";
                test9.style.display = "none";
                test10.style.display = "none";
                test11.style.display = "none";
                test12.style.display = "none";
                test13.style.display = "none";
                test14.style.display = "none";
                test15.style.display = "none";
                test16.style.display = "none";
                test17.style.display = "none";
                test18.style.display = "none";
                test19.style.display = "none";
                test20.style.display = "none";
                test21.style.display = "none";
                test22.style.display = "none";
                test23.style.display = "none";
                test24.style.display = "none";
                test25.style.display = "none";
                test26.style.display = "none";
                test27.style.display = "none";
                test28.style.display = "none";
                test29.style.display = "none";
                test30.style.display = "none";
                nightschange1.style.display = "none";
                nightschange2.style.display = "none";
                nightschange3.style.display = "none";
                nightschange4.style.display = "none";
                nightschange5.style.display = "none";
                nightschange6.style.display = "none";
                nightschange7.style.display = "none";
                nightschange8.style.display = "block";
                nightschange9.style.display = "none";
                nightschange10.style.display = "none";
                nightschange11.style.display = "none";
                nightschange12.style.display = "none";
                nightschange13.style.display = "none";
                nightschange14.style.display = "none";
                nightschange15.style.display = "none";
                nightschange16.style.display = "none";
                nightschange17.style.display = "none";
                nightschange18.style.display = "none";
                nightschange19.style.display = "none";
                nightschange20.style.display = "none";
                nightschange21.style.display = "none";
                nightschange22.style.display = "none";
                nightschange23.style.display = "none";
                nightschange24.style.display = "none";
                nightschange25.style.display = "none";
                nightschange26.style.display = "none";
                nightschange27.style.display = "none";
                nightschange28.style.display = "none";
                nightschange29.style.display = "none";
                nightschange30.style.display = "none";
            }
            else if (mouseX == 360) {
                test1.style.display = "none";
                test2.style.display = "none";
                test3.style.display = "none";
                test4.style.display = "none";
                test5.style.display = "none";
                test6.style.display = "none";
                test7.style.display = "none";
                test8.style.display = "none";
                test9.style.display = "block";
                test10.style.display = "none";
                test11.style.display = "none";
                test12.style.display = "none";
                test13.style.display = "none";
                test14.style.display = "none";
                test15.style.display = "none";
                test16.style.display = "none";
                test17.style.display = "none";
                test18.style.display = "none";
                test19.style.display = "none";
                test20.style.display = "none";
                test21.style.display = "none";
                test22.style.display = "none";
                test23.style.display = "none";
                test24.style.display = "none";
                test25.style.display = "none";
                test26.style.display = "none";
                test27.style.display = "none";
                test28.style.display = "none";
                test29.style.display = "none";
                test30.style.display = "none";
                nightschange1.style.display = "none";
                nightschange2.style.display = "none";
                nightschange3.style.display = "none";
                nightschange4.style.display = "none";
                nightschange5.style.display = "none";
                nightschange6.style.display = "none";
                nightschange7.style.display = "none";
                nightschange8.style.display = "none";
                nightschange9.style.display = "block";
                nightschange10.style.display = "none";
                nightschange11.style.display = "none";
                nightschange12.style.display = "none";
                nightschange13.style.display = "none";
                nightschange14.style.display = "none";
                nightschange15.style.display = "none";
                nightschange16.style.display = "none";
                nightschange17.style.display = "none";
                nightschange18.style.display = "none";
                nightschange19.style.display = "none";
                nightschange20.style.display = "none";
                nightschange21.style.display = "none";
                nightschange22.style.display = "none";
                nightschange23.style.display = "none";
                nightschange24.style.display = "none";
                nightschange25.style.display = "none";
                nightschange26.style.display = "none";
                nightschange27.style.display = "none";
                nightschange28.style.display = "none";
                nightschange29.style.display = "none";
                nightschange30.style.display = "none";
            }
            else if (mouseX == 400) {
                test1.style.display = "none";
                test2.style.display = "none";
                test3.style.display = "none";
                test4.style.display = "none";
                test5.style.display = "none";
                test6.style.display = "none";
                test7.style.display = "none";
                test8.style.display = "none";
                test9.style.display = "none";
                test10.style.display = "block";
                test11.style.display = "none";
                test12.style.display = "none";
                test13.style.display = "none";
                test14.style.display = "none";
                test15.style.display = "none";
                test16.style.display = "none";
                test17.style.display = "none";
                test18.style.display = "none";
                test19.style.display = "none";
                test20.style.display = "none";
                test21.style.display = "none";
                test22.style.display = "none";
                test23.style.display = "none";
                test24.style.display = "none";
                test25.style.display = "none";
                test26.style.display = "none";
                test27.style.display = "none";
                test28.style.display = "none";
                test29.style.display = "none";
                test30.style.display = "none";
                nightschange1.style.display = "none";
                nightschange2.style.display = "none";
                nightschange3.style.display = "none";
                nightschange4.style.display = "none";
                nightschange5.style.display = "none";
                nightschange6.style.display = "none";
                nightschange7.style.display = "none";
                nightschange8.style.display = "none";
                nightschange9.style.display = "none";
                nightschange10.style.display = "block";
                nightschange11.style.display = "none";
                nightschange12.style.display = "none";
                nightschange13.style.display = "none";
                nightschange14.style.display = "none";
                nightschange15.style.display = "none";
                nightschange16.style.display = "none";
                nightschange17.style.display = "none";
                nightschange18.style.display = "none";
                nightschange19.style.display = "none";
                nightschange20.style.display = "none";
                nightschange21.style.display = "none";
                nightschange22.style.display = "none";
                nightschange23.style.display = "none";
                nightschange24.style.display = "none";
                nightschange25.style.display = "none";
                nightschange26.style.display = "none";
                nightschange27.style.display = "none";
                nightschange28.style.display = "none";
                nightschange29.style.display = "none";
                nightschange30.style.display = "none";
            }
            else if (mouseX == 440) {
                test1.style.display = "none";
                test2.style.display = "none";
                test3.style.display = "none";
                test4.style.display = "none";
                test5.style.display = "none";
                test6.style.display = "none";
                test7.style.display = "none";
                test8.style.display = "none";
                test9.style.display = "none";
                test10.style.display = "none";
                test11.style.display = "block";
                test12.style.display = "none";
                test13.style.display = "none";
                test14.style.display = "none";
                test15.style.display = "none";
                test16.style.display = "none";
                test17.style.display = "none";
                test18.style.display = "none";
                test19.style.display = "none";
                test20.style.display = "none";
                test21.style.display = "none";
                test22.style.display = "none";
                test23.style.display = "none";
                test24.style.display = "none";
                test25.style.display = "none";
                test26.style.display = "none";
                test27.style.display = "none";
                test28.style.display = "none";
                test29.style.display = "none";
                test30.style.display = "none";
                nightschange1.style.display = "none";
                nightschange2.style.display = "none";
                nightschange3.style.display = "none";
                nightschange4.style.display = "none";
                nightschange5.style.display = "none";
                nightschange6.style.display = "none";
                nightschange7.style.display = "none";
                nightschange8.style.display = "none";
                nightschange9.style.display = "none";
                nightschange10.style.display = "none";
                nightschange11.style.display = "block";
                nightschange12.style.display = "none";
                nightschange13.style.display = "none";
                nightschange14.style.display = "none";
                nightschange15.style.display = "none";
                nightschange16.style.display = "none";
                nightschange17.style.display = "none";
                nightschange18.style.display = "none";
                nightschange19.style.display = "none";
                nightschange20.style.display = "none";
                nightschange21.style.display = "none";
                nightschange22.style.display = "none";
                nightschange23.style.display = "none";
                nightschange24.style.display = "none";
                nightschange25.style.display = "none";
                nightschange26.style.display = "none";
                nightschange27.style.display = "none";
                nightschange28.style.display = "none";
                nightschange29.style.display = "none";
                nightschange30.style.display = "none";
            }
            else if (mouseX == 480) {
                test1.style.display = "none";
                test2.style.display = "none";
                test3.style.display = "none";
                test4.style.display = "none";
                test5.style.display = "none";
                test6.style.display = "none";
                test7.style.display = "none";
                test8.style.display = "none";
                test9.style.display = "none";
                test10.style.display = "none";
                test11.style.display = "none";
                test12.style.display = "block";
                test13.style.display = "none";
                test14.style.display = "none";
                test15.style.display = "none";
                test16.style.display = "none";
                test17.style.display = "none";
                test18.style.display = "none";
                test19.style.display = "none";
                test20.style.display = "none";
                test21.style.display = "none";
                test22.style.display = "none";
                test23.style.display = "none";
                test24.style.display = "none";
                test25.style.display = "none";
                test26.style.display = "none";
                test27.style.display = "none";
                test28.style.display = "none";
                test29.style.display = "none";
                test30.style.display = "none";
                nightschange1.style.display = "none";
                nightschange2.style.display = "none";
                nightschange3.style.display = "none";
                nightschange4.style.display = "none";
                nightschange5.style.display = "none";
                nightschange6.style.display = "none";
                nightschange7.style.display = "none";
                nightschange8.style.display = "none";
                nightschange9.style.display = "none";
                nightschange10.style.display = "none";
                nightschange11.style.display = "none";
                nightschange12.style.display = "block";
                nightschange13.style.display = "none";
                nightschange14.style.display = "none";
                nightschange15.style.display = "none";
                nightschange16.style.display = "none";
                nightschange17.style.display = "none";
                nightschange18.style.display = "none";
                nightschange19.style.display = "none";
                nightschange20.style.display = "none";
                nightschange21.style.display = "none";
                nightschange22.style.display = "none";
                nightschange23.style.display = "none";
                nightschange24.style.display = "none";
                nightschange25.style.display = "none";
                nightschange26.style.display = "none";
                nightschange27.style.display = "none";
                nightschange28.style.display = "none";
                nightschange29.style.display = "none";
                nightschange30.style.display = "none";
            }
            else if (mouseX == 520) {
                test1.style.display = "none";
                test2.style.display = "none";
                test3.style.display = "none";
                test4.style.display = "none";
                test5.style.display = "none";
                test6.style.display = "none";
                test7.style.display = "none";
                test8.style.display = "none";
                test9.style.display = "none";
                test10.style.display = "none";
                test11.style.display = "none";
                test12.style.display = "none";
                test13.style.display = "block";
                test14.style.display = "none";
                test15.style.display = "none";
                test16.style.display = "none";
                test17.style.display = "none";
                test18.style.display = "none";
                test19.style.display = "none";
                test20.style.display = "none";
                test21.style.display = "none";
                test22.style.display = "none";
                test23.style.display = "none";
                test24.style.display = "none";
                test25.style.display = "none";
                test26.style.display = "none";
                test27.style.display = "none";
                test28.style.display = "none";
                test29.style.display = "none";
                test30.style.display = "none";
                nightschange1.style.display = "none";
                nightschange2.style.display = "none";
                nightschange3.style.display = "none";
                nightschange4.style.display = "none";
                nightschange5.style.display = "none";
                nightschange6.style.display = "none";
                nightschange7.style.display = "none";
                nightschange8.style.display = "none";
                nightschange9.style.display = "none";
                nightschange10.style.display = "none";
                nightschange11.style.display = "none";
                nightschange12.style.display = "none";
                nightschange13.style.display = "block";
                nightschange14.style.display = "none";
                nightschange15.style.display = "none";
                nightschange16.style.display = "none";
                nightschange17.style.display = "none";
                nightschange18.style.display = "none";
                nightschange19.style.display = "none";
                nightschange20.style.display = "none";
                nightschange21.style.display = "none";
                nightschange22.style.display = "none";
                nightschange23.style.display = "none";
                nightschange24.style.display = "none";
                nightschange25.style.display = "none";
                nightschange26.style.display = "none";
                nightschange27.style.display = "none";
                nightschange28.style.display = "none";
                nightschange29.style.display = "none";
                nightschange30.style.display = "none";
            }
            else if (mouseX == 560) {
                test1.style.display = "none";
                test2.style.display = "none";
                test3.style.display = "none";
                test4.style.display = "none";
                test5.style.display = "none";
                test6.style.display = "none";
                test7.style.display = "none";
                test8.style.display = "none";
                test9.style.display = "none";
                test10.style.display = "none";
                test11.style.display = "none";
                test12.style.display = "none";
                test13.style.display = "none";
                test14.style.display = "block";
                test15.style.display = "none";
                test16.style.display = "none";
                test17.style.display = "none";
                test18.style.display = "none";
                test19.style.display = "none";
                test20.style.display = "none";
                test21.style.display = "none";
                test22.style.display = "none";
                test23.style.display = "none";
                test24.style.display = "none";
                test25.style.display = "none";
                test26.style.display = "none";
                test27.style.display = "none";
                test28.style.display = "none";
                test29.style.display = "none";
                test30.style.display = "none";
                nightschange1.style.display = "none";
                nightschange2.style.display = "none";
                nightschange3.style.display = "none";
                nightschange4.style.display = "none";
                nightschange5.style.display = "none";
                nightschange6.style.display = "none";
                nightschange7.style.display = "none";
                nightschange8.style.display = "none";
                nightschange9.style.display = "none";
                nightschange10.style.display = "none";
                nightschange11.style.display = "none";
                nightschange12.style.display = "none";
                nightschange13.style.display = "none";
                nightschange14.style.display = "block";
                nightschange15.style.display = "none";
                nightschange16.style.display = "none";
                nightschange17.style.display = "none";
                nightschange18.style.display = "none";
                nightschange19.style.display = "none";
                nightschange20.style.display = "none";
                nightschange21.style.display = "none";
                nightschange22.style.display = "none";
                nightschange23.style.display = "none";
                nightschange24.style.display = "none";
                nightschange25.style.display = "none";
                nightschange26.style.display = "none";
                nightschange27.style.display = "none";
                nightschange28.style.display = "none";
                nightschange29.style.display = "none";
                nightschange30.style.display = "none";
            }
            else if (mouseX == 600) {
                test1.style.display = "none";
                test2.style.display = "none";
                test3.style.display = "none";
                test4.style.display = "none";
                test5.style.display = "none";
                test6.style.display = "none";
                test7.style.display = "none";
                test8.style.display = "none";
                test9.style.display = "none";
                test10.style.display = "none";
                test11.style.display = "none";
                test12.style.display = "none";
                test13.style.display = "none";
                test14.style.display = "none";
                test15.style.display = "block";
                test16.style.display = "none";
                test17.style.display = "none";
                test18.style.display = "none";
                test19.style.display = "none";
                test20.style.display = "none";
                test21.style.display = "none";
                test22.style.display = "none";
                test23.style.display = "none";
                test24.style.display = "none";
                test25.style.display = "none";
                test26.style.display = "none";
                test27.style.display = "none";
                test28.style.display = "none";
                test29.style.display = "none";
                test30.style.display = "none";
                nightschange1.style.display = "none";
                nightschange2.style.display = "none";
                nightschange3.style.display = "none";
                nightschange4.style.display = "none";
                nightschange5.style.display = "none";
                nightschange6.style.display = "none";
                nightschange7.style.display = "none";
                nightschange8.style.display = "none";
                nightschange9.style.display = "none";
                nightschange10.style.display = "none";
                nightschange11.style.display = "none";
                nightschange12.style.display = "none";
                nightschange13.style.display = "none";
                nightschange14.style.display = "none";
                nightschange15.style.display = "block";
                nightschange16.style.display = "none";
                nightschange17.style.display = "none";
                nightschange18.style.display = "none";
                nightschange19.style.display = "none";
                nightschange20.style.display = "none";
                nightschange21.style.display = "none";
                nightschange22.style.display = "none";
                nightschange23.style.display = "none";
                nightschange24.style.display = "none";
                nightschange25.style.display = "none";
                nightschange26.style.display = "none";
                nightschange27.style.display = "none";
                nightschange28.style.display = "none";
                nightschange29.style.display = "none";
                nightschange30.style.display = "none";
            }
            else if (mouseX == 640) {
                test1.style.display = "none";
                test2.style.display = "none";
                test3.style.display = "none";
                test4.style.display = "none";
                test5.style.display = "none";
                test6.style.display = "none";
                test7.style.display = "none";
                test8.style.display = "none";
                test9.style.display = "none";
                test10.style.display = "none";
                test11.style.display = "none";
                test12.style.display = "none";
                test13.style.display = "none";
                test14.style.display = "none";
                test15.style.display = "none";
                test16.style.display = "block";
                test17.style.display = "none";
                test18.style.display = "none";
                test19.style.display = "none";
                test20.style.display = "none";
                test21.style.display = "none";
                test22.style.display = "none";
                test23.style.display = "none";
                test24.style.display = "none";
                test25.style.display = "none";
                test26.style.display = "none";
                test27.style.display = "none";
                test28.style.display = "none";
                test29.style.display = "none";
                test30.style.display = "none";
                nightschange1.style.display = "none";
                nightschange2.style.display = "none";
                nightschange3.style.display = "none";
                nightschange4.style.display = "none";
                nightschange5.style.display = "none";
                nightschange6.style.display = "none";
                nightschange7.style.display = "none";
                nightschange8.style.display = "none";
                nightschange9.style.display = "none";
                nightschange10.style.display = "none";
                nightschange11.style.display = "none";
                nightschange12.style.display = "none";
                nightschange13.style.display = "none";
                nightschange14.style.display = "none";
                nightschange15.style.display = "none";
                nightschange16.style.display = "block";
                nightschange17.style.display = "none";
                nightschange18.style.display = "none";
                nightschange19.style.display = "none";
                nightschange20.style.display = "none";
                nightschange21.style.display = "none";
                nightschange22.style.display = "none";
                nightschange23.style.display = "none";
                nightschange24.style.display = "none";
                nightschange25.style.display = "none";
                nightschange26.style.display = "none";
                nightschange27.style.display = "none";
                nightschange28.style.display = "none";
                nightschange29.style.display = "none";
                nightschange30.style.display = "none";
            }
            else if (mouseX == 680) {
                test1.style.display = "none";
                test2.style.display = "none";
                test3.style.display = "none";
                test4.style.display = "none";
                test5.style.display = "none";
                test6.style.display = "none";
                test7.style.display = "none";
                test8.style.display = "none";
                test9.style.display = "none";
                test10.style.display = "none";
                test11.style.display = "none";
                test12.style.display = "none";
                test13.style.display = "none";
                test14.style.display = "none";
                test15.style.display = "none";
                test16.style.display = "none";
                test17.style.display = "block";
                test18.style.display = "none";
                test19.style.display = "none";
                test20.style.display = "none";
                test21.style.display = "none";
                test22.style.display = "none";
                test23.style.display = "none";
                test24.style.display = "none";
                test25.style.display = "none";
                test26.style.display = "none";
                test27.style.display = "none";
                test28.style.display = "none";
                test29.style.display = "none";
                test30.style.display = "none";
                nightschange1.style.display = "none";
                nightschange2.style.display = "none";
                nightschange3.style.display = "none";
                nightschange4.style.display = "none";
                nightschange5.style.display = "none";
                nightschange6.style.display = "none";
                nightschange7.style.display = "none";
                nightschange8.style.display = "none";
                nightschange9.style.display = "none";
                nightschange10.style.display = "none";
                nightschange11.style.display = "none";
                nightschange12.style.display = "none";
                nightschange13.style.display = "none";
                nightschange14.style.display = "none";
                nightschange15.style.display = "none";
                nightschange16.style.display = "none";
                nightschange17.style.display = "block";
                nightschange18.style.display = "none";
                nightschange19.style.display = "none";
                nightschange20.style.display = "none";
                nightschange21.style.display = "none";
                nightschange22.style.display = "none";
                nightschange23.style.display = "none";
                nightschange24.style.display = "none";
                nightschange25.style.display = "none";
                nightschange26.style.display = "none";
                nightschange27.style.display = "none";
                nightschange28.style.display = "none";
                nightschange29.style.display = "none";
                nightschange30.style.display = "none";
            }
            else if (mouseX == 720) {
                test1.style.display = "none";
                test2.style.display = "none";
                test3.style.display = "none";
                test4.style.display = "none";
                test5.style.display = "none";
                test6.style.display = "none";
                test7.style.display = "none";
                test8.style.display = "none";
                test9.style.display = "none";
                test10.style.display = "none";
                test11.style.display = "none";
                test12.style.display = "none";
                test13.style.display = "none";
                test14.style.display = "none";
                test15.style.display = "none";
                test16.style.display = "none";
                test17.style.display = "none";
                test18.style.display = "block";
                test19.style.display = "none";
                test20.style.display = "none";
                test21.style.display = "none";
                test22.style.display = "none";
                test23.style.display = "none";
                test24.style.display = "none";
                test25.style.display = "none";
                test26.style.display = "none";
                test27.style.display = "none";
                test28.style.display = "none";
                test29.style.display = "none";
                test30.style.display = "none";
                nightschange1.style.display = "none";
                nightschange2.style.display = "none";
                nightschange3.style.display = "none";
                nightschange4.style.display = "none";
                nightschange5.style.display = "none";
                nightschange6.style.display = "none";
                nightschange7.style.display = "none";
                nightschange8.style.display = "none";
                nightschange9.style.display = "none";
                nightschange10.style.display = "none";
                nightschange11.style.display = "none";
                nightschange12.style.display = "none";
                nightschange13.style.display = "none";
                nightschange14.style.display = "none";
                nightschange15.style.display = "none";
                nightschange16.style.display = "none";
                nightschange17.style.display = "none";
                nightschange18.style.display = "block";
                nightschange19.style.display = "none";
                nightschange20.style.display = "none";
                nightschange21.style.display = "none";
                nightschange22.style.display = "none";
                nightschange23.style.display = "none";
                nightschange24.style.display = "none";
                nightschange25.style.display = "none";
                nightschange26.style.display = "none";
                nightschange27.style.display = "none";
                nightschange28.style.display = "none";
                nightschange29.style.display = "none";
                nightschange30.style.display = "none";
            }
            else if (mouseX == 760) {
                test1.style.display = "none";
                test2.style.display = "none";
                test3.style.display = "none";
                test4.style.display = "none";
                test5.style.display = "none";
                test6.style.display = "none";
                test7.style.display = "none";
                test8.style.display = "none";
                test9.style.display = "none";
                test10.style.display = "none";
                test11.style.display = "none";
                test12.style.display = "none";
                test13.style.display = "none";
                test14.style.display = "none";
                test15.style.display = "none";
                test16.style.display = "none";
                test17.style.display = "none";
                test18.style.display = "none";
                test19.style.display = "block";
                test20.style.display = "none";
                test21.style.display = "none";
                test22.style.display = "none";
                test23.style.display = "none";
                test24.style.display = "none";
                test25.style.display = "none";
                test26.style.display = "none";
                test27.style.display = "none";
                test28.style.display = "none";
                test29.style.display = "none";
                test30.style.display = "none";
                nightschange1.style.display = "none";
                nightschange2.style.display = "none";
                nightschange3.style.display = "none";
                nightschange4.style.display = "none";
                nightschange5.style.display = "none";
                nightschange6.style.display = "none";
                nightschange7.style.display = "none";
                nightschange8.style.display = "none";
                nightschange9.style.display = "none";
                nightschange10.style.display = "none";
                nightschange11.style.display = "none";
                nightschange12.style.display = "none";
                nightschange13.style.display = "none";
                nightschange14.style.display = "none";
                nightschange15.style.display = "none";
                nightschange16.style.display = "none";
                nightschange17.style.display = "none";
                nightschange18.style.display = "none";
                nightschange19.style.display = "block";
                nightschange20.style.display = "none";
                nightschange21.style.display = "none";
                nightschange22.style.display = "none";
                nightschange23.style.display = "none";
                nightschange24.style.display = "none";
                nightschange25.style.display = "none";
                nightschange26.style.display = "none";
                nightschange27.style.display = "none";
                nightschange28.style.display = "none";
                nightschange29.style.display = "none";
                nightschange30.style.display = "none";
            }
            else if (mouseX == 800) {
                test1.style.display = "none";
                test2.style.display = "none";
                test3.style.display = "none";
                test4.style.display = "none";
                test5.style.display = "none";
                test6.style.display = "none";
                test7.style.display = "none";
                test8.style.display = "none";
                test9.style.display = "none";
                test10.style.display = "none";
                test11.style.display = "none";
                test12.style.display = "none";
                test13.style.display = "none";
                test14.style.display = "none";
                test15.style.display = "none";
                test16.style.display = "none";
                test17.style.display = "none";
                test18.style.display = "none";
                test19.style.display = "none";
                test20.style.display = "block";
                test21.style.display = "none";
                test22.style.display = "none";
                test23.style.display = "none";
                test24.style.display = "none";
                test25.style.display = "none";
                test26.style.display = "none";
                test27.style.display = "none";
                test28.style.display = "none";
                test29.style.display = "none";
                test30.style.display = "none";
                nightschange1.style.display = "none";
                nightschange2.style.display = "none";
                nightschange3.style.display = "none";
                nightschange4.style.display = "none";
                nightschange5.style.display = "none";
                nightschange6.style.display = "none";
                nightschange7.style.display = "none";
                nightschange8.style.display = "none";
                nightschange9.style.display = "none";
                nightschange10.style.display = "none";
                nightschange11.style.display = "none";
                nightschange12.style.display = "none";
                nightschange13.style.display = "none";
                nightschange14.style.display = "none";
                nightschange15.style.display = "none";
                nightschange16.style.display = "none";
                nightschange17.style.display = "none";
                nightschange18.style.display = "none";
                nightschange19.style.display = "none";
                nightschange20.style.display = "block";
                nightschange21.style.display = "none";
                nightschange22.style.display = "none";
                nightschange23.style.display = "none";
                nightschange24.style.display = "none";
                nightschange25.style.display = "none";
                nightschange26.style.display = "none";
                nightschange27.style.display = "none";
                nightschange28.style.display = "none";
                nightschange29.style.display = "none";
                nightschange30.style.display = "none";
            }
            else if (mouseX == 840) {
                test1.style.display = "none";
                test2.style.display = "none";
                test3.style.display = "none";
                test4.style.display = "none";
                test5.style.display = "none";
                test6.style.display = "none";
                test7.style.display = "none";
                test8.style.display = "none";
                test9.style.display = "none";
                test10.style.display = "none";
                test11.style.display = "none";
                test12.style.display = "none";
                test13.style.display = "none";
                test14.style.display = "none";
                test15.style.display = "none";
                test16.style.display = "none";
                test17.style.display = "none";
                test18.style.display = "none";
                test19.style.display = "none";
                test20.style.display = "none";
                test21.style.display = "block";
                test22.style.display = "none";
                test23.style.display = "none";
                test24.style.display = "none";
                test25.style.display = "none";
                test26.style.display = "none";
                test27.style.display = "none";
                test28.style.display = "none";
                test29.style.display = "none";
                test30.style.display = "none";
                nightschange1.style.display = "none";
                nightschange2.style.display = "none";
                nightschange3.style.display = "none";
                nightschange4.style.display = "none";
                nightschange5.style.display = "none";
                nightschange6.style.display = "none";
                nightschange7.style.display = "none";
                nightschange8.style.display = "none";
                nightschange9.style.display = "none";
                nightschange10.style.display = "none";
                nightschange11.style.display = "none";
                nightschange12.style.display = "none";
                nightschange13.style.display = "none";
                nightschange14.style.display = "none";
                nightschange15.style.display = "none";
                nightschange16.style.display = "none";
                nightschange17.style.display = "none";
                nightschange18.style.display = "none";
                nightschange19.style.display = "none";
                nightschange20.style.display = "none";
                nightschange21.style.display = "block";
                nightschange22.style.display = "none";
                nightschange23.style.display = "none";
                nightschange24.style.display = "none";
                nightschange25.style.display = "none";
                nightschange26.style.display = "none";
                nightschange27.style.display = "none";
                nightschange28.style.display = "none";
                nightschange29.style.display = "none";
                nightschange30.style.display = "none";
            }
            else if (mouseX == 880) {
                test1.style.display = "none";
                test2.style.display = "none";
                test3.style.display = "none";
                test4.style.display = "none";
                test5.style.display = "none";
                test6.style.display = "none";
                test7.style.display = "none";
                test8.style.display = "none";
                test9.style.display = "none";
                test10.style.display = "none";
                test11.style.display = "none";
                test12.style.display = "none";
                test13.style.display = "none";
                test14.style.display = "none";
                test15.style.display = "none";
                test16.style.display = "none";
                test17.style.display = "none";
                test18.style.display = "none";
                test19.style.display = "none";
                test20.style.display = "none";
                test21.style.display = "none";
                test22.style.display = "block";
                test23.style.display = "none";
                test24.style.display = "none";
                test25.style.display = "none";
                test26.style.display = "none";
                test27.style.display = "none";
                test28.style.display = "none";
                test29.style.display = "none";
                test30.style.display = "none";
                nightschange1.style.display = "none";
                nightschange2.style.display = "none";
                nightschange3.style.display = "none";
                nightschange4.style.display = "none";
                nightschange5.style.display = "none";
                nightschange6.style.display = "none";
                nightschange7.style.display = "none";
                nightschange8.style.display = "none";
                nightschange9.style.display = "none";
                nightschange10.style.display = "none";
                nightschange11.style.display = "none";
                nightschange12.style.display = "none";
                nightschange13.style.display = "none";
                nightschange14.style.display = "none";
                nightschange15.style.display = "none";
                nightschange16.style.display = "none";
                nightschange17.style.display = "none";
                nightschange18.style.display = "none";
                nightschange19.style.display = "none";
                nightschange20.style.display = "none";
                nightschange21.style.display = "none";
                nightschange22.style.display = "block";
                nightschange23.style.display = "none";
                nightschange24.style.display = "none";
                nightschange25.style.display = "none";
                nightschange26.style.display = "none";
                nightschange27.style.display = "none";
                nightschange28.style.display = "none";
                nightschange29.style.display = "none";
                nightschange30.style.display = "none";
            }
            else if (mouseX == 920) {
                test1.style.display = "none";
                test2.style.display = "none";
                test3.style.display = "none";
                test4.style.display = "none";
                test5.style.display = "none";
                test6.style.display = "none";
                test7.style.display = "none";
                test8.style.display = "none";
                test9.style.display = "none";
                test10.style.display = "none";
                test11.style.display = "none";
                test12.style.display = "none";
                test13.style.display = "none";
                test14.style.display = "none";
                test15.style.display = "none";
                test16.style.display = "none";
                test17.style.display = "none";
                test18.style.display = "none";
                test19.style.display = "none";
                test20.style.display = "none";
                test21.style.display = "none";
                test22.style.display = "none";
                test23.style.display = "block";
                test24.style.display = "none";
                test25.style.display = "none";
                test26.style.display = "none";
                test27.style.display = "none";
                test28.style.display = "none";
                test29.style.display = "none";
                test30.style.display = "none";
                nightschange1.style.display = "none";
                nightschange2.style.display = "none";
                nightschange3.style.display = "none";
                nightschange4.style.display = "none";
                nightschange5.style.display = "none";
                nightschange6.style.display = "none";
                nightschange7.style.display = "none";
                nightschange8.style.display = "none";
                nightschange9.style.display = "none";
                nightschange10.style.display = "none";
                nightschange11.style.display = "none";
                nightschange12.style.display = "none";
                nightschange13.style.display = "none";
                nightschange14.style.display = "none";
                nightschange15.style.display = "none";
                nightschange16.style.display = "none";
                nightschange17.style.display = "none";
                nightschange18.style.display = "none";
                nightschange19.style.display = "none";
                nightschange20.style.display = "none";
                nightschange21.style.display = "none";
                nightschange22.style.display = "none";
                nightschange23.style.display = "block";
                nightschange24.style.display = "none";
                nightschange25.style.display = "none";
                nightschange26.style.display = "none";
                nightschange27.style.display = "none";
                nightschange28.style.display = "none";
                nightschange29.style.display = "none";
                nightschange30.style.display = "none";
            }
            else if (mouseX == 960) {
                test1.style.display = "none";
                test2.style.display = "none";
                test3.style.display = "none";
                test4.style.display = "none";
                test5.style.display = "none";
                test6.style.display = "none";
                test7.style.display = "none";
                test8.style.display = "none";
                test9.style.display = "none";
                test10.style.display = "none";
                test11.style.display = "none";
                test12.style.display = "none";
                test13.style.display = "none";
                test14.style.display = "none";
                test15.style.display = "none";
                test16.style.display = "none";
                test17.style.display = "none";
                test18.style.display = "none";
                test19.style.display = "none";
                test20.style.display = "none";
                test21.style.display = "none";
                test22.style.display = "none";
                test23.style.display = "none";
                test24.style.display = "block";
                test25.style.display = "none";
                test26.style.display = "none";
                test27.style.display = "none";
                test28.style.display = "none";
                test29.style.display = "none";
                test30.style.display = "none";
                nightschange1.style.display = "none";
                nightschange2.style.display = "none";
                nightschange3.style.display = "none";
                nightschange4.style.display = "none";
                nightschange5.style.display = "none";
                nightschange6.style.display = "none";
                nightschange7.style.display = "none";
                nightschange8.style.display = "none";
                nightschange9.style.display = "none";
                nightschange10.style.display = "none";
                nightschange11.style.display = "none";
                nightschange12.style.display = "none";
                nightschange13.style.display = "none";
                nightschange14.style.display = "none";
                nightschange15.style.display = "none";
                nightschange16.style.display = "none";
                nightschange17.style.display = "none";
                nightschange18.style.display = "none";
                nightschange19.style.display = "none";
                nightschange20.style.display = "none";
                nightschange21.style.display = "none";
                nightschange22.style.display = "none";
                nightschange23.style.display = "none";
                nightschange24.style.display = "block";
                nightschange25.style.display = "none";
                nightschange26.style.display = "none";
                nightschange27.style.display = "none";
                nightschange28.style.display = "none";
                nightschange29.style.display = "none";
                nightschange30.style.display = "none";
            }
            else if (mouseX == 1000) {
                test1.style.display = "none";
                test2.style.display = "none";
                test3.style.display = "none";
                test4.style.display = "none";
                test5.style.display = "none";
                test6.style.display = "none";
                test7.style.display = "none";
                test8.style.display = "none";
                test9.style.display = "none";
                test10.style.display = "none";
                test11.style.display = "none";
                test12.style.display = "none";
                test13.style.display = "none";
                test14.style.display = "none";
                test15.style.display = "none";
                test16.style.display = "none";
                test17.style.display = "none";
                test18.style.display = "none";
                test19.style.display = "none";
                test20.style.display = "none";
                test21.style.display = "none";
                test22.style.display = "none";
                test23.style.display = "none";
                test24.style.display = "none";
                test25.style.display = "block";
                test26.style.display = "none";
                test27.style.display = "none";
                test28.style.display = "none";
                test29.style.display = "none";
                test30.style.display = "none";
                nightschange1.style.display = "none";
                nightschange2.style.display = "none";
                nightschange3.style.display = "none";
                nightschange4.style.display = "none";
                nightschange5.style.display = "none";
                nightschange6.style.display = "none";
                nightschange7.style.display = "none";
                nightschange8.style.display = "none";
                nightschange9.style.display = "none";
                nightschange10.style.display = "none";
                nightschange11.style.display = "none";
                nightschange12.style.display = "none";
                nightschange13.style.display = "none";
                nightschange14.style.display = "none";
                nightschange15.style.display = "none";
                nightschange16.style.display = "none";
                nightschange17.style.display = "none";
                nightschange18.style.display = "none";
                nightschange19.style.display = "none";
                nightschange20.style.display = "none";
                nightschange21.style.display = "none";
                nightschange22.style.display = "none";
                nightschange23.style.display = "none";
                nightschange24.style.display = "none";
                nightschange25.style.display = "block";
                nightschange26.style.display = "none";
                nightschange27.style.display = "none";
                nightschange28.style.display = "none";
                nightschange29.style.display = "none";
                nightschange30.style.display = "none";
            }
            else if (mouseX == 1040) {
                test1.style.display = "none";
                test2.style.display = "none";
                test3.style.display = "none";
                test4.style.display = "none";
                test5.style.display = "none";
                test6.style.display = "none";
                test7.style.display = "none";
                test8.style.display = "none";
                test9.style.display = "none";
                test10.style.display = "none";
                test11.style.display = "none";
                test12.style.display = "none";
                test13.style.display = "none";
                test14.style.display = "none";
                test15.style.display = "none";
                test16.style.display = "none";
                test17.style.display = "none";
                test18.style.display = "none";
                test19.style.display = "none";
                test20.style.display = "none";
                test21.style.display = "none";
                test22.style.display = "none";
                test23.style.display = "none";
                test24.style.display = "none";
                test25.style.display = "none";
                test26.style.display = "block";
                test27.style.display = "none";
                test28.style.display = "none";
                test29.style.display = "none";
                test30.style.display = "none";
                nightschange1.style.display = "none";
                nightschange2.style.display = "none";
                nightschange3.style.display = "none";
                nightschange4.style.display = "none";
                nightschange5.style.display = "none";
                nightschange6.style.display = "none";
                nightschange7.style.display = "none";
                nightschange8.style.display = "none";
                nightschange9.style.display = "none";
                nightschange10.style.display = "none";
                nightschange11.style.display = "none";
                nightschange12.style.display = "none";
                nightschange13.style.display = "none";
                nightschange14.style.display = "none";
                nightschange15.style.display = "none";
                nightschange16.style.display = "none";
                nightschange17.style.display = "none";
                nightschange18.style.display = "none";
                nightschange19.style.display = "none";
                nightschange20.style.display = "none";
                nightschange21.style.display = "none";
                nightschange22.style.display = "none";
                nightschange23.style.display = "none";
                nightschange24.style.display = "none";
                nightschange25.style.display = "none";
                nightschange26.style.display = "block";
                nightschange27.style.display = "none";
                nightschange28.style.display = "none";
                nightschange29.style.display = "none";
                nightschange30.style.display = "none";
            }
            else if (mouseX == 1080) {
                test1.style.display = "none";
                test2.style.display = "none";
                test3.style.display = "none";
                test4.style.display = "none";
                test5.style.display = "none";
                test6.style.display = "none";
                test7.style.display = "none";
                test8.style.display = "none";
                test9.style.display = "none";
                test10.style.display = "none";
                test11.style.display = "none";
                test12.style.display = "none";
                test13.style.display = "none";
                test14.style.display = "none";
                test15.style.display = "none";
                test16.style.display = "none";
                test17.style.display = "none";
                test18.style.display = "none";
                test19.style.display = "none";
                test20.style.display = "none";
                test21.style.display = "none";
                test22.style.display = "none";
                test23.style.display = "none";
                test24.style.display = "none";
                test25.style.display = "none";
                test26.style.display = "none";
                test27.style.display = "block";
                test28.style.display = "none";
                test29.style.display = "none";
                test30.style.display = "none";
                nightschange1.style.display = "none";
                nightschange2.style.display = "none";
                nightschange3.style.display = "none";
                nightschange4.style.display = "none";
                nightschange5.style.display = "none";
                nightschange6.style.display = "none";
                nightschange7.style.display = "none";
                nightschange8.style.display = "none";
                nightschange9.style.display = "none";
                nightschange10.style.display = "none";
                nightschange11.style.display = "none";
                nightschange12.style.display = "none";
                nightschange13.style.display = "none";
                nightschange14.style.display = "none";
                nightschange15.style.display = "none";
                nightschange16.style.display = "none";
                nightschange17.style.display = "none";
                nightschange18.style.display = "none";
                nightschange19.style.display = "none";
                nightschange20.style.display = "none";
                nightschange21.style.display = "none";
                nightschange22.style.display = "none";
                nightschange23.style.display = "none";
                nightschange24.style.display = "none";
                nightschange25.style.display = "none";
                nightschange26.style.display = "none";
                nightschange27.style.display = "block";
                nightschange28.style.display = "none";
                nightschange29.style.display = "none";
                nightschange30.style.display = "none";
            }
            else if (mouseX == 1120) {
                test1.style.display = "none";
                test2.style.display = "none";
                test3.style.display = "none";
                test4.style.display = "none";
                test5.style.display = "none";
                test6.style.display = "none";
                test7.style.display = "none";
                test8.style.display = "none";
                test9.style.display = "none";
                test10.style.display = "none";
                test11.style.display = "none";
                test12.style.display = "none";
                test13.style.display = "none";
                test14.style.display = "none";
                test15.style.display = "none";
                test16.style.display = "none";
                test17.style.display = "none";
                test18.style.display = "none";
                test19.style.display = "none";
                test20.style.display = "none";
                test21.style.display = "none";
                test22.style.display = "none";
                test23.style.display = "none";
                test24.style.display = "none";
                test25.style.display = "none";
                test26.style.display = "none";
                test27.style.display = "none";
                test28.style.display = "block";
                test29.style.display = "none";
                test30.style.display = "none";
                nightschange1.style.display = "none";
                nightschange2.style.display = "none";
                nightschange3.style.display = "none";
                nightschange4.style.display = "none";
                nightschange5.style.display = "none";
                nightschange6.style.display = "none";
                nightschange7.style.display = "none";
                nightschange8.style.display = "none";
                nightschange9.style.display = "none";
                nightschange10.style.display = "none";
                nightschange11.style.display = "none";
                nightschange12.style.display = "none";
                nightschange13.style.display = "none";
                nightschange14.style.display = "none";
                nightschange15.style.display = "none";
                nightschange16.style.display = "none";
                nightschange17.style.display = "none";
                nightschange18.style.display = "none";
                nightschange19.style.display = "none";
                nightschange20.style.display = "none";
                nightschange21.style.display = "none";
                nightschange22.style.display = "none";
                nightschange23.style.display = "none";
                nightschange24.style.display = "none";
                nightschange25.style.display = "none";
                nightschange26.style.display = "none";
                nightschange27.style.display = "none";
                nightschange28.style.display = "block";
                nightschange29.style.display = "none";
                nightschange30.style.display = "none";
            }
            else if (mouseX == 1160) {
                test1.style.display = "none";
                test2.style.display = "none";
                test3.style.display = "none";
                test4.style.display = "none";
                test5.style.display = "none";
                test6.style.display = "none";
                test7.style.display = "none";
                test8.style.display = "none";
                test9.style.display = "none";
                test10.style.display = "none";
                test11.style.display = "none";
                test12.style.display = "none";
                test13.style.display = "none";
                test14.style.display = "none";
                test15.style.display = "none";
                test16.style.display = "none";
                test17.style.display = "none";
                test18.style.display = "none";
                test19.style.display = "none";
                test20.style.display = "none";
                test21.style.display = "none";
                test22.style.display = "none";
                test23.style.display = "none";
                test24.style.display = "none";
                test25.style.display = "none";
                test26.style.display = "none";
                test27.style.display = "none";
                test28.style.display = "none";
                test29.style.display = "block";
                test30.style.display = "none";
                nightschange1.style.display = "none";
                nightschange2.style.display = "none";
                nightschange3.style.display = "none";
                nightschange4.style.display = "none";
                nightschange5.style.display = "none";
                nightschange6.style.display = "none";
                nightschange7.style.display = "none";
                nightschange8.style.display = "none";
                nightschange9.style.display = "none";
                nightschange10.style.display = "none";
                nightschange11.style.display = "none";
                nightschange12.style.display = "none";
                nightschange13.style.display = "none";
                nightschange14.style.display = "none";
                nightschange15.style.display = "none";
                nightschange16.style.display = "none";
                nightschange17.style.display = "none";
                nightschange18.style.display = "none";
                nightschange19.style.display = "none";
                nightschange20.style.display = "none";
                nightschange21.style.display = "none";
                nightschange22.style.display = "none";
                nightschange23.style.display = "none";
                nightschange24.style.display = "none";
                nightschange25.style.display = "none";
                nightschange26.style.display = "none";
                nightschange27.style.display = "none";
                nightschange28.style.display = "none";
                nightschange29.style.display = "block";
                nightschange30.style.display = "none";
            }
            else if (mouseX == 1200) {
                test1.style.display = "none";
                test2.style.display = "none";
                test3.style.display = "none";
                test4.style.display = "none";
                test5.style.display = "none";
                test6.style.display = "none";
                test7.style.display = "none";
                test8.style.display = "none";
                test9.style.display = "none";
                test10.style.display = "none";
                test11.style.display = "none";
                test12.style.display = "none";
                test13.style.display = "none";
                test14.style.display = "none";
                test15.style.display = "none";
                test16.style.display = "none";
                test17.style.display = "none";
                test18.style.display = "none";
                test19.style.display = "none";
                test20.style.display = "none";
                test21.style.display = "none";
                test22.style.display = "none";
                test23.style.display = "none";
                test24.style.display = "none";
                test25.style.display = "none";
                test26.style.display = "none";
                test27.style.display = "none";
                test28.style.display = "none";
                test29.style.display = "none";
                test30.style.display = "block";
                nightschange1.style.display = "none";
                nightschange2.style.display = "none";
                nightschange3.style.display = "none";
                nightschange4.style.display = "none";
                nightschange5.style.display = "none";
                nightschange6.style.display = "none";
                nightschange7.style.display = "none";
                nightschange8.style.display = "none";
                nightschange9.style.display = "none";
                nightschange10.style.display = "none";
                nightschange11.style.display = "none";
                nightschange12.style.display = "none";
                nightschange13.style.display = "none";
                nightschange14.style.display = "none";
                nightschange15.style.display = "none";
                nightschange16.style.display = "none";
                nightschange17.style.display = "none";
                nightschange18.style.display = "none";
                nightschange19.style.display = "none";
                nightschange20.style.display = "none";
                nightschange21.style.display = "none";
                nightschange22.style.display = "none";
                nightschange23.style.display = "none";
                nightschange24.style.display = "none";
                nightschange25.style.display = "none";
                nightschange26.style.display = "none";
                nightschange27.style.display = "none";
                nightschange28.style.display = "none";
                nightschange29.style.display = "none";
                nightschange30.style.display = "block";
            }
        }
        else if (mouseX <= 0) {
            line.style.backgroundColor = "rgb(221, 221, 221)";
        }

        if (mouseX >= 0 && mouseX <= maxX) {
            point.style.left = `${mouseX}px`;
        }
    }
}

function showlogin() {
    const loginsignupdiv = document.getElementById("loginsignupdiv");
    const change = document.getElementById("change");
    const img2 = document.getElementById("img2");
    const img3 = document.getElementById("img3");
    const img4 = document.getElementById("img4");
    const host19 = document.getElementsByClassName("host19")[0];
    const host24 = document.getElementsByClassName("host24")[0];
    const host27 = document.getElementsByClassName("host27")[0];
    const hidediv = document.getElementById("hidediv");
    const pack1 = document.getElementsByClassName("pack1")[0];
    const passwordfield = document.getElementsByClassName("passwordfield")[0]
    const emailcontent = document.getElementsByClassName("emailcontent")[0];
    const RegistrationForm = document.getElementsByClassName("registration-form-container")[0];
    const fbsection = document.getElementById("fbsection");
    const googlesection = document.getElementById("googlesection");
    const applesection = document.getElementById("applesection");
    const p22 = document.getElementById("p22");
    if (isRegistered) {
        return;
    }
    if (isloggedIn) {
        return;
    }
    loginsignupdiv.style.display = "block";
    loginsignupdiv.style.opacity = 1;
    loginsignupdiv.style.width = "35rem";
    loginsignupdiv.style.height = "51rem";
    loginsignupdiv.style.backgroundColor = "white";
    loginsignupdiv.style.boxShadow = "-1px -1px 1px rgb(225, 225, 225)";
    loginsignupdiv.style.border = "1px solid rgb(225, 225, 225)";
    loginsignupdiv.style.borderRadius = "1rem";
    loginsignupdiv.style.position = "absolute";
    loginsignupdiv.style.overflow = "auto";
    loginsignupdiv.style.zIndex = "1";
    loginsignupdiv.style.top = "9rem";
    loginsignupdiv.style.left = "58rem";
    loginsignupdiv.style.transition = "transform 0.5s ease-in-out";
    loginsignupdiv.style.transform = "translateY(0)";
    loginsignupdiv.style.animation = "SlideFromBottom 0.5s ease-in-out";
    hidediv.style.marginTop = "9rem";
    passwordfield.style.width = "30.7rem";
    pack1.style.display = "flex";
    change.style.backgroundColor = "rgb(123, 123, 123)";
    host19.style.backgroundColor = "rgb(123, 123, 123)";
    host24.style.backgroundColor = "rgb(123, 123, 123)";
    img2.style.filter = "brightness(0.5)";
    img3.style.filter = "brightness(0.5)";
    img4.style.filter = "brightness(0.5)";
    emailcontent.style.marginLeft = "1.6rem";
    window.addEventListener('click', (event) => {
        const clickoutside1 = document.querySelector(".host4");
        const clickoutside2 = document.querySelector(".host27");
        if (!clickoutside1.contains(event.target) && !clickoutside2.contains(event.target)) {
            loginsignupdiv.style.display = "none";
            host19.style.backgroundColor = "";
            change.style.backgroundColor = "";
            img2.style.filter = "";
            img3.style.filter = "";
            img4.style.filter = "";
            host24.style.backgroundColor = "";
            host27.style.backgroundColor = "";
            RegistrationForm.style.display = "none";
            emailcontent.style.display = "block";
            hidediv.style.display = "block";
            pack1.style.display = "block";
            pack1.style.display = "flex";
            fbsection.style.display = "block";
            googlesection.style.display = "block";
            applesection.style.display = "block";
            p22.style.display = "block";
            loginsignupdiv.style.width = "35rem";
            loginsignupdiv.style.height = "51rem";
            passwordfield.style.display = "block";
        }
    })
}
const loginsignupdiv = document.getElementById("loginsignupdiv");
loginsignupdiv.addEventListener('click', (event) => {
    event.stopPropagation();
});

function fun17() {
    const emailshow = document.getElementsByClassName("emailshow")[0];
    const emailcontent = document.getElementsByClassName("emailcontent")[0];
    const showemailtext = document.getElementsByClassName("showemailtext")[0];
    const error2 = document.getElementsByClassName("error2")[0];
    const hidediv = document.getElementById("hidediv");
    const emailerror = document.getElementsByClassName("emailerror")[0];
    emailshow.style.display = "block";
    error2.style.display = "none";
    showemailtext.style.display = "none";
    loginsignupdiv.style.height = "50rem";
    hidediv.style.display = "block";
    emailcontent.style.border = "2px solid black";
    document.body.addEventListener("click", (event) => {
        if (!emailcontent.contains(event.target) || !hidediv.contains(event.target)) {
            emailcontent.style.border = "2px solid black";
            emailerror.style.display = "none";
        }
    })
}
function submit2(event) {
    event.preventDefault();
    const et = document.getElementById("et");
    const emailerror = document.getElementsByClassName("emailerror")[0];
    const emailcontent = document.getElementsByClassName("emailcontent")[0];
    const userlogo = document.getElementsByClassName("userlogo")[0];
    const loginsignupdiv = document.getElementById("loginsignupdiv");
    const emailinfoValue = document.getElementById("email-info");
    const pack1 = document.getElementsByClassName("pack1")[0];
    const pass = document.getElementById("pass");
    const Password = pass.value.trim();
    const change = document.getElementById("change");
    const img2 = document.getElementById("img2");
    const img3 = document.getElementById("img3");
    const img4 = document.getElementById("img4");
    const host19 = document.getElementsByClassName("host19")[0];
    const host24 = document.getElementsByClassName("host24")[0];
    const host27 = document.getElementsByClassName("host27")[0];
    const RegistrationForm = document.getElementsByClassName("registration-form-container")[0];
    const logincircle = document.getElementsByClassName("logincircle")[0];
    let regex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
    const inputValue = et.value.trim();
    const inputValueAsString = inputValue.toString()
    if (regex.test(inputValueAsString)) {
        emailerror.style.display = "none";
        const formData = {
            email: inputValue,
            password: Password,
        };
        fetch('/handlelogin', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(formData),
        })
            .then(response => response.json())
            .then(data => {
                if (data.message === "Success") {
                    alert("You are logged in Successfully");
                    isloggedIn = true;
                    document.querySelector('#loginsignupdiv').style.display = "none";
                    let character = inputValue[0];
                    userlogo.innerText = character;
                    document.querySelector('.logincircle').style.display = "block";
                    logincircle.style.marginLeft = "2rem";
                    logincircle.style.marginTop = "5rem";
                    change.style.backgroundColor = "";
                    img2.style.filter = "";
                    img3.style.filter = "";
                    img4.style.filter = "";
                    host19.style.backgroundColor = "";
                    host24.style.backgroundColor = "";
                    host27.style.backgroundColor = "";
                    if (host4clicked) {
                        fetch('/Becomeahost', {
                            method: 'GET',
                            headers: {
                                'Content-Type': "application/json"
                            }
                        })
                            .then(response => {
                                if (response.redirected) {
                                    // Redirect to the URL sent by the server
                                    window.location.href = response.url;
                                } else {
                                    throw new Error('Invalid redirect');
                                }
                            }
                            )
                            .then(data => console.log(data))
                            .catch(error => console.log(error))
                    }
                    // please defined api
                    else if (host27clicked) {
                        fetch('/register/nextpage', {
                            method: "GET",
                            headers: {
                                'Content-Type': "application/json"
                            }
                        })
                            .then(response => {
                                if (response.redirected) {
                                    window.location.href = response.url;
                                }
                                else {
                                    throw new Error
                                }
                            })
                            .then(data => console.log(data))
                            .catch(error => console.log(error))
                    }

                } else if (data.message === "Login Failed!") {
                    alert("Invalid Credentials!");
                }
                else if (data.message === "User not found") {
                    alert("Please Register");
                    document.querySelector('.registration-form-container').style.display = 'block';
                    emailinfoValue.value = inputValue;
                    document.querySelector('#hidediv').style.display = "none";
                    document.querySelector('.emailcontent').style.display = "none";
                    document.querySelector('.passwordfield').style.display = "none";
                    document.querySelector('#fbsection').style.display = "none";
                    document.querySelector('#googlesection').style.display = "none";
                    document.querySelector('#applesection').style.display = "none";
                    document.querySelector('#p22').style.display = "none";
                    loginsignupdiv.style.height = "96rem";
                    loginsignupdiv.style.width = "58rem";
                    loginsignupdiv.style.marginLeft = "1rem";
                    loginsignupdiv.style.overflow = "hidden";
                    RegistrationForm.style.marginTop = "-1rem";
                    RegistrationForm.style.marginLeft = "4rem";
                    pack1.style.display = "none";
                }
            })
            .catch((error) => {
                console.error('Error:', error);
            });
    }
    else {
        emailerror.style.display = "block";
        emailcontent.style.border = "2px solid red";
        emailerror.style.color = "red";
        emailerror.style.marginLeft = "5%";
        emailerror.innerHTML = "Please Enter Vaild Email address !";
    }
    if (et.value == "") {
        emailerror.style.display = "block";
        emailcontent.style.border = "2px solid red";
        emailerror.style.color = "red";
        emailerror.style.marginLeft = "5%";
        emailerror.innerHTML = "Email required !";
    }
}
const host4 = document.getElementsByClassName("host4")[0];
const host27 = document.getElementsByClassName("host27")[0];
host4.addEventListener('click', () => {
    host4clicked = true;
    showlogin();
});
host27.addEventListener('click', () => {
    host27clicked = true;
    showlogin();
});
const button = document.querySelector('.continuebutton')
button.addEventListener('mousemove', e => {
    const rect = button.getBoundingClientRect();
    const x = (e.clientX - rect.left) * 100 / button.clientWidth
    const y = (e.clientY - rect.top) * 100 / button.clientHeight
    button.style.setProperty('--mouse-x', x);
    button.style.setProperty('--mouse-y', y);
});
function fun56() {
    const emailcontent = document.getElementsByClassName("emailcontent")[0];
    const passwordfield = document.getElementsByClassName("passwordfield")[0];
    const registrationForm = document.getElementsByClassName("registration-form-container")[0];
    const hidediv = document.getElementById("hidediv");
    const pack1 = document.getElementsByClassName("pack1")[0];
    const fbsection = document.getElementById("fbsection");
    const googlesection = document.getElementById("googlesection");
    const applesection = document.getElementById("applesection");
    const p22 = document.getElementById("p22");
    const loginsignupdiv = document.getElementById("loginsignupdiv");
    emailcontent.style.display = "block";
    passwordfield.style.display = "block";
    registrationForm.style.display = "none";
    hidediv.style.display = "block";
    pack1.style.display = "block";
    pack1.style.display = "flex";
    fbsection.style.display = "block";
    fbsection.style.display = "flex";
    googlesection.style.display = "block";
    googlesection.style.display = "flex";
    applesection.style.display = "block";
    applesection.style.display = "flex";
    p22.style.display = "block";
    p22.style.display = "flex";
    loginsignupdiv.style.width = "35rem";
    loginsignupdiv.style.height = "51rem";
}
function previous(event) {
    const emailcontent = document.getElementsByClassName("emailcontent")[0];
    const emailshow = document.getElementsByClassName("emailshow")[0];
    const showemailtext = document.getElementsByClassName("showemailtext")[0];
    if (!emailcontent.contains(event.target)) {
        emailshow.style.display = "block";
        showemailtext.style.display = "none";
    }
}
function hidedisplay() {
    const loginsignupdiv = document.getElementById("loginsignupdiv");
    const pElements = document.querySelectorAll(".p img");
    const emailcontent = document.getElementsByClassName("emailcontent")[0];
    const hidediv = document.getElementById("hidediv");
    const pack1 = document.getElementsByClassName("pack1")[0];
    const host19 = document.getElementsByClassName("host19")[0];
    const host24 = document.getElementsByClassName("host24")[0];
    const host27 = document.getElementsByClassName("host27")[0];
    const passwordfield = document.getElementsByClassName("passwordfield")[0]
    const change = document.getElementById("change");
    const img2 = document.getElementById("img2");
    const img3 = document.getElementById("img3");
    const img4 = document.getElementById("img4");
    loginsignupdiv.style.width = "35rem";
    loginsignupdiv.style.height = "51rem";
    emailcontent.style.display = "block";
    hidediv.style.display = "block";
    pack1.style.display = "block";
    document.querySelector('#fbsection').style.display = "block";
    document.querySelector('#fbsection').style.display = "flex";
    document.querySelector('#googlesection').style.display = "block";
    document.querySelector('#googlesection').style.display = "flex";
    document.querySelector('#applesection').style.display = "block";
    document.querySelector('#applesection').style.display = "flex";
    document.querySelector('#p22').style.display = "block";
    document.querySelector('#p22').style.display = "flex";
    document.querySelector('.registration-form-container').style.display = "none";
    document.querySelector('.passwordfield').style.display = "block";
    loginsignupdiv.style.display = "none";
    loginsignupdiv.classList.remove("show1");
    loginsignupdiv.classList.add("loginsignupcontainer");
    host19.style.backgroundColor = "";
    change.style.backgroundColor = "";
    img2.style.filter = "";
    img3.style.filter = "";
    img4.style.filter = "";
    host24.style.backgroundColor = "";
    host27.style.backgroundColor = "";
}
function fun18() {
    const showemailtext = document.getElementsByClassName("showemailtext")[0];
    const emailshow = document.getElementsByClassName("emailshow")[0];
    emailshow.style.display = "none";
    showemailtext.style.display = "block";
    document.addEventListener('click', previous);
}
function popup() {
    const learnmore = document.getElementById("learnmore");
    const host36 = document.getElementsByClassName("host36")[0];
    const change = document.getElementById("change");
    const img2 = document.getElementById("img2");
    const img3 = document.getElementById("img3");
    const img4 = document.getElementById("img4");
    const host19 = document.getElementsByClassName("host19")[0];
    const host24 = document.getElementsByClassName("host24")[0];
    host36.style.display = "block";
    change.style.backgroundColor = "rgb(123, 123, 123)";
    change.style.overflowX = "hidden";
    host19.style.backgroundColor = "rgb(123, 123, 123)";
    host24.style.backgroundColor = "rgb(123, 123, 123)";
    img2.style.filter = "brightness(0.5)";
    img3.style.filter = "brightness(0.5)";
    img4.style.filter = "brightness(0.5)";
    host36.style.transition = "transform 0.5s ease-in-out";
    host36.style.transform = "translateY(0)";
    host36.style.animation = "SlideFromBottom 0.5s ease-in-out";
    window.addEventListener('click', (event) => {
        if (!learnmore.contains(event.target) && !hostlocation.contains(event.target)) {
            host36.style.display = "none";
            change.style.backgroundColor = "";
            host19.style.backgroundColor = "";
            host24.style.backgroundColor = "";
            img2.style.filter = "";
            img3.style.filter = "";
            img4.style.filter = "";
            change.style.overflowX = "hidden";
        }
    })
}
const learnmore = document.getElementById("learnmore");
learnmore.addEventListener('click', () => {
    popup();
})
const host36 = document.getElementsByClassName("host36")[0];
host36.addEventListener("click", (event) => {
    event.stopPropagation();
});
function closenow() {
    const host36 = document.getElementsByClassName("host36")[0];
    const change = document.getElementById("change");
    const img2 = document.getElementById("img2");
    const img3 = document.getElementById("img3");
    const img4 = document.getElementById("img4");
    const host19 = document.getElementsByClassName("host19")[0];
    const host24 = document.getElementsByClassName("host24")[0];
    host36.style.display = "none";
    change.style.backgroundColor = "";
    host19.style.backgroundColor = "";
    host24.style.backgroundColor = "";
    img2.style.filter = "";
    img3.style.filter = "";
    img4.style.filter = "";
    change.style.overflowX = "hidden";
}
function nowsearch() {
    const hidedata = document.getElementById("hidedata");
    const showdata = document.getElementById("showdata");
    const address = document.getElementById("address");
    const host38one = document.getElementById("host38one")
    const host38 = document.getElementsByClassName("host38")[0];
    const Line2 = document.getElementById("Line2");
    const Line3 = document.getElementById("Line3");
    const content = document.getElementById("content");
    const content1 = document.getElementById("content1");
    const content5 = document.getElementsByClassName("content5")[0];
    const counter13 = document.getElementsByClassName("counter13")[0];
    const counter14 = document.getElementsByClassName("counter14")[0];
    const updatebutton = document.getElementById("updatebutton");
    hidedata.style.display = "none";
    updatebutton.style.display = "none";
    showdata.style.display = "block";
    address.style.display = "none";
    host38.style.display = "none";
    content5.style.display = "none";
    host38one.style.display = "block";
    Line2.style.display = "none";
    Line3.style.display = "none";
    content.style.display = "none";
    content1.style.display = "none";
    counter13.style.display = "none";
    counter14.style.display = "none";
}
function back() {
    const hidedata = document.getElementById("hidedata");
    const showdata = document.getElementById("showdata");
    const address = document.getElementById("address");
    const host38one = document.getElementById("host38one")
    const host38 = document.getElementsByClassName("host38")[0];
    const aboutplace = document.getElementById("aboutplace");
    const Line2 = document.getElementById("Line2");
    const Line3 = document.getElementById("Line3");
    const content = document.getElementById("content");
    const content1 = document.getElementById("content1");
    const content5 = document.getElementsByClassName("content5")[0];
    const counter13 = document.getElementsByClassName("counter13")[0];
    const counter14 = document.getElementsByClassName("counter14")[0];
    hidedata.style.display = "block";
    showdata.style.display = "none";
    address.style.display = "block";
    host38.style.display = "block";
    host38one.style.display = "none";
    aboutplace.style.marginTop = "-3.8rem";
    aboutplace.style.marginLeft = "19rem";
    aboutplace.style.marginBottom = "2rem";
    content5.style.display = "block";
    content5.style.display = "flex";
    Line2.style.display = "block";
    Line3.style.display = "block";
    content.style.display = "block";
    content1.style.display = "block";
    content1.style.display = "flex";
    counter13.style.display = "block";
    counter14.style.display = "block";
}

let counter5 = 0;
function add5() {
    const content9 = document.getElementById("content9");
    const content11 = document.getElementById("content11");
    const content8 = document.getElementById("content8");
    const content12 = document.getElementById("content12");
    const content10 = document.getElementById("content10");
    content11.style.userSelect = "none";
    content8.style.userSelect = "none";
    content8.style.cursor = "pointer";
    content12.style.cursor = "pointer";
    if (counter5 < 8) {
        counter5++;
        content9.innerHTML = counter5;
        content10.style.color = "black";
        content11.onmouseover = () => {
            content11.style.border = "2px solid black";
            content10.style.color = "black";
        }
        content11.onmouseout = () => {
            content11.style.border = "2px solid rgb(185, 185, 185)";
        }
    }
    if (counter5 > 7) {
        content11.style.cursor = "not-allowed";
        content10.style.cursor = "not-allowed";
    }

    if (counter5 == 8) {
        content10.style.color = "rgb(185, 185, 185)";
        content11.onmouseover = () => {
            content11.style.border = "2px solid rgb(185, 185, 185)";
            content10.style.color = "rgb(185, 185, 185)";
        }

        content11.onmouseout = () => {
            content11.style.border = "2px solid rgb(185, 185, 185)";
        }
    }

    content8.style.color = "black";
    content12.onmouseover = () => {
        content12.style.border = "2px solid black";
        content8.style.color = "black";
    }
    content12.onmouseout = () => {
        content12.style.border = "2px solid rgb(185, 185, 185)";
    }
}
function sub5() {
    const content8 = document.getElementById("content8");
    const content9 = document.getElementById("content9");
    const content10 = document.getElementById("content10");
    const content11 = document.getElementById("content11");
    const content12 = document.getElementById("content12");
    content11.style.cursor = "pointer";
    content10.style.cursor = "pointer";
    content11.style.cursor = "pointer";
    content10.style.color = "black";
    content11.onmouseover = () => {
        content11.style.border = "2px solid black";
        content10.style.color = "black";
    }
    content11.onmouseout = () => {
        content11.style.border = "2px solid rgb(185, 185, 185)";
    }
    if (counter5 > 0) {
        counter5--;
        content9.innerHTML = counter5;
        content12.style.cursor = "pointer";

    }
    if (counter5 == 0) {
        content12.style.cursor = "not-allowed";
        content8.style.cursor = "not-allowed";
        content12.style.border = "2px solid rgb(185, 185, 185)";
        content8.style.color = "rgb(185, 185, 185)"
        content12.onmouseover = () => {
            content12.style.border = "2px solid rgb(185, 185, 185)";
            content8.style.color = "rgb(185, 185, 185)";
        }
        content12.onmouseout = () => {
            content12.style.border = "2px solid rgb(185, 185, 185)";
            content8.style.color = "rgb(185, 185, 185)";
        }
    }

}
function fun56() {
    const emailcontent = document.getElementsByClassName("emailcontent")[0];
    const passwordfield = document.getElementsByClassName("passwordfield")[0];
    const registrationForm = document.getElementsByClassName("registration-form-container")[0];
    const hidediv = document.getElementById("hidediv");
    const pack1 = document.getElementsByClassName("pack1")[0];
    const fbsection = document.getElementById("fbsection");
    const googlesection = document.getElementById("googlesection");
    const applesection = document.getElementById("applesection");
    const p22 = document.getElementById("p22");
    const loginsignupdiv = document.getElementById("loginsignupdiv");
    emailcontent.style.display = "block";
    passwordfield.style.display = "block";
    registrationForm.style.display = "none";
    hidediv.style.display = "block";
    pack1.style.display = "block";
    pack1.style.display = "flex";
    fbsection.style.display = "block";
    fbsection.style.display = "flex";
    googlesection.style.display = "block";
    googlesection.style.display = "flex";
    applesection.style.display = "block";
    applesection.style.display = "flex";
    p22.style.display = "block";
    p22.style.display = "flex";
    loginsignupdiv.style.width = "35rem";
    loginsignupdiv.style.height = "51rem";
}
function fun52() {
    const fname = document.getElementById("fname");
    const showinput1 = document.getElementById("first-name");
    const register1 = document.getElementById("register1");
    fname.style.fontSize = "1rem";
    fname.style.marginTop = "1rem";
    showinput1.style.display = "block";
    showinput1.style.marginTop = "1rem";
    showinput1.style.marginLeft = "1.1rem";
    register1.style.height = "7.6rem";
    register1.style.borderBottomLeftRadius = "0.7rem";
    register1.style.borderBottomRightRadius = "0.7rem";
}
function fun53() {
    const lname = document.getElementById("lname");
    const showinput2 = document.getElementById("last-name");
    const register2 = document.getElementById("register2");
    lname.style.fontSize = "1rem";
    lname.style.marginTop = "1rem";
    showinput2.style.display = "block";
    showinput2.style.position = "relative";
    showinput2.style.marginTop = "1rem";
    showinput2.style.marginLeft = "1.1rem";
    register2.style.height = "7.6rem";
    register2.style.borderBottomLeftRadius = "0.7rem";
    register2.style.borderBottomRightRadius = "0.7rem";
    register2.style.borderTopLeftRadius = "0.7rem";
    register2.style.borderTopRightRadius = "0.7rem";
}
function fun54() {
    const dob = document.getElementById("dob");
    const showinput3 = document.getElementById("date-of-birth");
    dob.style.fontSize = "1rem";
    dob.style.marginTop = "1rem";
    showinput3.style.display = "block";
}
function fun55() {
    const pass1 = document.getElementById("pass1");
    const showinput4 = document.getElementById("pass2");
    const register4 = document.getElementById("register4");
    pass1.style.fontSize = "1rem";
    pass1.style.marginTop = "1rem";
    showinput4.style.display = "block";
    register4.style.border = "2px solid black";
}
function calculateAge(dateOfBirth) {
    // Parse the date of birth string into a Date object
    const dob = new Date(dateOfBirth);

    // Get the current date
    const currentDate = new Date();

    // Calculate the difference in years
    let age = currentDate.getFullYear() - dob.getFullYear();

    // Adjust the age if the birthday hasn't occurred yet this year
    if (currentDate.getMonth() < dob.getMonth() ||
        (currentDate.getMonth() === dob.getMonth() && currentDate.getDate() < dob.getDate())) {
        age--;
    }
    return age;
}
function openlogout() {
    const container14 = document.getElementsByClassName("container14")[0];
    const logincircle = document.getElementsByClassName("logincircle")[0];
    container14.style.display = "block";
    container14.style.marginLeft = "-7rem";
    container14.style.marginTop = "11.5rem";
    container14.style.textAlign = "center";
    document.body.addEventListener('click', (event) => {
        if (!logincircle.contains(event.target)) {
            container14.style.display = "none";
        }
    })
}
const searchdetails = [
    "Agartala,Tripura",
    "Agra,Uttar Pradesh",
    "Ahmedabad,Gujarat",
    "Aizwal,Mizoram",
    "Ajmer,Rajasthan",
    "Allahabad,Uttar Pradesh",
    "Alleppey,Kerala",
    "Alibagh,Maharashtra",
    "Almora,Uttaranchal",
    "Alsisar,Rajasthan",
    "Alwar,Rajasthan",
    "Ambala,Haryana",
    "Amla,Madhya Pradesh",
    "Amritsar,Punjab",
    "Anand,Gujarat",
    "Ankleshwar,Gujarat",
    "Ashtamudi,Kerala",
    "Auli,Himachal Pradesh",
    "Aurangabad,Maharashtra",
    "Bengaluru, India",
    "Nilgiris, India",
    "Kodaikanal, India",
    "Velloor, India",
    "Konavakorai, India",
    "Kodaikanal, India",
    "Kerala, India",
    "Mysore, India",
    "Coonoor, India",
    "Kotagiri, India",
    "Chennai, India",
    "Nadukani, India",
    "Sigiriya, Sri Lanka",
    "Varkala, India",
    "Kainakary South, India",
    "Mananthavady, India",
    "Kollam, India",
    "Kandy, Sri Lanka",
    "Nedumkandam, India",
    "Habarana, Sri Lanka",
    "Munroe Island, India",
    "Madikeri, India",
    "Kaup, India",
    "Kandy, Sri Lanka",
    "Vythiri, India",
    "Ernakulam, India",
    "Kottayam, India",
    "Ratnapura, Sri Lanka",
    "Siddapura, India"
];
// Function to create and append an <li> element to the list

function createListItem(text) {

    // Create the <li> element
    var li = document.createElement("li");
    li.classList.add("styleli");
    // Create the <a> element
    var a = document.createElement("a");
    var p = document.createElement("p");
    a.classList.add("removestyle");
    p.classList.add("pstyle")
    // Set the text content of the <a> element
    a.textContent = text;
    // Set the href attribute of the <a> element
    a.setAttribute("href", "#");
    // Set the onclick attribute of the <a> element to call populateInput function
    a.setAttribute("onclick", "populateInput(this)");
    // Append the <a> element to the <li> element
    li.appendChild(p);
    p.appendChild(a);
    // Append the <li> element to the list
    document.getElementById("myUL").appendChild(li);
}
function myFunction() {
    var input, filter, ul, li, a, i, txtValue;
    input = document.getElementById("list");
    filter = input.value.toUpperCase();
    ul = document.getElementById("myUL");
    li = ul.getElementsByTagName("li");
    for (i = 0; i < li.length; i++) {
        a = li[i].getElementsByTagName("a")[0];
        txtValue = a.textContent || a.innerText;
        if (txtValue.toUpperCase().indexOf(filter) > -1) {
            li[i].style.display = "";
        } else {
            li[i].style.display = "none";
        }
    }
}

// Function to populate the input field with the clicked item's text content
function populateInput(element) {
    var input = document.getElementById("list");
    const host39 = document.getElementsByClassName("host39")[0];
    const host38 = document.getElementsByClassName("host38")[0];
    const showdata = document.getElementById("showdata");
    const hidedata = document.getElementById("hidedata");
    const host38one = document.getElementById("host38one");
    const searchDropdown = document.getElementById("searchDropdown");
    const Line2 = document.getElementById("Line2");
    const Line3 = document.getElementById("Line3");
    const content = document.getElementById("content");
    const content1 = document.getElementById("content1");
    const content5 = document.getElementsByClassName("content5")[0];
    const counter13 = document.getElementsByClassName("counter13")[0];
    const counter14 = document.getElementsByClassName("counter14")[0];
    input.value = element.textContent || element.innerText;
    host39.innerHTML = input.value;
    showdata.style.display = "none";
    hidedata.style.display = "block";
    hidedata.style.display = "flex";
    host38one.style.display = "none";
    host38.style.display = "block";
    searchDropdown.style.display = "none";
    Line2.style.display = "block";
    Line3.style.display = "block";
    content.style.display = "block";
    content1.style.display = "block";
    content1.style.display = "flex";
    content5.style.display = "block";
    content5.style.display = "flex";
    counter13.style.display = "block";
    counter14.style.display = "block";
    counter14.style.marginTop = "9rem";
}
searchdetails.forEach((text) => {
    createListItem(text);
});
function closedropdown() {
    const searchDropdown = document.getElementById("searchDropdown");
    const list = document.getElementById("list");
    document.body.addEventListener('click', (event) => {
        if (list.contains(event.target) || searchDropdown.contains(event.target)) {
            searchDropdown.style.display = "block";
        }
        else {
            searchDropdown.style.display = "none";
        }
    })
}



function typedata() {
    const list = document.getElementById("list");
    const host39 = document.getElementsByClassName("host39")[0];
    const host38 = document.getElementsByClassName("host38")[0];
    const showdata = document.getElementById("showdata");
    const hidedata = document.getElementById("hidedata");
    const host38one = document.getElementById("host38one");
    const searchDropdown = document.getElementById("searchDropdown");
    const Line2 = document.getElementById("Line2");
    const Line3 = document.getElementById("Line3");
    const content = document.getElementById("content");
    const content1 = document.getElementById("content1");
    const content5 = document.getElementsByClassName("content5")[0];
    const counter13 = document.getElementsByClassName("counter13")[0];
    const counter14 = document.getElementsByClassName("counter14")[0];
    showdata.style.display = "none";
    hidedata.style.display = "block";
    hidedata.style.display = "flex";
    host38one.style.display = "none";
    host38.style.display = "block";
    searchDropdown.style.display = "none";
    Line2.style.display = "block";
    Line3.style.display = "block";
    content.style.display = "block";
    content1.style.display = "block";
    content1.style.display = "flex";
    content5.style.display = "block";
    content5.style.display = "flex";
    counter13.style.display = "block";
    counter14.style.display = "block";
    host39.innerHTML = list.value;
}
function private() {
    const private = document.getElementsByClassName("private")[0];
    const entireplace = document.getElementsByClassName("entireplace")[0];
    const content5 = document.getElementsByClassName("content5")[0];
    const counter14 = document.getElementsByClassName("counter14")[0];
    const updatebutton = document.getElementById("updatebutton");
    entireplace.style.backgroundColor = "rgb(235, 235, 235)";
    private.style.backgroundColor = "white";
    content5.style.opacity = "0.5";
    counter14.style.display = "none";
    updatebutton.style.display = "block";
    updatebutton.style.marginTop = "2rem";
}
function private1() {
    const private = document.getElementsByClassName("private")[0];
    const entireplace = document.getElementsByClassName("entireplace")[0];
    const content5 = document.getElementsByClassName("content5")[0];
    const counter14 = document.getElementsByClassName("counter14")[0];
    const updatebutton = document.getElementById("updatebutton");
    entireplace.style.backgroundColor = "white";
    private.style.backgroundColor = "rgb(235, 235, 235)";
    content5.style.opacity = "1";
    counter14.style.display = "block";
    updatebutton.style.display = "none";
}
function execute() {
    const unique = document.getElementById("unique");
    const change = document.getElementById("change");
    const img2 = document.getElementById("img2");
    const img3 = document.getElementById("img3");
    const img4 = document.getElementById("img4");
    const host19 = document.getElementsByClassName("host19")[0];
    const host24 = document.getElementsByClassName("host24")[0];
    const place3 = document.getElementsByClassName("place3")[0];
    const place = document.getElementsByClassName("place")[0];
    const host39 = document.getElementsByClassName("host39")[0];
    unique.style.display = "none";
    change.classList.remove("colorchange");
    change.style.overflowX = "hidden";
    host19.style.backgroundColor = "";
    host24.style.backgroundColor = "";
    img2.style.filter = "";
    img3.style.filter = "";
    img4.style.filter = "";
    place3.innerText = text + " bedroom";
    place.innerText = host39.innerText;
    place.style.marginLeft = "-23rem";
}
function nowcheck() {
    const content9 = document.getElementById("content9");
    const test1 = document.getElementById("test1");
    const test2 = document.getElementById("test2");
    const test3 = document.getElementById("test3");
    const test4 = document.getElementById("test4");
    const test5 = document.getElementById("test5");
    const test6 = document.getElementById("test6");
    const test7 = document.getElementById("test7");
    const test8 = document.getElementById("test8");
    const test9 = document.getElementById("test9");
    const test10 = document.getElementById("test10");
    const test11 = document.getElementById("test11");
    const test12 = document.getElementById("test12");
    const test13 = document.getElementById("test13");
    const test14 = document.getElementById("test14");
    const test15 = document.getElementById("test15");
    const test16 = document.getElementById("test16");
    const test17 = document.getElementById("test17");
    const test18 = document.getElementById("test18");
    const test19 = document.getElementById("test19");
    const test20 = document.getElementById("test20");
    const test21 = document.getElementById("test21");
    const test22 = document.getElementById("test22");
    const test23 = document.getElementById("test23");
    const test24 = document.getElementById("test24");
    const test25 = document.getElementById("test25");
    const test26 = document.getElementById("test26");
    const test27 = document.getElementById("test27");
    const test28 = document.getElementById("test28");
    const test29 = document.getElementById("test29");
    const test30 = document.getElementById("test30");
    const nightschange1 = document.getElementById("nightschange1");
    const nightschange2 = document.getElementById("nightschange2");
    const nightschange3 = document.getElementById("nightschange3");
    const nightschange4 = document.getElementById("nightschange4");
    const nightschange5 = document.getElementById("nightschange5");
    const nightschange6 = document.getElementById("nightschange6");
    const nightschange7 = document.getElementById("nightschange7");
    const nightschange8 = document.getElementById("nightschange8");
    const nightschange9 = document.getElementById("nightschange9");
    const nightschange10 = document.getElementById("nightschange10");
    const nightschange11 = document.getElementById("nightschange11");
    const nightschange12 = document.getElementById("nightschange12");
    const nightschange13 = document.getElementById("nightschange13");
    const nightschange14 = document.getElementById("nightschange14");
    const nightschange15 = document.getElementById("nightschange15");
    const nightschange16 = document.getElementById("nightschange16");
    const nightschange17 = document.getElementById("nightschange17");
    const nightschange18 = document.getElementById("nightschange18");
    const nightschange19 = document.getElementById("nightschange19");
    const nightschange20 = document.getElementById("nightschange20");
    const nightschange21 = document.getElementById("nightschange21");
    const nightschange22 = document.getElementById("nightschange22");
    const nightschange23 = document.getElementById("nightschange23");
    const nightschange24 = document.getElementById("nightschange24");
    const nightschange25 = document.getElementById("nightschange25");
    const nightschange26 = document.getElementById("nightschange26");
    const nightschange27 = document.getElementById("nightschange27");
    const nightschange28 = document.getElementById("nightschange28");
    const nightschange29 = document.getElementById("nightschange29");
    const nightschange30 = document.getElementById("nightschange30");
    var text = content9.innerText;
    if (text == 1) {
        test1.style.display = "block";
        test2.style.display = "none";
        test3.style.display = "none";
        test4.style.display = "none";
        test5.style.display = "none";
        test6.style.display = "none";
        test7.style.display = "none";
        test8.style.display = "none";
        test9.style.display = "none";
        test10.style.display = "none";
        test11.style.display = "none";
        test12.style.display = "none";
        test13.style.display = "none";
        test14.style.display = "none";
        test15.style.display = "none";
        test16.style.display = "none";
        test17.style.display = "none";
        test18.style.display = "none";
        test19.style.display = "none";
        test20.style.display = "none";
        test21.style.display = "none";
        test22.style.display = "none";
        test23.style.display = "none";
        test24.style.display = "none";
        test25.style.display = "none";
        test26.style.display = "none";
        test27.style.display = "none";
        test28.style.display = "none";
        test29.style.display = "none";
        test30.style.display = "none";
        nightschange1.style.display = "block";
        nightschange2.style.display = "none";
        nightschange3.style.display = "none";
        nightschange4.style.display = "none";
        nightschange5.style.display = "none";
        nightschange6.style.display = "none";
        nightschange7.style.display = "none";
        nightschange8.style.display = "none";
        nightschange9.style.display = "none";
        nightschange10.style.display = "none";
        nightschange11.style.display = "none";
        nightschange12.style.display = "none";
        nightschange13.style.display = "none";
        nightschange14.style.display = "none";
        nightschange15.style.display = "none";
        nightschange16.style.display = "none";
        nightschange17.style.display = "none";
        nightschange18.style.display = "none";
        nightschange19.style.display = "none";
        nightschange20.style.display = "none";
        nightschange21.style.display = "none";
        nightschange22.style.display = "none";
        nightschange23.style.display = "none";
        nightschange24.style.display = "none";
        nightschange25.style.display = "none";
        nightschange26.style.display = "none";
        nightschange27.style.display = "none";
        nightschange28.style.display = "none";
        nightschange29.style.display = "none";
        nightschange30.style.display = "none";
        execute()
    }
    else if (text == 2) {
        test1.style.display = "none";
        test2.style.display = "block";
        test3.style.display = "none";
        test4.style.display = "none";
        test5.style.display = "none";
        test6.style.display = "none";
        test7.style.display = "none";
        test8.style.display = "none";
        test9.style.display = "none";
        test10.style.display = "none";
        test11.style.display = "none";
        test12.style.display = "none";
        test13.style.display = "none";
        test14.style.display = "none";
        test15.style.display = "none";
        test16.style.display = "none";
        test17.style.display = "none";
        test18.style.display = "none";
        test19.style.display = "none";
        test20.style.display = "none";
        test21.style.display = "none";
        test22.style.display = "none";
        test23.style.display = "none";
        test24.style.display = "none";
        test25.style.display = "none";
        test26.style.display = "none";
        test27.style.display = "none";
        test28.style.display = "none";
        test29.style.display = "none";
        test30.style.display = "none";
        nightschange1.style.display = "none";
        nightschange2.style.display = "block";
        nightschange3.style.display = "none";
        nightschange4.style.display = "none";
        nightschange5.style.display = "none";
        nightschange6.style.display = "none";
        nightschange7.style.display = "none";
        nightschange8.style.display = "none";
        nightschange9.style.display = "none";
        nightschange10.style.display = "none";
        nightschange11.style.display = "none";
        nightschange12.style.display = "none";
        nightschange13.style.display = "none";
        nightschange14.style.display = "none";
        nightschange15.style.display = "none";
        nightschange16.style.display = "none";
        nightschange17.style.display = "none";
        nightschange18.style.display = "none";
        nightschange19.style.display = "none";
        nightschange20.style.display = "none";
        nightschange21.style.display = "none";
        nightschange22.style.display = "none";
        nightschange23.style.display = "none";
        nightschange24.style.display = "none";
        nightschange25.style.display = "none";
        nightschange26.style.display = "none";
        nightschange27.style.display = "none";
        nightschange28.style.display = "none";
        nightschange29.style.display = "none";
        nightschange30.style.display = "none";
        execute()
    }
    else if (text == 3) {
        test1.style.display = "none";
        test2.style.display = "none";
        test3.style.display = "block";
        test4.style.display = "none";
        test5.style.display = "none";
        test6.style.display = "none";
        test7.style.display = "none";
        test8.style.display = "none";
        test9.style.display = "none";
        test10.style.display = "none";
        test11.style.display = "none";
        test12.style.display = "none";
        test13.style.display = "none";
        test14.style.display = "none";
        test15.style.display = "none";
        test16.style.display = "none";
        test17.style.display = "none";
        test18.style.display = "none";
        test19.style.display = "none";
        test20.style.display = "none";
        test21.style.display = "none";
        test22.style.display = "none";
        test23.style.display = "none";
        test24.style.display = "none";
        test25.style.display = "none";
        test26.style.display = "none";
        test27.style.display = "none";
        test28.style.display = "none";
        test29.style.display = "none";
        test30.style.display = "none";
        nightschange1.style.display = "none";
        nightschange2.style.display = "none";
        nightschange3.style.display = "block";
        nightschange4.style.display = "none";
        nightschange5.style.display = "none";
        nightschange6.style.display = "none";
        nightschange7.style.display = "none";
        nightschange8.style.display = "none";
        nightschange9.style.display = "none";
        nightschange10.style.display = "none";
        nightschange11.style.display = "none";
        nightschange12.style.display = "none";
        nightschange13.style.display = "none";
        nightschange14.style.display = "none";
        nightschange15.style.display = "none";
        nightschange16.style.display = "none";
        nightschange17.style.display = "none";
        nightschange18.style.display = "none";
        nightschange19.style.display = "none";
        nightschange20.style.display = "none";
        nightschange21.style.display = "none";
        nightschange22.style.display = "none";
        nightschange23.style.display = "none";
        nightschange24.style.display = "none";
        nightschange25.style.display = "none";
        nightschange26.style.display = "none";
        nightschange27.style.display = "none";
        nightschange28.style.display = "none";
        nightschange29.style.display = "none";
        nightschange30.style.display = "none";
        execute()
    }
    else if (text == 4) {
        test1.style.display = "none";
        test2.style.display = "none";
        test3.style.display = "none";
        test4.style.display = "block";
        test5.style.display = "none";
        test6.style.display = "none";
        test7.style.display = "none";
        test8.style.display = "none";
        test9.style.display = "none";
        test10.style.display = "none";
        test11.style.display = "none";
        test12.style.display = "none";
        test13.style.display = "none";
        test14.style.display = "none";
        test15.style.display = "none";
        test16.style.display = "none";
        test17.style.display = "none";
        test18.style.display = "none";
        test19.style.display = "none";
        test20.style.display = "none";
        test21.style.display = "none";
        test22.style.display = "none";
        test23.style.display = "none";
        test24.style.display = "none";
        test25.style.display = "none";
        test26.style.display = "none";
        test27.style.display = "none";
        test28.style.display = "none";
        test29.style.display = "none";
        test30.style.display = "none";
        nightschange1.style.display = "none";
        nightschange2.style.display = "none";
        nightschange3.style.display = "none";
        nightschange4.style.display = "block";
        nightschange5.style.display = "none";
        nightschange6.style.display = "none";
        nightschange7.style.display = "none";
        nightschange8.style.display = "none";
        nightschange9.style.display = "none";
        nightschange10.style.display = "none";
        nightschange11.style.display = "none";
        nightschange12.style.display = "none";
        nightschange13.style.display = "none";
        nightschange14.style.display = "none";
        nightschange15.style.display = "none";
        nightschange16.style.display = "none";
        nightschange17.style.display = "none";
        nightschange18.style.display = "none";
        nightschange19.style.display = "none";
        nightschange20.style.display = "none";
        nightschange21.style.display = "none";
        nightschange22.style.display = "none";
        nightschange23.style.display = "none";
        nightschange24.style.display = "none";
        nightschange25.style.display = "none";
        nightschange26.style.display = "none";
        nightschange27.style.display = "none";
        nightschange28.style.display = "none";
        nightschange29.style.display = "none";
        nightschange30.style.display = "none";
        execute()
    }
    else if (text == 5) {
        test1.style.display = "none";
        test2.style.display = "none";
        test3.style.display = "none";
        test4.style.display = "none";
        test5.style.display = "block";
        test6.style.display = "none";
        test7.style.display = "none";
        test8.style.display = "none";
        test9.style.display = "none";
        test10.style.display = "none";
        test11.style.display = "none";
        test12.style.display = "none";
        test13.style.display = "none";
        test14.style.display = "none";
        test15.style.display = "none";
        test16.style.display = "none";
        test17.style.display = "none";
        test18.style.display = "none";
        test19.style.display = "none";
        test20.style.display = "none";
        test21.style.display = "none";
        test22.style.display = "none";
        test23.style.display = "none";
        test24.style.display = "none";
        test25.style.display = "none";
        test26.style.display = "none";
        test27.style.display = "none";
        test28.style.display = "none";
        test29.style.display = "none";
        test30.style.display = "none";
        nightschange1.style.display = "none";
        nightschange2.style.display = "none";
        nightschange3.style.display = "none";
        nightschange4.style.display = "none";
        nightschange5.style.display = "block";
        nightschange6.style.display = "none";
        nightschange7.style.display = "none";
        nightschange8.style.display = "none";
        nightschange9.style.display = "none";
        nightschange10.style.display = "none";
        nightschange11.style.display = "none";
        nightschange12.style.display = "none";
        nightschange13.style.display = "none";
        nightschange14.style.display = "none";
        nightschange15.style.display = "none";
        nightschange16.style.display = "none";
        nightschange17.style.display = "none";
        nightschange18.style.display = "none";
        nightschange19.style.display = "none";
        nightschange20.style.display = "none";
        nightschange21.style.display = "none";
        nightschange22.style.display = "none";
        nightschange23.style.display = "none";
        nightschange24.style.display = "none";
        nightschange25.style.display = "none";
        nightschange26.style.display = "none";
        nightschange27.style.display = "none";
        nightschange28.style.display = "none";
        nightschange29.style.display = "none";
        nightschange30.style.display = "none";
        execute()
    }
    else if (text == 6) {
        test1.style.display = "none";
        test2.style.display = "none";
        test3.style.display = "none";
        test4.style.display = "none";
        test5.style.display = "none";
        test6.style.display = "block";
        test7.style.display = "none";
        test8.style.display = "none";
        test9.style.display = "none";
        test10.style.display = "none";
        test11.style.display = "none";
        test12.style.display = "none";
        test13.style.display = "none";
        test14.style.display = "none";
        test15.style.display = "none";
        test16.style.display = "none";
        test17.style.display = "none";
        test18.style.display = "none";
        test19.style.display = "none";
        test20.style.display = "none";
        test21.style.display = "none";
        test22.style.display = "none";
        test23.style.display = "none";
        test24.style.display = "none";
        test25.style.display = "none";
        test26.style.display = "none";
        test27.style.display = "none";
        test28.style.display = "none";
        test29.style.display = "none";
        test30.style.display = "none";
        nightschange1.style.display = "none";
        nightschange2.style.display = "none";
        nightschange3.style.display = "none";
        nightschange4.style.display = "none";
        nightschange5.style.display = "none";
        nightschange6.style.display = "block";
        nightschange7.style.display = "none";
        nightschange8.style.display = "none";
        nightschange9.style.display = "none";
        nightschange10.style.display = "none";
        nightschange11.style.display = "none";
        nightschange12.style.display = "none";
        nightschange13.style.display = "none";
        nightschange14.style.display = "none";
        nightschange15.style.display = "none";
        nightschange16.style.display = "none";
        nightschange17.style.display = "none";
        nightschange18.style.display = "none";
        nightschange19.style.display = "none";
        nightschange20.style.display = "none";
        nightschange21.style.display = "none";
        nightschange22.style.display = "none";
        nightschange23.style.display = "none";
        nightschange24.style.display = "none";
        nightschange25.style.display = "none";
        nightschange26.style.display = "none";
        nightschange27.style.display = "none";
        nightschange28.style.display = "none";
        nightschange29.style.display = "none";
        nightschange30.style.display = "none";
        execute()
    }
    else if (text == 7) {
        test1.style.display = "none";
        test2.style.display = "none";
        test3.style.display = "none";
        test4.style.display = "none";
        test5.style.display = "none";
        test6.style.display = "none";
        test7.style.display = "block";
        test8.style.display = "none";
        test9.style.display = "none";
        test10.style.display = "none";
        test11.style.display = "none";
        test12.style.display = "none";
        test13.style.display = "none";
        test14.style.display = "none";
        test15.style.display = "none";
        test16.style.display = "none";
        test17.style.display = "none";
        test18.style.display = "none";
        test19.style.display = "none";
        test20.style.display = "none";
        test21.style.display = "none";
        test22.style.display = "none";
        test23.style.display = "none";
        test24.style.display = "none";
        test25.style.display = "none";
        test26.style.display = "none";
        test27.style.display = "none";
        test28.style.display = "none";
        test29.style.display = "none";
        test30.style.display = "none";
        nightschange1.style.display = "none";
        nightschange2.style.display = "none";
        nightschange3.style.display = "none";
        nightschange4.style.display = "none";
        nightschange5.style.display = "none";
        nightschange6.style.display = "none";
        nightschange7.style.display = "block";
        nightschange8.style.display = "none";
        nightschange9.style.display = "none";
        nightschange10.style.display = "none";
        nightschange11.style.display = "none";
        nightschange12.style.display = "none";
        nightschange13.style.display = "none";
        nightschange14.style.display = "none";
        nightschange15.style.display = "none";
        nightschange16.style.display = "none";
        nightschange17.style.display = "none";
        nightschange18.style.display = "none";
        nightschange19.style.display = "none";
        nightschange20.style.display = "none";
        nightschange21.style.display = "none";
        nightschange22.style.display = "none";
        nightschange23.style.display = "none";
        nightschange24.style.display = "none";
        nightschange25.style.display = "none";
        nightschange26.style.display = "none";
        nightschange27.style.display = "none";
        nightschange28.style.display = "none";
        nightschange29.style.display = "none";
        nightschange30.style.display = "none";
        execute()
    }
    else if (text == 8) {
        test1.style.display = "none";
        test2.style.display = "none";
        test3.style.display = "none";
        test4.style.display = "none";
        test5.style.display = "none";
        test6.style.display = "none";
        test7.style.display = "none";
        test8.style.display = "block";
        test9.style.display = "none";
        test10.style.display = "none";
        test11.style.display = "none";
        test12.style.display = "none";
        test13.style.display = "none";
        test14.style.display = "none";
        test15.style.display = "none";
        test16.style.display = "none";
        test17.style.display = "none";
        test18.style.display = "none";
        test19.style.display = "none";
        test20.style.display = "none";
        test21.style.display = "none";
        test22.style.display = "none";
        test23.style.display = "none";
        test24.style.display = "none";
        test25.style.display = "none";
        test26.style.display = "none";
        test27.style.display = "none";
        test28.style.display = "none";
        test29.style.display = "none";
        test30.style.display = "none";
        nightschange1.style.display = "none";
        nightschange2.style.display = "none";
        nightschange3.style.display = "none";
        nightschange4.style.display = "none";
        nightschange5.style.display = "none";
        nightschange6.style.display = "none";
        nightschange7.style.display = "none";
        nightschange8.style.display = "block";
        nightschange9.style.display = "none";
        nightschange10.style.display = "none";
        nightschange11.style.display = "none";
        nightschange12.style.display = "none";
        nightschange13.style.display = "none";
        nightschange14.style.display = "none";
        nightschange15.style.display = "none";
        nightschange16.style.display = "none";
        nightschange17.style.display = "none";
        nightschange18.style.display = "none";
        nightschange19.style.display = "none";
        nightschange20.style.display = "none";
        nightschange21.style.display = "none";
        nightschange22.style.display = "none";
        nightschange23.style.display = "none";
        nightschange24.style.display = "none";
        nightschange25.style.display = "none";
        nightschange26.style.display = "none";
        nightschange27.style.display = "none";
        nightschange28.style.display = "none";
        nightschange29.style.display = "none";
        nightschange30.style.display = "none";
        execute()
    }
}
function show() {
    const unique = document.getElementById("unique");
    const change = document.getElementById("change");
    const img2 = document.getElementById("img2");
    const img3 = document.getElementById("img3");
    const img4 = document.getElementById("img4");
    const host19 = document.getElementsByClassName("host19")[0];
    const host24 = document.getElementsByClassName("host24")[0];
    unique.style.display = "block";
    unique.style.marginLeft = "31%";
    unique.marginTop = "-138%";
    if (change) {
        change.classList.add("colorchange");
        change.style.overflowX = "hidden";
    }
    host19.style.backgroundColor = "rgb(123, 123, 123)";
    host24.style.backgroundColor = "rgb(123, 123, 123)";
    img2.style.filter = "brightness(0.5)";
    img3.style.filter = "brightness(0.5)";
    img4.style.filter = "brightness(0.5)";
    unique.style.transition = "transform 0.5s ease-in-out";
    unique.style.transform = "translateY(0)";
    unique.style.animation = "SlideFromBottom 0.5s ease-in-out";
}
const hostlocation = document.getElementsByClassName("hostlocation")[0];
hostlocation.addEventListener('click', () => {
    show();
});
function nowclose() {
    const unique = document.getElementById("unique");
    const change = document.getElementById("change");
    const img2 = document.getElementById("img2");
    const img3 = document.getElementById("img3");
    const img4 = document.getElementById("img4");
    const host19 = document.getElementsByClassName("host19")[0];
    const host24 = document.getElementsByClassName("host24")[0];
    unique.style.display = "none";
    change.classList.remove("colorchange");
    change.style.overflowX = "hidden";
    host19.style.backgroundColor = "";
    host24.style.backgroundColor = "";
    img2.style.filter = "";
    img3.style.filter = "";
    img4.style.filter = "";
}
function nowcheck2() {
    const unique = document.getElementById("unique");
    const change = document.getElementById("change");
    const img2 = document.getElementById("img2");
    const img3 = document.getElementById("img3");
    const img4 = document.getElementById("img4");
    const host19 = document.getElementsByClassName("host19")[0];
    const host24 = document.getElementsByClassName("host24")[0];
    const host39 = document.getElementsByClassName("host39")[0];
    const place = document.getElementsByClassName("place")[0];
    unique.style.display = "none";
    change.style.backgroundColor = "";
    change.style.overflowX = "hidden";
    host19.style.backgroundColor = "";
    host24.style.backgroundColor = "";
    img2.style.filter = "";
    img3.style.filter = "";
    img4.style.filter = "";
    place.innerText = host39.innerText;
    place.style.marginLeft = "-28rem";
}
function show2() {
    const nowshow1 = document.getElementById("nowshow1");
    const nowshow = document.getElementById("nowshow");
    const nowshow2 = document.getElementsByClassName("nowshow2")[0];
    const item2 = document.getElementById("item2");
    const item3 = document.getElementById("item3");
    const item4 = document.getElementById("item4");
    const item6 = document.getElementById("item6");
    const item7 = document.getElementById("item7");
    const item8 = document.getElementById("item8");
    const host19 = document.getElementsByClassName("host19")[0];
    const host24 = document.getElementsByClassName("host24")[0];
    nowshow1.style.display = "none";
    nowshow.style.display = "block";
    nowshow2.style.display = "block";
    nowshow.style.marginLeft = "93%";
    nowshow.style.marginTop = "-5rem";
    nowshow.style.width = "4rem";
    nowshow.style.height = "4rem";
    item2.style.marginTop = "0rem";
    item3.style.marginTop = "-9rem";
    item4.style.marginLeft = "80%";
    item4.style.marginTop = "-21rem";
    item4.style.marginLeft = "-1%";
    item6.style.marginLeft = "-1%";
    item7.style.marginLeft = "-1rem";
    item7.style.marginTop = "5rem";
    host19.style.height = "169rem";
    host24.style.marginTop = "-16rem";

}
function show3() {
    const nowshow = document.getElementById("nowshow");
    const nowshow1 = document.getElementById("nowshow1");
    const nowshow2 = document.getElementsByClassName("nowshow2")[0];
    const item7 = document.getElementById("item7");
    const item2 = document.getElementById("item2");
    const item3 = document.getElementById("item3");
    const item4 = document.getElementById("item4");
    const host19 = document.getElementsByClassName("host19")[0];
    const host24 = document.getElementsByClassName("host24")[0];
    nowshow.style.display = "none";
    nowshow1.style.display = "block";
    nowshow1.style.marginTop = "-4rem";
    nowshow2.style.display = "none";
    item7.style.marginTop = "-6rem";
    item2.style.marginTop = "-9rem";
    item3.style.marginTop = "-13rem";
    item4.style.marginTop = "-11rem";
    host19.style.height = "188rem";
    host24.style.marginTop = "4rem";
}
function show4() {
    const nowshow6 = document.getElementsByClassName("nowshow6")[0];
    const nowshow3 = document.getElementById("nowshow3");
    const nowshow4 = document.getElementById("nowshow4");
    const item3 = document.getElementById("item3");
    const item4 = document.getElementById("item4");
    const item6 = document.getElementById("item6");
    const host19 = document.getElementsByClassName("host19")[0];
    const host24 = document.getElementsByClassName("host24")[0];
    nowshow3.style.display = "none";
    nowshow4.style.display = "block";
    nowshow4.style.marginLeft = "93%";
    nowshow4.style.marginTop = "-4rem";
    nowshow4.style.width = "4rem";
    nowshow4.style.height = "4rem";
    nowshow6.style.display = "block";
    item3.style.marginTop = "-4rem";
    item6.style.marginTop = "0rem";
    item4.style.marginTop = "-16rem";
    host19.style.height = "163rem";
    host24.style.marginTop = "-21rem";

}
function show5() {
    const item3 = document.getElementById("item3");
    const item4 = document.getElementById("item4");
    const item6 = document.getElementById("item6");
    const nowshow3 = document.getElementById("nowshow3");
    const nowshow4 = document.getElementById("nowshow4");
    const host19 = document.getElementsByClassName("host19")[0];
    const host24 = document.getElementsByClassName("host24")[0];
    const nowshow6 = document.getElementsByClassName("nowshow6")[0];
    nowshow3.style.display = "block";
    nowshow3.style.marginTop = "-4rem";
    nowshow4.style.display = "none";
    nowshow6.style.display = "none";
    item3.style.marginTop = "-16rem";
    item4.style.marginTop = "-14rem";
    item6.style.marginTop = "-4rem";
    host24.style.marginTop = "4rem";
    host19.style.height = "188rem";
}
function show6() {
    const item4 = document.getElementById("item4");
    const item5 = document.getElementById("item5");
    const item9 = document.getElementById("item9");
    const item10 = document.getElementById("item10");
    const item11 = document.getElementsByClassName("item11")[0];
    const host19 = document.getElementsByClassName("host19")[0];
    const host24 = document.getElementsByClassName("host24")[0];
    item9.style.display = "none";
    item10.style.display = "block";
    item10.style.width = "4rem";
    item10.style.height = "4rem";
    item10.style.marginTop = "-5rem";
    item10.style.marginLeft = "93%";
    item11.style.display = "block";
    item11.style.marginTop = "-12rem";
    item4.style.marginTop = "-2rem";
    item5.style.marginTop = "4rem";
    host19.style.height = "183rem";
    host24.style.marginTop = "-1rem";
}
function show7() {
    const item4 = document.getElementById("item4");
    const item5 = document.getElementById("item5");
    const item9 = document.getElementById("item9");
    const item10 = document.getElementById("item10");
    const item11 = document.getElementsByClassName("item11")[0];
    const host19 = document.getElementsByClassName("host19")[0];
    const host24 = document.getElementsByClassName("host24")[0];
    item9.style.display = "block";
    item10.style.display = "none";
    item9.style.marginTop = "-4rem";
    item11.style.display = "none";
    item4.style.marginTop = "-30rem";
    item5.style.marginTop = "-21rem";
    host19.style.height = "169rem";
    host24.style.marginTop = "-15rem";
}
function show8() {
    const item8 = document.getElementById("item8");
    const item12 = document.getElementById("item12");
    const nowshow7 = document.getElementsByClassName("nowshow7")[0];
    const host19 = document.getElementsByClassName("host19")[0];
    const host24 = document.getElementsByClassName("host24")[0];
    item8.style.display = "none";
    item12.style.display = "block";
    item12.style.width = "4rem";
    item12.style.height = "4rem";
    item12.style.marginLeft = "163%";
    item12.style.marginTop = "-4rem";
    nowshow7.style.display = "block";
    nowshow7.style.marginLeft = "-1rem";
    nowshow7.style.marginTop = "-32rem";
    host24.style.marginTop = "13rem";
    host19.style.height = "197rem";
}
function show9() {
    const item8 = document.getElementById("item8");
    const item12 = document.getElementById("item12");
    const nowshow7 = document.getElementsByClassName("nowshow7")[0];
    const host19 = document.getElementsByClassName("host19")[0];
    const host24 = document.getElementsByClassName("host24")[0];
    item8.style.display = "block";
    item8.style.marginTop = "-3rem";
    item12.style.display = "none";
    nowshow7.style.display = "none";
    host24.style.marginTop = "-32rem";
    host19.style.height = "152rem";
}
let isRegistered = false;
let isloggedIn = false;
function submit5(event) {
    event.preventDefault();
    const captureemail = document.getElementById("email-info");
    const Firstname = document.getElementById("first-name");
    const Lastname = document.getElementById("last-name");
    const Dob = document.getElementById("date-of-birth");
    const pass2 = document.getElementById("pass2");
    const Password = pass2.value.trim();
    const change = document.getElementById("change");
    const inputValue = captureemail.value.trim();
    let userlogo = document.getElementsByClassName("userlogo")[0];
    const img2 = document.getElementById("img2");
    const img3 = document.getElementById("img3");
    const img4 = document.getElementById("img4");
    const host19 = document.getElementsByClassName("host19")[0];
    const host24 = document.getElementsByClassName("host24")[0];
    const host27 = document.getElementsByClassName("host27")[0];
    const logincircle = document.getElementsByClassName("logincircle")[0];
    const dateOfBirth = Dob.value;
    const age = calculateAge(dateOfBirth);
    if (age < 18) {
        alert("Age cannot be less than 18 years");
        return;
    }
    const formdata = {
        email: captureemail.value,
        password: Password,
        Firstname: Firstname.value,
        Lastname: Lastname.value,
        Dob: Dob.value,
    }
    fetch('/registeruserdetails', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(formdata)
    })
        .then(response => response.json())
        .then(data => {
            if (data.message === 'Details are already saved.Please login') {
                alert("Details already Saved Please Login")
            }
            else if (data.message === "Details saved Successfully") {
                alert("Details Successfully Saved");
                isRegistered = true;
                document.querySelector('#loginsignupdiv').style.display = "none";
                document.querySelector('.passwordfield').style.display = "none";
                document.querySelector('#googlesection').style.display = "none";
                document.querySelector('#applesection').style.display = "none";
                document.querySelector('#loginsignupdiv').style.display = "none";
                document.querySelector('.registration-form-container').style.display = "none";
                let character = inputValue[0];
                userlogo.innerText = character;
                document.querySelector('.logincircle').style.display = "block";
                loginsignupdiv.style.display = "none";
                logincircle.style.marginLeft = "2rem";
                logincircle.style.marginTop = "5rem";
                change.style.backgroundColor = "";
                img2.style.filter = "";
                img3.style.filter = "";
                img4.style.filter = "";
                host19.style.backgroundColor = "";
                host24.style.backgroundColor = "";
                host27.style.backgroundColor = "";
            }
        })
        .catch((err) => {
            console.error(err)
        })
};