function nowstarted(event){
  event.preventDefault();
  function call(){
    fetch('/nextpage',{
        method:"get",
        headers:{
            'Content-Type':"application/json"
        }
    })
    .then(response=>{
        if (response.redirected) {
            // Redirect to the URL sent by the server
            window.location.href = response.url; 
         } else {
            throw new Error('Invalid redirect'); 
         }
        })
    .then(data=>console.log(data))
    .catch(error=>console.error(error));
  }
  call();
}

