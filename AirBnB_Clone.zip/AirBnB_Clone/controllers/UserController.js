const {
    Getdoc1, Getdoc2, Getdoc3,
    Getdoc5, Getdoc6, Getdoc7, Getdoc8, Getdoc9, Getdoc10,
    Getdoc11, Getdoc12, Getdoc13, Getdoc14, Getdoc15, Getdoc16, Getdoc17, Getdoc18,
    Getdoc19, Getdoc20, Getdoc21, Getdoc22, Getdoc23, Getdoc24, Getdoc25, Getdoc26,
    Getdoc27, Getdoc28, Getdoc29, Getdoc30, Getdoc31, Getdoc32, Getdoc33,
    Getdoc34, Getdoc35, Getdoc36, Getdoc37, Getdoc38, Getdoc39, Getdoc40,
    Getdoc41, Getdoc42, Getdoc43, Getdoc44, Getdoc45, Getdoc46, Getdoc47,
    Getdoc48, Getdoc49, Getdoc50, Getdoc51, Getdoc52, Getdoc53, Getdoc54,
    Getdoc55, Getdoc56, Getdoc57, Getdoc58, Getdoc59, Getdoc60, Getdoc61,
    Getdoc62, Getdoc63, Getdoc64, Getdoc65, Getdoc66, Getdoc67, Getdoc68,
    Getdoc69, Getdoc70, Getdoc71, Getdoc72, Getdoc73, Getdoc74, Getdoc75,
    Getdoc76, Getdoc77, Getdoc78, Getdoc79, Getdoc80, Getdoc81, Getdoc82,
    Getdoc83, Getdoc84, Getdoc85, Getdoc86, Getdoc87, Getdoc88, Getdoc89,
    Getdoc90, Getdoc91, Getdoc92, Getdoc93, Getdoc94, Getdoc95, Getdoc96,
    Getdoc97, Getdoc98, Getdoc99, Getdoc100, Getdoc101, Getdoc102, Getdoc103,
    Getdoc104, Getdoc105, Getdoc106, Getdoc107, Getdoc108, Getdoc109,
    Getdoc110, Getdoc111, Getdoc112, Getdoc113, Getdoc114, Getdoc115, Getdoc116,
    Getdoc117, Getdoc118, Getdoc119, Getdoc120, Getdoc121, Getdoc122, Getdoc123,
    Getdoc124, Getdoc125, Getdoc126, Getdoc127, Getdoc128, Getdoc129, Getdoc130,
    Getdoc131, Getdoc132, Getdoc133, Getdoc134, Getdoc135, Getdoc136, Getdoc137,
    Getdoc138, Getdoc139, Getdoc140, Getdoc141, Getdoc142, Getdoc143, Getdoc144, Getdoc145,
    Getdoc146, Getdoc147, Getdoc148, Getdoc149, Getdoc150, Getdoc151, Getdoc152, Getdoc153,
    Getdoc154, Getdoc155, Getdoc156, Getdoc157, Getdoc158, Getdoc159, Getdoc160, Getdoc161,
    Getdoc162, Getdoc163, Getdoc164, Getdoc165, Getdoc166, Getdoc167, Getdoc168, Getdoc169,
    Getdoc170, Getdoc171, Getdoc172, Getdoc173, Getdoc174, Getdoc175, Getdoc176, Getdoc177,
    Getdoc178, Getdoc179, Getdoc180, Getdoc181, Getdoc182, Getdoc183, Getdoc184, Getdoc185,
    Getdoc186, Getdoc187, Getdoc188, Getdoc189, Getdoc190, Getdoc191, Getdoc192, Getdoc193,
    Getdoc194, Getdoc195, Getdoc196, Getdoc197, Getdoc198, Getdoc199, Getdoc200, Getdoc201,
    Getdoc202, Getdoc203, Getdoc204, Getdoc205, Getdoc206, Getdoc207, Getdoc208,
    Getdoc209, Getdoc210, Getdoc211, Getdoc212, Getdoc213, Getdoc214, Getdoc215,
    Getdoc216, Getdoc217, Getdoc218, Getdoc219, Getdoc220, Getdoc221, Getdoc222, Getdoc223,
    Getdoc224, Getdoc225, Getdoc226, Getdoc227, Getdoc228, Getdoc229, Getdoc230,
    Getdoc231, Getdoc232, Getdoc233, Getdoc234, Getdoc235, Getdoc236, Getdoc237,
    Getdoc238, Getdoc239, Getdoc240, Getdoc241, Getdoc242, Getdoc243, Getdoc244, Getdoc245,
    Getdoc246, Getdoc247, Getdoc248, Getdoc249, Getdoc250, Getdoc251, Getdoc252,
    Getdoc253, Getdoc254, Getdoc255, Getdoc256, Getdoc257, Getdoc258, Getdoc259,
    getpropertyimages, getpropertyimageswithid,
    Getdoc489, Getdoc490, Getdoc491, Getdoc492, Getdoc493, Getdoc494, Getdoc495, Getdoc496, Getdoc497, Getdoc498,
    Getdoc499, Getdoc500, Getdoc501, Getdoc502, Getdoc503, Getdoc504, Getdoc505, Getdoc506, Getdoc507, Getdoc508,
    Getdoc509, Getdoc510, Getdoc511, Getdoc512, Getdoc513, Getdoc514, Getdoc515, Getdoc516, Getdoc517, Getdoc518,
    Getdoc519, Getdoc520, Getdoc521, Getdoc522, Getdoc523, Getdoc524, Getdoc525, Getdoc526, Getdoc527, Getdoc528,
    Getdoc529, Getdoc530, Getdoc531, Getdoc532, Getdoc533, Getdoc534, Getdoc535, Getdoc536, Getdoc537, Getdoc538,
    Getdoc539, Getdoc540, Getdoc541, Getdoc542, Getdoc543, Getdoc544, Getdoc545, Getdoc546, Getdoc547, Getdoc548,
    Getdoc549, Getdoc550, Getdoc551, Getdoc552, Getdoc553, Getdoc554, Getdoc555, Getdoc556, Getdoc557, Getdoc558,
    Getdoc559, Getdoc560, Getdoc561, Getdoc562, Getdoc563, Getdoc564, Getdoc565, Getdoc566, Getdoc567, Getdoc568,
    Getdoc569, Getdoc570, Getdoc571, Getdoc572, Getdoc573, Getdoc574, Getdoc575, Getdoc576, Getdoc577, Getdoc578,
    Getdoc579, Getdoc580, Getdoc581, Getdoc582, Getdoc583, Getdoc584, Getdoc585, Getdoc586, Getdoc587, Getdoc588,
    Getdoc590, Getdoc591, Getdoc592, Getdoc593, Getdoc594, Getdoc595, Getdoc596, Getdoc597, Getdoc598,
    Getdoc599, Getdoc600, Getdoc601, Getdoc602, Getdoc603, Getdoc604, Getdoc605, Getdoc606, Getdoc607, Getdoc608,
    Getdoc609, Getdoc610, Getdoc611, Getdoc612, Getdoc613, Getdoc614, Getdoc615, Getdoc616, Getdoc617, Getdoc618, Getdoc619,
    Getdoc620, Getdoc621, Getdoc622, Getdoc623, Getdoc624, Getdoc625, Getdoc626, Getdoc627, Getdoc628, Getdoc629, Getdoc630, Getdoc631,
    Getdoc632, Getdoc633, Getdoc634, Getdoc635, Getdoc636, Getdoc637, Getdoc638, Getdoc639, Getdoc640, Getdoc641, Getdoc642, Getdoc643,
    Getdoc644, Getdoc645, Getdoc646, Getdoc647, Getdoc648, Getdoc649, Getdoc650, Getdoc652, Getdoc653,
    Getdoc654, Getdoc655, Getdoc656, Getdoc657, Getdoc658, Getdoc659, Getdoc660, Getdoc661, Getdoc662, Getdoc663, Getdoc664,
    Getdoc665, Getdoc666, Getdoc667, Getdoc668, Getdoc669, Getdoc670, Getdoc671, Getdoc672, Getdoc673, Getdoc674,
    Getdoc675, Getdoc676, Getdoc677, Getdoc678, Getdoc679, Getdoc680, Getdoc681, Getdoc682, Getdoc683, Getdoc684, Getdoc685,
    Getdoc686, Getdoc687, Getdoc688, Getdoc689, Getdoc690, Getdoc691, Getdoc692, PictureModel,
    Getdoc693, Getdoc694, Getdoc695, Getdoc696, Getdoc697, Getdoc698, Getdoc699, Getdoc700, Getdoc701,
    Getdoc702, Getdoc703, Getdoc704, Getdoc705, Getdoc706, Getdoc707, Getdoc708, Getdoc709, Getdoc710, Getdoc711, Getdoc712, Getdoc713, Getdoc714, Getdoc715,
    Getdoc716, Getdoc717, Getdoc718, Getdoc719, Getdoc720, Getdoc721, Getdoc722, Getdoc723, Getdoc724, Getdoc725, Getdoc726, Getdoc727, Getdoc728,
    Getdoc729, Getdoc730, Getdoc731, Getdoc732, Getdoc733, Getdoc734, Getdoc735, Getdoc736, Getdoc737, Getdoc738,
    Getdoc739, Getdoc740, Getdoc741, Getdoc742, Getdoc743, Getdoc744, Getdoc745, Getdoc746, Getdoc747, Getdoc748, Getdoc749, Getdoc750,
    Getdoc751, Getdoc752, Getdoc753, Getdoc754, Getdoc755, Getdoc756, Getdoc757, Getdoc758, Getdoc759, Getdoc760, Getdoc761, Getdoc762, Getdoc763,
    Getdoc764, Getdoc765, Getdoc766, Getdoc767, Getdoc768, Getdoc769, Getdoc771, Getdoc772, Getdoc773, Getdoc774, Getdoc775, Getdoc776,
    Getdoc777, Getdoc778, Getdoc779, Getdoc780, Getdoc781, Getdoc782, Getdoc783, Getdoc784, Getdoc785, Getdoc786, Getdoc787, Getdoc788, Getdoc789,
    Getdoc790, Getdoc791, Getdoc792, Getdoc793, Getdoc794, Getdoc795, Getdoc796, Getdoc797, Getdoc798, Getdoc799, Getdoc800, Getdoc801,
    Getdoc802, Getdoc803, Getdoc804, Getdoc805, Getdoc806, Getdoc807, Getdoc808, Getdoc809, Getdoc810, Getdoc811, Getdoc812,
    Getdoc813, Getdoc814, Getdoc815, Getdoc816, Getdoc817, Getdoc818, Getdoc819, Getdoc820, finddetails, 
    SaveData,Form,findedData } = require('../models/data.js');
const jwt = require('jsonwebtoken');
const path = require("path");
const multer = require("multer");
const { createSecretKey } = require('crypto');
const storage = multer.diskStorage({
    destination: path.join(__dirname, 'public/images'),
    filename: (req, file, cb) => {
        cb(null, Date.now() + path.extname(file.originalname));
    }
});
const upload = multer({
    storage: storage,
    fileFilter: (req, file, cb) => {
        const allowedMimeTypes = ['image/jpeg', 'image/jpg', 'image/png', 'image/gif'];
        if (allowedMimeTypes.includes(file.mimetype)) {
            cb(null, true);
        } else {
            cb(new Error("Only jpeg, jpg, png, and gif image extensions are allowed"));
        }
    }
});
exports.fun1 = async (req, res) => {
    const x = await Getdoc1();
    const d = await getpropertyimages();
    const y = await Getdoc2();
    const z = await Getdoc3();
    const u = await Getdoc5();
    const w = await Getdoc6();
    const r = await Getdoc7();
    const y1 = await Getdoc8();
    const p1 = await Getdoc9();
    const h1 = await Getdoc10();
    const e1 = await Getdoc11();
    const f1 = await Getdoc12();
    const g1 = await Getdoc13();
    const i1 = await Getdoc14();
    const l1 = await Getdoc15();
    const m1 = await Getdoc16();
    const n1 = await Getdoc17();
    const o1 = await Getdoc18();
    const q1 = await Getdoc19();
    const v1 = await Getdoc20();
    const ab1 = await Getdoc21();
    const bc1 = await Getdoc22();
    const cd1 = await Getdoc23();
    const de1 = await Getdoc24();
    const ef1 = await Getdoc25();
    const gh1 = await Getdoc26();
    const re1 = await Getdoc27();
    const em1 = await Getdoc28();
    const el = await Getdoc29();
    const rt1 = await Getdoc30();
    const cx1 = await Getdoc31();
    const lm1 = await Getdoc32();
    const mn1 = await Getdoc33();
    const dbf1 = await Getdoc34();
    const dbf2 = await Getdoc35();
    const dbf3 = await Getdoc36();
    const dbf4 = await Getdoc37();
    const dbf5 = await Getdoc38();
    const dbf6 = await Getdoc39();
    const dbf7 = await Getdoc40();
    const dbf8 = await Getdoc41();
    const dbf9 = await Getdoc42();
    const dbf10 = await Getdoc43();
    const dbf11 = await Getdoc44();
    const dbf12 = await Getdoc45();
    const dbf13 = await Getdoc46();
    const dbf14 = await Getdoc47();
    const dbf15 = await Getdoc48();
    const dbf16 = await Getdoc49();
    const dbf17 = await Getdoc50();
    const dbf18 = await Getdoc51();
    const dbf19 = await Getdoc52();
    const dbf20 = await Getdoc53();
    const dbf21 = await Getdoc54();
    const dbf22 = await Getdoc55();
    const dbf23 = await Getdoc56();
    const dbf24 = await Getdoc57();
    const dbf25 = await Getdoc58();
    const dbf26 = await Getdoc59();
    const dbf27 = await Getdoc60();
    const dbf28 = await Getdoc61();
    const dbf29 = await Getdoc62();
    const dbf30 = await Getdoc63();
    const dbf31 = await Getdoc64();
    const dbf32 = await Getdoc65();
    const dbf33 = await Getdoc66();
    const dbf34 = await Getdoc67();
    const dbf35 = await Getdoc68();
    const dbf36 = await Getdoc69();
    const dbf37 = await Getdoc70();
    const dbf38 = await Getdoc71();
    const dbf39 = await Getdoc72();
    const dbf40 = await Getdoc73();
    const dbf41 = await Getdoc74();
    const dbf42 = await Getdoc75();
    const dbf43 = await Getdoc76();
    const dbf44 = await Getdoc77();
    const dbf45 = await Getdoc78();
    const dbf46 = await Getdoc79();
    const dbf47 = await Getdoc80();
    const dbf48 = await Getdoc81();
    const dbf49 = await Getdoc82();
    const dbf50 = await Getdoc83();
    const dbf51 = await Getdoc84();
    const dbf52 = await Getdoc85();
    const dbf53 = await Getdoc86();
    const dbf54 = await Getdoc87();
    const dbf55 = await Getdoc88();
    const dbf56 = await Getdoc89();
    const dbf57 = await Getdoc90();
    const dbf58 = await Getdoc91();
    const dbf59 = await Getdoc92();
    const dbf60 = await Getdoc93();
    const dbf61 = await Getdoc94();
    const dbf62 = await Getdoc95();
    const dbf63 = await Getdoc96();
    const dbf64 = await Getdoc97();
    const dbf65 = await Getdoc98();
    const dbf66 = await Getdoc99();
    const dbf67 = await Getdoc100();
    const dbf68 = await Getdoc101();
    const dbf69 = await Getdoc102();
    const dbf70 = await Getdoc103();
    const dbf71 = await Getdoc104();
    const dbf72 = await Getdoc105();
    const dbf73 = await Getdoc106();
    const dbf74 = await Getdoc107();
    const dbf75 = await Getdoc108();
    const dbf76 = await Getdoc109();
    const dbf77 = await Getdoc110();
    const dbf78 = await Getdoc111();
    const dbf79 = await Getdoc112();
    const dbf80 = await Getdoc113();
    const dbf81 = await Getdoc114();
    const dbf82 = await Getdoc115();
    const dbf83 = await Getdoc116();
    const dbf84 = await Getdoc117();
    const dbf85 = await Getdoc118();
    const dbf86 = await Getdoc119();
    const dbf87 = await Getdoc120();
    const dbf88 = await Getdoc121();
    const dbf89 = await Getdoc122();
    const dbf90 = await Getdoc123();
    const dbf91 = await Getdoc124();
    const dbf92 = await Getdoc125();
    const dbf93 = await Getdoc126();
    const lz1 = await Getdoc127();
    const lz2 = await Getdoc128();
    const lz3 = await Getdoc129();
    const lz4 = await Getdoc130();
    const lz5 = await Getdoc131();
    const lz6 = await Getdoc132();
    const lz7 = await Getdoc133();
    const lz8 = await Getdoc134();
    const lz9 = await Getdoc135();
    const lz10 = await Getdoc136();
    const lz11 = await Getdoc137();
    const lz12 = await Getdoc138();
    const lz13 = await Getdoc139();
    const lz14 = await Getdoc140();
    const lz15 = await Getdoc141();
    const lz16 = await Getdoc142();
    const lz17 = await Getdoc143();
    const lz18 = await Getdoc144();
    const lz19 = await Getdoc145();
    const lz20 = await Getdoc146();
    const lz21 = await Getdoc147();
    const lz22 = await Getdoc148();
    const lz23 = await Getdoc149();
    const lz24 = await Getdoc150();
    const lz25 = await Getdoc151();
    const lz26 = await Getdoc152();
    const lz27 = await Getdoc153();
    const lz28 = await Getdoc154();
    const lz29 = await Getdoc155();
    const lz30 = await Getdoc156();
    const lz31 = await Getdoc157();
    const lz32 = await Getdoc158();
    const lz33 = await Getdoc159();
    const lz34 = await Getdoc160();
    const lz35 = await Getdoc161();
    const lz36 = await Getdoc162();
    const lz37 = await Getdoc163();
    const lz38 = await Getdoc164();
    const lz39 = await Getdoc165();
    const lz40 = await Getdoc166();
    const lz41 = await Getdoc167();
    const lz42 = await Getdoc168();
    const lz43 = await Getdoc169();
    const lz44 = await Getdoc170();
    const lz45 = await Getdoc171();
    const lz46 = await Getdoc172();
    const lz47 = await Getdoc173();
    const lz48 = await Getdoc174();
    const lz49 = await Getdoc175();
    const lz50 = await Getdoc176();
    const lz51 = await Getdoc177();
    const lz52 = await Getdoc178();
    const lz53 = await Getdoc179();
    const lz54 = await Getdoc180();
    const lz55 = await Getdoc181();
    const lz56 = await Getdoc182();
    const lz57 = await Getdoc183();
    const lz58 = await Getdoc184();
    const lz59 = await Getdoc185();
    const lz60 = await Getdoc186();
    const lz61 = await Getdoc187();
    const lz62 = await Getdoc188();
    const lz63 = await Getdoc189();
    const lz64 = await Getdoc190();
    const lz65 = await Getdoc191();
    const lz66 = await Getdoc192();
    const lz67 = await Getdoc193();
    const lz68 = await Getdoc194();
    const lz69 = await Getdoc195();
    const lz70 = await Getdoc196();
    const lz71 = await Getdoc197();
    const lz72 = await Getdoc198();
    const lz73 = await Getdoc199();
    const lz74 = await Getdoc200();
    const lz75 = await Getdoc201();
    const lz76 = await Getdoc202();
    const lz77 = await Getdoc203();
    const lz78 = await Getdoc204();
    const lz79 = await Getdoc205();
    const lz80 = await Getdoc206();
    const lz81 = await Getdoc207();
    const lz82 = await Getdoc208();
    const lz83 = await Getdoc209();
    const lz84 = await Getdoc210();
    const lz85 = await Getdoc211();
    const lz86 = await Getdoc212();
    const lz87 = await Getdoc213();
    const lz88 = await Getdoc214();
    const lz89 = await Getdoc215();
    const lz90 = await Getdoc216();
    const lz91 = await Getdoc217();
    const lz92 = await Getdoc218();
    const lz93 = await Getdoc219();
    const lz94 = await Getdoc220();
    const lz95 = await Getdoc221();
    const lz96 = await Getdoc222();
    const lz97 = await Getdoc223();
    const lz98 = await Getdoc224();
    const lz99 = await Getdoc225();
    const lz100 = await Getdoc226();
    const lz101 = await Getdoc227();
    const lz102 = await Getdoc228();
    const lz103 = await Getdoc229();
    const lz104 = await Getdoc230();
    const lz105 = await Getdoc231();
    const lz106 = await Getdoc232();
    const lz107 = await Getdoc233();
    const lz108 = await Getdoc234();
    const lz109 = await Getdoc235();
    const lz110 = await Getdoc236();
    const lz111 = await Getdoc237();
    const lz112 = await Getdoc238();
    const lz113 = await Getdoc239();
    const lz114 = await Getdoc240();
    const lz115 = await Getdoc241();
    const lz116 = await Getdoc242();
    const lz117 = await Getdoc243();
    const lz118 = await Getdoc244();
    const lz119 = await Getdoc245();
    const lz120 = await Getdoc246();
    const lz121 = await Getdoc247();
    const lz122 = await Getdoc248();
    const lz123 = await Getdoc249();
    const lz124 = await Getdoc250();
    const lz125 = await Getdoc251();
    const lz126 = await Getdoc252();
    const lz127 = await Getdoc253();
    const lz128 = await Getdoc254();
    const lz129 = await Getdoc255();
    const lz130 = await Getdoc256();
    const lz131 = await Getdoc257();
    const lz132 = await Getdoc258();
    const lz133 = await Getdoc259();
    res.render("landingpage", {
        a: x,
        b: d,
        c: y,
        j: z,
        u1: u,
        w1: w,
        r1: r,
        c1: y1,
        d1: p1,
        h: h1,
        e: e1,
        f: f1,
        g: g1,
        i: i1,
        l: l1,
        m: m1,
        n: n1,
        o: o1,
        q: q1,
        v: v1,
        ab: ab1,
        bc: bc1,
        cd: cd1,
        de: de1,
        ef: ef1,
        gh: gh1,
        re: re1,
        em: em1,
        el1: el,
        rt: rt1,
        cx: cx1,
        lm: lm1,
        mn: mn1,
        db1: dbf1,
        db2: dbf2,
        db3: dbf3,
        db4: dbf4,
        db5: dbf5,
        db6: dbf6,
        db7: dbf7,
        db8: dbf8,
        db9: dbf9,
        db10: dbf10,
        db11: dbf11,
        db12: dbf12,
        db13: dbf13,
        db14: dbf14,
        db15: dbf15,
        db16: dbf16,
        db17: dbf17,
        db18: dbf18,
        db19: dbf19,
        db20: dbf20,
        db21: dbf21,
        db22: dbf22,
        db23: dbf23,
        db24: dbf24,
        db25: dbf25,
        db26: dbf26,
        db27: dbf27,
        db28: dbf28,
        db29: dbf29,
        db30: dbf30,
        db31: dbf31,
        db32: dbf32,
        db33: dbf33,
        db34: dbf34,
        db35: dbf35,
        db36: dbf36,
        db37: dbf37,
        db38: dbf38,
        db39: dbf39,
        db40: dbf40,
        db41: dbf41,
        db42: dbf42,
        db43: dbf43,
        db44: dbf44,
        db45: dbf45,
        db46: dbf46,
        db47: dbf47,
        db48: dbf48,
        db49: dbf49,
        db50: dbf50,
        db51: dbf51,
        db52: dbf52,
        db53: dbf53,
        db54: dbf54,
        db55: dbf55,
        db56: dbf56,
        db57: dbf57,
        db58: dbf58,
        db59: dbf59,
        db60: dbf60,
        db61: dbf61,
        db62: dbf62,
        db63: dbf63,
        db64: dbf64,
        db65: dbf65,
        db66: dbf66,
        db67: dbf67,
        db68: dbf68,
        db69: dbf69,
        db70: dbf70,
        db71: dbf71,
        db72: dbf72,
        db73: dbf73,
        db74: dbf74,
        db75: dbf75,
        db76: dbf76,
        db77: dbf77,
        db78: dbf78,
        db79: dbf79,
        db80: dbf80,
        db81: dbf81,
        db82: dbf82,
        db83: dbf83,
        db84: dbf84,
        db85: dbf85,
        db86: dbf86,
        db87: dbf87,
        db88: dbf88,
        db89: dbf89,
        db90: dbf90,
        db91: dbf91,
        db92: dbf92,
        db93: dbf93,
        lz: lz1,
        jz: lz2,
        kz: lz3,
        db94: lz4,
        db95: lz5,
        db96: lz6,
        db97: lz7,
        db98: lz8,
        db99: lz9,
        db100: lz10,
        db101: lz11,
        db94: lz4,
        db95: lz5,
        db96: lz6,
        db97: lz7,
        db98: lz8,
        db99: lz9,
        db100: lz10,
        db101: lz11,
        db94: lz4,
        db95: lz5,
        db96: lz6,
        db97: lz7,
        db98: lz8,
        db99: lz9,
        db100: lz10,
        db101: lz11,
        db102: lz12,
        db103: lz13,
        db104: lz14,
        db105: lz15,
        db106: lz16,
        db107: lz17,
        db108: lz18,
        db109: lz19,
        db110: lz20,
        db111: lz21,
        db112: lz22,
        db113: lz23,
        db114: lz24,
        db115: lz25,
        db116: lz26,
        db117: lz27,
        db118: lz28,
        db119: lz29,
        db120: lz30,
        db121: lz31,
        db122: lz32,
        db123: lz33,
        db124: lz34,
        db125: lz35,
        db126: lz36,
        db127: lz37,
        db128: lz38,
        db129: lz39,
        db130: lz40,
        db131: lz41,
        db132: lz42,
        db133: lz43,
        db134: lz44,
        db135: lz45,
        db136: lz46,
        db137: lz47,
        db138: lz48,
        db139: lz49,
        db140: lz50,
        db141: lz51,
        db142: lz52,
        db143: lz53,
        db144: lz54,
        db145: lz55,
        db146: lz56,
        db147: lz57,
        db148: lz58,
        db149: lz59,
        db150: lz60,
        db151: lz61,
        db152: lz62,
        db153: lz63,
        db154: lz64,
        db155: lz65,
        db156: lz66,
        db157: lz67,
        db158: lz68,
        db159: lz69,
        db160: lz70,
        db161: lz71,
        db162: lz72,
        db163: lz73,
        db164: lz74,
        db165: lz75,
        db166: lz76,
        db165: lz77,
        db166: lz78,
        db167: lz79,
        db168: lz80,
        db169: lz81,
        db170: lz82,
        db171: lz83,
        db172: lz84,
        db173: lz85,
        db174: lz86,
        db175: lz87,
        db176: lz88,
        db177: lz89,
        db178: lz90,
        db179: lz91,
        db180: lz92,
        db181: lz93,
        db182: lz94,
        db183: lz95,
        db184: lz96,
        db185: lz97,
        db186: lz98,
        db187: lz99,
        db188: lz100,
        db189: lz101,
        db190: lz102,
        db191: lz103,
        db192: lz104,
        db193: lz105,
        db194: lz106,
        db195: lz107,
        db196: lz108,
        db197: lz109,
        db198: lz110,
        db199: lz111,
        db200: lz112,
        db201: lz113,
        db202: lz114,
        db203: lz115,
        db204: lz116,
        db205: lz117,
        db206: lz118,
        db207: lz119,
        db208: lz120,
        db209: lz121,
        db210: lz122,
        db211: lz123,
        db212: lz124,
        db213: lz125,
        db214: lz126,
        db215: lz127,
        db216: lz128,
        db217: lz129,
        db218: lz130,
        db219: lz131,
        db220: lz132,
        db221: lz133, 
    })
}
exports.fun2 = async (req, res) => {
    const db1 = await Getdoc489();
    const db2 = await Getdoc490();
    const db3 = await Getdoc491();
    const db4 = await Getdoc612();
    const db5 = await Getdoc492();
    const db6 = await Getdoc493();
    const db7 = await Getdoc494();
    const db8 = await Getdoc495();
    const db9 = await Getdoc496();
    const db10 = await Getdoc555();
    const db11 = await Getdoc556();
    const db12 = await Getdoc557();
    const db14 = await Getdoc559();
    const db15 = await Getdoc560();
    const db16 = await Getdoc561();
    const db17 = await Getdoc562();
    const db18 = await Getdoc563();
    const db19 = await Getdoc564();
    const db20 = await Getdoc565();
    const db21 = await Getdoc566();
    const db22 = await Getdoc567();
    const db23 = await Getdoc568();
    const db25 = await Getdoc613();
    const db26 = await Getdoc570();
    const db27 = await Getdoc571();
    const db28 = await Getdoc572();
    const db29 = await Getdoc573();
    const db30 = await Getdoc574();
    const db31 = await Getdoc575();
    const db32 = await Getdoc576();
    const db33 = await Getdoc577();
    const db34 = await Getdoc578();
    const db35 = await Getdoc579();
    const db36 = await Getdoc580();
    const db37 = await Getdoc581();
    const db38 = await Getdoc582();
    const db39 = await Getdoc583();
    const db40 = await Getdoc584();
    const db41 = await Getdoc585();
    const db42 = await Getdoc586();
    const db43 = await Getdoc587();
    const db44 = await Getdoc588();
    const db45 = await Getdoc590();
    const db46 = await Getdoc591();
    const db47 = await Getdoc592();
    const db48 = await Getdoc593();
    const db49 = await Getdoc594();
    const db50 = await Getdoc569();
    const db51 = await Getdoc595();
    const db52 = await Getdoc596();
    const db53 = await Getdoc597();
    const db54 = await Getdoc598();
    const db55 = await Getdoc599();
    const db56 = await Getdoc600();
    const db57 = await Getdoc601();
    const db58 = await Getdoc602();
    const db59 = await Getdoc603();
    const db60 = await Getdoc606();
    const db61 = await Getdoc607();
    const db62 = await Getdoc609();
    const db63 = await Getdoc610();
    const db64 = await Getdoc611();
    const db65 = await Getdoc612();
    const db66 = await Getdoc613();
    const db67 = await Getdoc615();
    const db68 = await Getdoc616();
    const db69 = await Getdoc617();
    const db70 = await Getdoc618();
    const db71 = await Getdoc619();
    const db72 = await Getdoc620();
    const db73 = await Getdoc621();
    const db74 = await Getdoc622();
    const db75 = await Getdoc623();
    const db76 = await Getdoc624();
    const db77 = await Getdoc625();
    const db78 = await Getdoc626();
    const db79 = await Getdoc627();
    const db80 = await Getdoc628();
    const db81 = await Getdoc629();
    const db82 = await Getdoc630();
    const db83 = await Getdoc631();
    const db84 = await Getdoc632();
    const db85 = await Getdoc633();
    const db86 = await Getdoc634();
    const db87 = await Getdoc635();
    const db88 = await Getdoc636();
    const db89 = await Getdoc637();
    const db90 = await Getdoc638();
    const db91 = await Getdoc639();
    const db92 = await Getdoc640();
    const db93 = await Getdoc641();
    const db94 = await Getdoc642();
    const db95 = await Getdoc643();
    const db96 = await Getdoc644();
    const db97 = await Getdoc497();
    const db98 = await Getdoc494();
    const db99 = await Getdoc499();
    const db100 = await Getdoc498();
    const db101 = await Getdoc501();
    const db102 = await Getdoc500();
    const db103 = await Getdoc502();
    const db104 = await Getdoc503();
    const db105 = await Getdoc504();
    const db106 = await Getdoc505();
    const db107 = await Getdoc506();
    const db108 = await Getdoc507();
    const db109 = await Getdoc508();
    const db110 = await Getdoc509();
    const db111 = await Getdoc510();
    const db112 = await Getdoc511();
    const db113 = await Getdoc512();
    const db114 = await Getdoc513();
    const db115 = await Getdoc514();
    const db116 = await Getdoc515();
    const db117 = await Getdoc516();
    const db118 = await Getdoc517();
    const db119 = await Getdoc518();
    const db120 = await Getdoc519();
    const db121 = await Getdoc520();
    const db122 = await Getdoc521();
    const db123 = await Getdoc522();
    const db124 = await Getdoc523();
    const db125 = await Getdoc524();
    const db126 = await Getdoc525();
    const db127 = await Getdoc526();
    const db128 = await Getdoc527();
    const db129 = await Getdoc528();
    const db130 = await Getdoc529();
    const db131 = await Getdoc530();
    const db132 = await Getdoc531();
    const db133 = await Getdoc532();
    const db134 = await Getdoc533();
    const db135 = await Getdoc534();
    const db136 = await Getdoc535();
    const db137 = await Getdoc536();
    const db138 = await Getdoc537();
    const db139 = await Getdoc538();
    const db140 = await Getdoc539();
    const db141 = await Getdoc540();
    const db142 = await Getdoc541();
    const db143 = await Getdoc542();
    const db144 = await Getdoc543();
    const db145 = await Getdoc544();
    const db146 = await Getdoc545();
    const db147 = await Getdoc546();
    const db148 = await Getdoc547();
    const db149 = await Getdoc548();
    const db150 = await Getdoc549();
    const db151 = await Getdoc550();
    const db152 = await Getdoc551();
    const db153 = await Getdoc552();
    const db154 = await Getdoc553();
    const db155 = await Getdoc554();
    const db156 = await Getdoc555();
    const db157 = await Getdoc645();
    const db158 = await Getdoc646();
    const db159 = await Getdoc647();
    const db160 = await Getdoc604();
    const db161 = await Getdoc605();
    const db162 = await Getdoc648();
    const db163 = await Getdoc649();
    const db164 = await Getdoc653();
    const db165 = await Getdoc650();
    const db166 = await Getdoc652();
    const db167 = await Getdoc614();
    const db168 = await Getdoc608();
    const db169 = await Getdoc494();
    const db170 = await Getdoc497();
    const db171 = await Getdoc495();
    res.render("propertylogin", {
        a: db1,
        b: db2,
        c: db3,
        d: db4,
        e: db5,
        f: db6,
        g: db7,
        h: db8,
        i: db9,
        j: db10,
        k: db11,
        l: db12,
        n: db14,
        o: db15,
        p: db16,
        q: db17,
        r: db19,
        s: db21,
        t: db18,
        u: db20,
        v: db22,
        w: db23,
        x: db26,
        y: db25,
        z: db27,
        doc1: db28,
        doc2: db29,
        doc3: db30,
        doc4: db31,
        doc5: db32,
        doc6: db33,
        doc7: db34,
        doc8: db35,
        doc9: db36,
        doc10: db37,
        doc11: db38,
        doc12: db39,
        doc13: db40,
        doc14: db41,
        doc15: db42,
        doc16: db43,
        doc17: db44,
        doc18: db45,
        doc19: db46,
        doc20: db47,
        doc21: db48,
        doc22: db49,
        doc23: db50,
        doc24: db51,
        doc25: db52,
        doc26: db53,
        doc27: db54,
        doc28: db55,
        doc29: db56,
        doc30: db57,
        doc31: db58,
        doc32: db59,
        doc33: db60,
        doc34: db61,
        doc35: db62,
        doc36: db63,
        doc37: db64,
        doc38: db65,
        doc39: db66,
        doc40: db67,
        doc41: db68,
        doc42: db69,
        doc43: db70,
        doc44: db71,
        doc45: db72,
        doc46: db73,
        doc47: db74,
        doc48: db75,
        doc49: db76,
        doc50: db77,
        doc51: db78,
        doc52: db79,
        doc53: db80,
        doc54: db81,
        doc55: db82,
        doc56: db83,
        doc57: db84,
        doc58: db85,
        doc59: db86,
        doc60: db87,
        doc61: db88,
        doc62: db89,
        doc63: db90,
        doc64: db91,
        doc65: db92,
        doc66: db93,
        doc67: db94,
        doc68: db95,
        doc69: db96,
        doc70: db97,
        doc71: db98,
        doc72: db99,
        doc73: db100,
        doc74: db101,
        doc75: db102,
        doc76: db103,
        doc77: db104,
        doc78: db105,
        doc79: db106,
        doc80: db107,
        doc81: db108,
        doc82: db109,
        doc83: db110,
        doc84: db111,
        doc85: db112,
        doc86: db113,
        doc87: db114,
        doc88: db115,
        doc89: db116,
        doc90: db117,
        doc91: db118,
        doc92: db119,
        doc93: db120,
        doc94: db121,
        doc95: db122,
        doc96: db123,
        doc97: db124,
        doc98: db125,
        doc99: db126,
        doc100: db127,
        doc101: db128,
        doc102: db129,
        doc103: db130,
        doc104: db131,
        doc105: db132,
        doc106: db133,
        doc107: db134,
        doc108: db135,
        doc109: db136,
        doc110: db137,
        doc111: db138,
        doc112: db139,
        doc113: db140,
        doc114: db141,
        doc115: db142,
        doc116: db143,
        doc117: db144,
        doc118: db145,
        doc119: db146,
        doc120: db147,
        doc121: db148,
        doc122: db149,
        doc123: db150,
        doc124: db151,
        doc125: db152,
        doc126: db153,
        doc127: db154,
        doc128: db155,
        doc129: db156,
        doc130: db157,
        doc131: db158,
        doc132: db159,
        doc133: db160,
        doc134: db161,
        doc135: db162,
        doc136: db163,
        doc137: db164,
        doc138: db165,
        doc139: db166,
        doc140: db167,
        doc141: db168,
        doc142: db169,
        doc143: db170,
        doc144: db171,
    });
}

exports.fun3 = async (req, res) => {
    const hotelid = req.params.id;
    const hoteldatawithid = await getpropertyimageswithid(hotelid);
    const x = await Getdoc1();
    const y = await Getdoc2();
    const z = await Getdoc3();
    const u = await Getdoc5();
    const w = await Getdoc6();
    const r = await Getdoc7();
    const y1 = await Getdoc8();
    const p1 = await Getdoc9();
    const h1 = await Getdoc10();
    const e1 = await Getdoc11();
    const f1 = await Getdoc12();
    const g1 = await Getdoc13();
    const i1 = await Getdoc14();
    const l1 = await Getdoc15();
    const m1 = await Getdoc16();
    const n1 = await Getdoc17();
    const o1 = await Getdoc18();
    const q1 = await Getdoc19();
    const v1 = await Getdoc20();
    const ab1 = await Getdoc21();
    const bc1 = await Getdoc22();
    const cd1 = await Getdoc23();
    const de1 = await Getdoc24();
    const ef1 = await Getdoc25();
    const gh1 = await Getdoc26();
    const re1 = await Getdoc27();
    const em1 = await Getdoc28();
    const el = await Getdoc29();
    const rt1 = await Getdoc30();
    const cx1 = await Getdoc31();
    const lm1 = await Getdoc32();
    const mn1 = await Getdoc33();
    const lz1 = await Getdoc127();
    const lz2 = await Getdoc128();
    const lz3 = await Getdoc129();
    const lz4 = await Getdoc130();
    const lz5 = await Getdoc131();
    const lz6 = await Getdoc132();
    const lz7 = await Getdoc133();
    const lz8 = await Getdoc134();
    const lz9 = await Getdoc135();
    const lz10 = await Getdoc136();
    const lz11 = await Getdoc137();
    const lz12 = await Getdoc138();
    const lz13 = await Getdoc139();
    const lz14 = await Getdoc140();
    const lz15 = await Getdoc141();
    const lz16 = await Getdoc142();
    const lz17 = await Getdoc143();
    const lz18 = await Getdoc144();
    const lz19 = await Getdoc145();
    const lz20 = await Getdoc146();
    const lz21 = await Getdoc147();
    const lz22 = await Getdoc148();
    const lz23 = await Getdoc149();
    const lz24 = await Getdoc150();
    const lz25 = await Getdoc151();
    const lz26 = await Getdoc152();
    const lz27 = await Getdoc153();
    const lz28 = await Getdoc154();
    const lz29 = await Getdoc155();
    const lz30 = await Getdoc156();
    const lz31 = await Getdoc157();
    const lz32 = await Getdoc158();
    const lz33 = await Getdoc159();
    const lz34 = await Getdoc160();
    const lz35 = await Getdoc161();
    const lz36 = await Getdoc162();
    const lz37 = await Getdoc163();
    const lz38 = await Getdoc164();
    const lz39 = await Getdoc165();
    const lz40 = await Getdoc166();
    const lz41 = await Getdoc167();
    const lz42 = await Getdoc168();
    const lz43 = await Getdoc169();
    const lz44 = await Getdoc170();
    const lz45 = await Getdoc171();
    const lz46 = await Getdoc172();
    const lz47 = await Getdoc173();
    const lz48 = await Getdoc174();
    const lz49 = await Getdoc175();
    const lz50 = await Getdoc176();
    const lz51 = await Getdoc177();
    const lz52 = await Getdoc178();
    const lz53 = await Getdoc179();
    const lz54 = await Getdoc180();
    const lz55 = await Getdoc181();
    const lz56 = await Getdoc182();
    const lz57 = await Getdoc183();
    const lz58 = await Getdoc184();
    const lz59 = await Getdoc185();
    const lz60 = await Getdoc186();
    const lz61 = await Getdoc187();
    const lz62 = await Getdoc188();
    const lz63 = await Getdoc189();
    const lz64 = await Getdoc190();
    const lz65 = await Getdoc191();
    const lz66 = await Getdoc192();
    const lz67 = await Getdoc193();
    const lz68 = await Getdoc194();
    const lz69 = await Getdoc195();
    const lz70 = await Getdoc196();
    const lz71 = await Getdoc197();
    const lz72 = await Getdoc198();
    const lz73 = await Getdoc199();
    const lz74 = await Getdoc200();
    const lz75 = await Getdoc201();
    const lz76 = await Getdoc202();
    const lz77 = await Getdoc203();
    const lz78 = await Getdoc204();
    const lz79 = await Getdoc205();
    const lz80 = await Getdoc206();
    const lz81 = await Getdoc207();
    const lz82 = await Getdoc208();
    const lz83 = await Getdoc209();
    const lz84 = await Getdoc210();
    const lz85 = await Getdoc211();
    const lz86 = await Getdoc212();
    const lz87 = await Getdoc213();
    const lz88 = await Getdoc214();
    const lz89 = await Getdoc215();
    const lz90 = await Getdoc216();
    const lz91 = await Getdoc217();
    const lz92 = await Getdoc218();
    const lz93 = await Getdoc219();
    const lz94 = await Getdoc220();
    const lz95 = await Getdoc221();
    const lz96 = await Getdoc222();
    const lz97 = await Getdoc223();
    const lz98 = await Getdoc224();
    const lz99 = await Getdoc225();
    const lz100 = await Getdoc226();
    const lz101 = await Getdoc227();
    const lz102 = await Getdoc228();
    const lz103 = await Getdoc229();
    const lz104 = await Getdoc230();
    const lz105 = await Getdoc231();
    const lz106 = await Getdoc232();
    const lz107 = await Getdoc233();
    const lz108 = await Getdoc234();
    const lz109 = await Getdoc235();
    const lz110 = await Getdoc236();
    const lz111 = await Getdoc237();
    const lz112 = await Getdoc238();
    const lz113 = await Getdoc239();
    const lz114 = await Getdoc240();
    const lz115 = await Getdoc241();
    const lz116 = await Getdoc242();
    const lz117 = await Getdoc243();
    const lz118 = await Getdoc244();
    const lz119 = await Getdoc245();
    const lz120 = await Getdoc246();
    const lz121 = await Getdoc247();
    const lz122 = await Getdoc248();
    const lz123 = await Getdoc249();
    const lz124 = await Getdoc250();
    const lz125 = await Getdoc251();
    const lz126 = await Getdoc252();
    const lz127 = await Getdoc253();
    const lz128 = await Getdoc254();
    const lz129 = await Getdoc255();
    const lz130 = await Getdoc256();
    const lz131 = await Getdoc257();
    const lz132 = await Getdoc258();
    const lz133 = await Getdoc259();
    res.render("propertypage", {
        alldata: hoteldatawithid,
        a: x,
        c: y,
        j: z,
        u1: u,
        lz: lz1,
        jz: lz2,
        kz: lz3,
        db94: lz4,
        w1: w,
        r1: r,
        c1: y1,
        d1: p1,
        h: h1,
        e: e1,
        f: f1,
        g: g1,
        i: i1,
        l: l1,
        m: m1,
        n: n1,
        o: o1,
        q: q1,
        v: v1,
        ab: ab1,
        bc: bc1,
        cd: cd1,
        de: de1,
        ef: ef1,
        gh: gh1,
        re: re1,
        em: em1,
        el1: el,
        rt: rt1,
        cx: cx1,
        lm: lm1,
        mn: mn1,
        db95: lz5,
        db96: lz6,
        db97: lz7,
        db98: lz8,
        db99: lz9,
        db100: lz10,
        db101: lz11,
        db94: lz4,
        db95: lz5,
        db96: lz6,
        db97: lz7,
        db98: lz8,
        db99: lz9,
        db100: lz10,
        db101: lz11,
        db94: lz4,
        db95: lz5,
        db96: lz6,
        db97: lz7,
        db98: lz8,
        db99: lz9,
        db100: lz10,
        db101: lz11,
        db102: lz12,
        db103: lz13,
        db104: lz14,
        db105: lz15,
        db106: lz16,
        db107: lz17,
        db108: lz18,
        db109: lz19,
        db110: lz20,
        db111: lz21,
        db112: lz22,
        db113: lz23,
        db114: lz24,
        db115: lz25,
        db116: lz26,
        db117: lz27,
        db118: lz28,
        db119: lz29,
        db120: lz30,
        db121: lz31,
        db122: lz32,
        db123: lz33,
        db124: lz34,
        db125: lz35,
        db126: lz36,
        db127: lz37,
        db128: lz38,
        db129: lz39,
        db130: lz40,
        db131: lz41,
        db132: lz42,
        db133: lz43,
        db134: lz44,
        db135: lz45,
        db136: lz46,
        db137: lz47,
        db138: lz48,
        db139: lz49,
        db140: lz50,
        db141: lz51,
        db142: lz52,
        db143: lz53,
        db144: lz54,
        db145: lz55,
        db146: lz56,
        db147: lz57,
        db148: lz58,
        db149: lz59,
        db150: lz60,
        db151: lz61,
        db152: lz62,
        db153: lz63,
        db154: lz64,
        db155: lz65,
        db156: lz66,
        db157: lz67,
        db158: lz68,
        db159: lz69,
        db160: lz70,
        db161: lz71,
        db162: lz72,
        db163: lz73,
        db164: lz74,
        db165: lz75,
        db166: lz76,
        db165: lz77,
        db166: lz78,
        db167: lz79,
        db168: lz80,
        db169: lz81,
        db170: lz82,
        db171: lz83,
        db172: lz84,
        db173: lz85,
        db174: lz86,
        db175: lz87,
        db176: lz88,
        db177: lz89,
        db178: lz90,
        db179: lz91,
        db180: lz92,
        db181: lz93,
        db182: lz94,
        db183: lz95,
        db184: lz96,
        db185: lz97,
        db186: lz98,
        db187: lz99,
        db188: lz100,
        db189: lz101,
        db190: lz102,
        db191: lz103,
        db192: lz104,
        db193: lz105,
        db194: lz106,
        db195: lz107,
        db196: lz108,
        db197: lz109,
        db198: lz110,
        db199: lz111,
        db200: lz112,
        db201: lz113,
        db202: lz114,
        db203: lz115,
        db204: lz116,
        db205: lz117,
        db206: lz118,
        db207: lz119,
        db208: lz120,
        db209: lz121,
        db210: lz122,
        db211: lz123,
        db212: lz124,
        db213: lz125,
        db214: lz126,
        db215: lz127,
        db216: lz128,
        db217: lz129,
        db218: lz130,
        db219: lz131,
        db220: lz132,
        db221: lz133,
    });
}

exports.fun4 = async(req, res) => {
    const db1 = await Getdoc489();
    const db2 = await Getdoc490();
    const db3 = await Getdoc491();
    const db4 = await Getdoc691();
    const db5 = await Getdoc692();
    const db16 = await Getdoc561();
    const db29 = await Getdoc573();
    const db30 = await Getdoc574();
    const db31 = await Getdoc575();
    const db32 = await Getdoc576();
    const db33 = await Getdoc577();
    const db23 = await Getdoc568();
    const db34 = await Getdoc578();
    const db35 = await Getdoc579();
    const db36 = await Getdoc654();
    const db37 = await Getdoc655();
    const db38 = await Getdoc582();
    const db39 = await Getdoc583();
    const db40 = await Getdoc656();
    const db41 = await Getdoc584();
    const db42 = await Getdoc657();
    const db43 = await Getdoc585();
    const db44 = await Getdoc658();
    const db45 = await Getdoc586();
    const db46 = await Getdoc659();
    const db47 = await Getdoc587();
    const db48 = await Getdoc660();
    const db49 = await Getdoc590();
    const db50 = await Getdoc661();
    const db51 = await Getdoc662();
    const db52 = await Getdoc663();
    const db53 = await Getdoc664();
    const db54 = await Getdoc673();
    const db55 = await Getdoc665();
    const db56 = await Getdoc666();
    const db57 = await Getdoc667();
    const db58 = await Getdoc668();
    const db59 = await Getdoc669();
    const db60 = await Getdoc670();
    const db61 = await Getdoc671();
    const db62 = await Getdoc672();
    const db63 = await Getdoc674();
    const db64 = await Getdoc571();
    const db65 = await Getdoc572();
    const db66 = await Getdoc584();
    const db67 = await Getdoc593();
    const db68 = await Getdoc595();
    const db69 = await Getdoc596();
    const db70 = await Getdoc675();
    const db71 = await Getdoc676();
    const db72 = await Getdoc677();
    const db73 = await Getdoc678();
    const db74 = await Getdoc679();
    const db75 = await Getdoc680();
    const db77 = await Getdoc681();
    const db78 = await Getdoc682();
    const db79 = await Getdoc609();
    const db80 = await Getdoc610();
    const db81 = await Getdoc611();
    const db82 = await Getdoc612();
    const db83 = await Getdoc613();
    const db84 = await Getdoc615();
    const db85 = await Getdoc616();
    const db86 = await Getdoc617();
    const db87 = await Getdoc618();
    const db88 = await Getdoc619();
    const db89 = await Getdoc620();
    const db90 = await Getdoc621();
    const db91 = await Getdoc622();
    const db92 = await Getdoc623();
    const db93 = await Getdoc624();
    const db94 = await Getdoc625();
    const db95 = await Getdoc626();
    const db96 = await Getdoc627();
    const db97 = await Getdoc628();
    const db98 = await Getdoc629();
    const db99 = await Getdoc630();
    const db100 = await Getdoc631();
    const db101 = await Getdoc632();
    const db102 = await Getdoc633();
    const db103 = await Getdoc683();
    const db104 = await Getdoc684();
    const db105 = await Getdoc685();
    const db106 = await Getdoc686();
    const db107 = await Getdoc687();
    const db108 = await Getdoc688();
    const db109 = await Getdoc689();
    const db110 = await Getdoc690();
    const db111 = await Getdoc634();
    const db112 = await Getdoc635();
    const db113 = await Getdoc636();
    const db114 = await Getdoc637();
    const db115 = await Getdoc638();
    const db116 = await Getdoc639();
    const db117 = await Getdoc640();
    const db118 = await Getdoc641();
    const db119 = await Getdoc642();
    const db120 = await Getdoc643();
    const db121 = await Getdoc644();
    res.render("aircoverhost", {
        a: db1,
        b: db2,
        c: db3,
        w: db23,
        doc0: db5,
        doc1: db4,
        doc2: db29,
        doc3: db16,
        doc4: db31,
        doc5: db32,
        doc6: db33,
        doc7: db34,
        doc8: db35,
        doc9: db36,
        doc10: db37,
        doc11: db38,
        doc12: db39,
        doc13: db40,
        doc14: db41,
        doc15: db42,
        doc16: db43,
        doc17: db44,
        doc18: db45,
        doc19: db46,
        doc20: db47,
        doc21: db48,
        doc22: db49,
        doc23: db50,
        doc24: db51,
        doc25: db52,
        doc26: db53,
        doc27: db54,
        doc28: db55,
        doc29: db56,
        doc30: db57,
        doc31: db58,
        doc32: db59,
        doc33: db60,
        doc34: db61,
        doc35: db62,
        doc36: db63,
        doc37: db64,
        doc38: db65,
        doc39: db30,
        doc40: db66,
        doc41: db67,
        doc42: db68,
        doc43: db69,
        doc44: db70,
        doc45: db71,
        doc46: db72,
        doc47: db73,
        doc48: db74,
        doc49: db75,
        doc50: db77,
        doc51: db78,
        doc52: db79,
        doc53: db80,
        doc54: db81,
        doc55: db82,
        doc56: db83,
        doc57: db84,
        doc58: db85,
        doc59: db86,
        doc60: db87,
        doc61: db88,
        doc62: db89,
        doc63: db90,
        doc64: db91,
        doc65: db92,
        doc66: db93,
        doc67: db94,
        doc68: db95,
        doc69: db96,
        doc70: db97,
        doc71: db98,
        doc72: db99,
        doc73: db100,
        doc74: db101,
        doc75: db102,
        doc76: db103,
        doc77: db104,
        doc78: db105,
        doc79: db106,
        doc80: db107,
        doc81: db108,
        doc82: db109,
        doc83: db110,
        doc84: db111,
        doc85: db112,
        doc86: db113,
        doc87: db114,
        doc88: db115,
        doc89: db116,
        doc90: db117,
        doc91: db118,
        doc92: db119,
        doc93: db120,
        doc94: db121,
    });
}
exports.fun5 = async (req, res) => {
    const { email, password } = req.body;
    try {
        const user = await finddetails(email, password);
        if (user && user !== "Login Failed!" && user !== "User not found") {
            // Successful login
            res.cookie('username', email);
            res.json({ message: "Success" });
        } else if (user === "Login Failed!") {
            // Incorrect password
            res.clearCookie('username');
            res.status(200).json({ message: "Login Failed!" });
        } else if (user === "User not found") {
            // User not registered
            res.status(200).json({ message: "User not found" });
        }
    } catch (error) {
        // Server error
        console.error('Error in handlelogin:', error);
        res.status(500).json({ message: "Server Error" });
    }
}
exports.fun6 = async(req,res) =>{
    const { email, password, Firstname, Lastname, Dob, age } = req.body;
    try {
        if (age < 18) {
            return res.status(400).json({ message: "Age cannot be less than 18 years" });
        }
        const data = await SaveData(email, password, Firstname, Lastname, Dob);

        if (data === true) {
            res.status(409).json({ message: "Details are already saved.Please login" });
        } else {
            res.cookie('username', email);
            res.status(200).json({ message: 'Details saved Successfully' });
        }
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: "Server Error" });
    }
}
exports.fun7 = async(req,res) =>{
    const data1 = await Getdoc693();
    const data2 = await Getdoc694();
    const data3 = await Getdoc695();
    const data4 = await Getdoc696();
    const data5 = await Getdoc697();
    const data6 = await Getdoc698();
    const data7 = await Getdoc699();
    const data8 = await Getdoc700();
    const data9 = await Getdoc701();
    const data10 = await Getdoc702();
    try {
        res.render('Becomeahost', {
            Data1: data1,
            Data2: data2,
            Data3: data3,
            Data4: data4,
            Data5: data5,
            Data6: data6,
            Data7: data7,
            Data8: data8,
            Data9: data9,
            Data10: data10
        })
    }
    catch {
        res.status(500).json({ message: 'Server Error' })
    }
}
exports.fun8 = async (req,res) =>{
    const data1 = await Getdoc707();
    const data2 = await Getdoc708();
    const data3 = await Getdoc709();
    const data4 = await Getdoc710();
    const data5 = await Getdoc711();
    const data6 = await Getdoc712();
    const data7 = await Getdoc713();
    const data8 = await Getdoc714();
    const data9 = await Getdoc715();
    const data10 = await Getdoc716();
    const data11 = await Getdoc717();
    const data12 = await Getdoc718();
    const data13 = await Getdoc719();
    const data14 = await Getdoc720();
    const data15 = await Getdoc721();
    const data16 = await Getdoc722();
    const data17 = await Getdoc723();
    const data18 = await Getdoc724();
    const data19 = await Getdoc725();
    const data20 = await Getdoc726();
    const data21 = await Getdoc727();
    const data22 = await Getdoc728();
    const data23 = await Getdoc729();
    const data24 = await Getdoc730();
    const data25 = await Getdoc731();
    const data26 = await Getdoc732();
    const data27 = await Getdoc733();
    const data28 = await Getdoc734();
    const data29 = await Getdoc735();
    const data30 = await Getdoc736();
    const data31 = await Getdoc737();
    const data32 = await Getdoc738();
    res.render("step2", {
        Data1: data1,
        Data2: data2,
        Data3: data3,
        Data4: data4,
        Data5: data5,
        Data6: data6,
        Data7: data7,
        Data8: data8,
        Data9: data9,
        Data10: data10,
        Data11: data11,
        Data12: data12,
        Data13: data13,
        Data14: data14,
        Data15: data15,
        Data16: data16,
        Data17: data17,
        Data18: data18,
        Data19: data19,
        Data20: data20,
        Data21: data21,
        Data22: data22,
        Data23: data23,
        Data24: data24,
        Data25: data25,
        Data26: data26,
        Data27: data27,
        Data28: data28,
        Data29: data29,
        Data30: data30,
        Data31: data31,
        Data32: data32,
    });
}
exports.fun9=async(req,res)=>{
    const data1 = await Getdoc703();
    const data2 = await Getdoc704();
    const data3 = await Getdoc705();
    const data4 = await Getdoc706();
    res.render("step1", {
        Data1: data1,
        Data2: data2,
        Data3: data3,
        Data4: data4,
    });
}
exports.fun10=async(req,res)=>{
    const data1 = await Getdoc749();
    const data2 = await Getdoc750();
    const data3 = await Getdoc751();
    const data4 = await Getdoc752();
    res.render("step4", {
        Data1: data1,
        Data2: data2,
        Data3: data3,
        Data4: data4,
    });
}
exports.fun11=async(req,res)=>{
    const data1 = await Getdoc739();
    const data2 = await Getdoc740();
    const data3 = await Getdoc741();
    const data4 = await Getdoc742();
    const data5 = await Getdoc743();
    const data6 = await Getdoc744();
    const data7 = await Getdoc745();
    const data8 = await Getdoc746();
    const data9 = await Getdoc747();
    const data10 = await Getdoc748();
    res.render('step3', {
        Data1: data1,
        Data2: data2,
        Data3: data3,
        Data4: data4,
        Data5: data5,
        Data6: data6,
        Data7: data7,
        Data8: data8,
        Data9: data9,
        Data10: data10,
    });
}
exports.fun12=async(req,res)=>{
    const captureddata=req.body;
     const check=findedData(captureddata) 
     if(check){
        setTimeout(()=>{
            res.redirect('/')
        },2000);
     }
     else{
        return
     }
}
exports.fun13=async(req,res)=>{
    setTimeout(() => {
        res.redirect('/host/homes')
    }, 2000)
}
exports.fun15=async(req,res)=>{
    res.redirect('/aircover-for-host') 
}
exports.fun16=async(req,res)=>{
    setTimeout(() => {
        res.redirect('/')
    }, 2000)
}
exports.fun17=async(req,res)=>{
    setTimeout(() => {
        res.redirect('/become-a-host')
    }, 5000) 
}
exports.fun18=async(req,res)=>{
    setTimeout(() => {
        res.redirect('/');
    }, 1000)
}
exports.fun19=async(req,res)=>{
    setTimeout(() => {
        res.redirect('/about-your-place');
    }, 1000)
}
exports.fun20=async(req,res)=>{
    setTimeout(() => {
        res.redirect('/about-your-place')
    }, 1000)
}
exports.fun21=async(req,res)=>{
    setTimeout(() => {
        res.redirect('/become-a-host')
    }, 2000)
}
exports.fun22=async(req,res)=>{
    setTimeout(() => {
        res.redirect('/become-a-host-structure')
    }, 2000)
}
exports.fun23=async(req,res)=>{
    res.redirect('/become-a-host')
}
exports.fun24=async(req,res)=>{
    setTimeout(() => {
        res.redirect('/become-a-host/privacy-type')
    }, 2000)
}
exports.fun25=async(req,res)=>{
    setTimeout(()=>{
        res.redirect('/become-a-host-privacy-type')
    },2000) 
}
exports.fun26=async(req,res)=>{
    setTimeout(() => {
        res.redirect('/become-a-host-structure')
    }, 2000)
}
exports.fun27=async(req,res)=>{
    setTimeout(() => {
        res.redirect('/become-a-host/privacy-type')
    }, 2000)
}
exports.fun28=async(req,res)=>{
    setTimeout(() => {
        res.redirect('/become-a-host/floor-plan')
    }, 2000)
}
exports.fun29=async(req,res)=>{
    const data1 = await Getdoc753();
    const data2 = await Getdoc754();
    const data3 = await Getdoc755();
    const data4 = await Getdoc756();
    const data5 = await Getdoc757();
    const data6 = await Getdoc614();
    res.render("step5", {
        Data1: data1,
        Data2: data2,
        Data3: data3,
        Data4: data4,
        Data5: data5,
        Data6: data6,
    })
}
exports.fun30=async(req,res)=>{
    setTimeout(() => {
        res.redirect('/become-a-host-privacy-type');
    }, 2000)
}
exports.fun31=async(req,res)=>{
    setTimeout(() => {
        res.redirect('/become-a-host/stand-out')
    }, 2000)
}
exports.fun32=async(req,res)=>{
    const data1 = await Getdoc758();
    const data2 = await Getdoc759();
    const data3 = await Getdoc760();
    const data4 = await Getdoc706();
    res.render("step6", {
        Data1: data1,
        Data2: data2,
        Data3: data3,
        Data4: data4,
    })
}
exports.fun33=async(req,res)=>{
    setTimeout(() => {
        res.redirect('/become-a-host/floor-plan')
    }, 2000)
}
exports.fun34=async(req,res)=>{
    setTimeout(() => {
        res.redirect('/become-a-host/amenities')
    }, 2000)
}
exports.fun35=async(req,res)=>{
    const data1 = await Getdoc761();
    const data2 = await Getdoc762();
    const data3 = await Getdoc763();
    const data4 = await Getdoc764();
    const data5 = await Getdoc765();
    const data6 = await Getdoc766();
    const data7 = await Getdoc767();
    const data8 = await Getdoc768();
    const data9 = await Getdoc769();
    const data11 = await Getdoc771();
    const data12 = await Getdoc772();
    const data13 = await Getdoc773();
    const data14 = await Getdoc774();
    const data15 = await Getdoc775();
    const data16 = await Getdoc776();
    const data17 = await Getdoc777();
    const data18 = await Getdoc778();
    const data19 = await Getdoc779();
    const data20 = await Getdoc780();
    const data21 = await Getdoc781();
    const data22 = await Getdoc782();
    const data23 = await Getdoc783();
    const data24 = await Getdoc784();
    const data25 = await Getdoc785();
    const data26 = await Getdoc786();
    const data27 = await Getdoc787();
    const data28 = await Getdoc788();
    const data29 = await Getdoc789();
    const data30 = await Getdoc790();
    const data31 = await Getdoc791();
    const data32 = await Getdoc792();
    res.render("step7", {
        Data1: data1,
        Data2: data2,
        Data3: data3,
        Data4: data4,
        Data5: data5,
        Data6: data6,
        Data7: data7,
        Data8: data8,
        Data9: data9,
        Data11: data11,
        Data12: data12,
        Data13: data13,
        Data14: data14,
        Data15: data15,
        Data16: data16,
        Data17: data17,
        Data18: data18,
        Data19: data19,
        Data20: data20,
        Data21: data21,
        Data22: data22,
        Data23: data23,
        Data24: data24,
        Data25: data25,
        Data26: data26,
        Data27: data27,
        Data28: data28,
        Data29: data29,
        Data30: data30,
        Data31: data31,
        Data32: data32,
    });
}
exports.fun36=async(req,res)=>{
    setTimeout(() => {
        res.redirect('/become-a-host/stand-out')
    }, 2000)
}
exports.fun37=async(req,res)=>{
    const data1 = await Getdoc793();
    const data2 = await Getdoc794();
    res.render("photos", {
        Data1: data1,
        Data2: data2,
    });
}
exports.fun38=async(req,res)=>{
    setTimeout(() => {
        res.redirect('/become-a-host/photos')
    }, 2000)
}
exports.fun39=async(req,res)=>{
    setTimeout(() => {
        res.redirect('/become-a-host/amenities');
    }, 2000)
}
exports.fun40= (upload.array('multiple_input', 20)),async(req,res)=>{
    try {
        const filenames = [];
        for (const file of req.files) {
            try {
                await PictureModel.create({ Picture: file.filename });
                filenames.push(file.filename); // Collect filenames for response
            } catch (error) {
                console.error('Error saving file to database:', error);
            }
        }
        // Send JSON response with filenames of uploaded files
        res.json({ images: filenames });
    } catch (error) {
        console.error('Error processing file uploads:', error);
        res.status(500).json({ error: 'Error processing file uploads' });
    }
}
exports.fun41=async(req,res)=>{
    setTimeout(() => {
        res.redirect('/become-a-host/title')
    }, 2000)
}
exports.fun42=async(req,res)=>{
    const data1 = await Getdoc795();
    const data2 = await Getdoc796();
    res.render("step8", {
        Data1: data1,
        Data2: data2,
    });
}
exports.fun43=async(req,res)=>{
    res.redirect("/become-a-host/description")
}
exports.fun44=async(req,res)=>{
    setTimeout(() => {
        res.redirect('/become-a-host/title')
    }, 2000)
}
exports.fun45=async(req,res)=>{
    const data1 = await Getdoc797();
    const data2 = await Getdoc798();
    res.render("step9", {
        Data1: data1,
        Data2: data2,
    })
}
exports.fun46=async(req,res)=>{
    setTimeout(() => {
        res.redirect('/become-a-host/photos')
    }, 2000); 
}
exports.fun47=async(req,res)=>{
    setTimeout(() => {
        res.redirect('/become-a-host/finish-setup')
    }, 2000)
}
exports.fun48=async(req,res)=>{
    const data1 = await Getdoc799();
    const data2 = await Getdoc800();
    const data3 = await Getdoc801();
    res.render("step10", {
        Data1: data1,
        Data2: data2,
        Data3: data3,
    });
}
exports.fun49=async(req,res)=>{
    setTimeout(() => {
        res.redirect('/become-a-host/description')
    }, 2000);
}
exports.fun50=async(req,res)=>{
    setTimeout(() => {
        res.redirect('/become-a-host/instant-book')
    }, 2000)
}
exports.fun51=async(req,res)=>{
    const data1 = await Getdoc802();
    const data2 = await Getdoc803();
    const data3 = await Getdoc804();
    const data4 = await Getdoc805();
    const data5 = await Getdoc806();
    res.render("step11", {
        Data1: data1,
        Data2: data2,
        Data3: data3,
        Data4: data4,
        Data5: data5,
    });
}
exports.fun52=async(req,res)=>{
    setTimeout(() => {
        res.redirect('/become-a-host/visibility')
    }, 2000)
}
exports.fun53=async(req,res)=>{
    const data1 = await Getdoc807();
    const data2 = await Getdoc808();
    const data3 = await Getdoc809();
    const data4 = await Getdoc810();
    const data5 = await Getdoc811();
    const data6 = await Getdoc812();
    res.render("step12", {
        Data1: data1,
        Data2: data2,
        Data3: data3,
        Data4: data4,
        Data5: data5,
        Data6: data6,
    })
}
exports.fun54=async(req,res)=>{
    setTimeout(() => {
        res.redirect('/become-a-host/finish-setup')
    }, 2000)
}
exports.fun55=async(req,res)=>{
    setTimeout(() => {
        res.redirect('/become-a-host/instant-book')
    }, 2000)
}
exports.fun56=async(req,res)=>{
    setTimeout(() => {
        res.redirect('/become-a-host/price')
    }, 2000)
}
exports.fun57=async(req,res)=>{
    const data1 = await Getdoc813();
    const data2 = await Getdoc814();
    const data3 = await Getdoc815();
    const data4 = await Getdoc816();
    const data5 = await Getdoc817();
    const data6 = await Getdoc818();
    const data7 = await Getdoc819();
    const data8 = await Getdoc820();
    res.render("step13", {
        Data1: data1,
        Data2: data2,
        Data3: data3,
        Data4: data4,
        Data5: data5,
        Data6: data6,
        Data7: data7,
        Data8: data8,
    })
}
exports.fun58=async(req,res)=>{
    setTimeout(() => {
        res.redirect('/become-a-host/visibility')
    }, 2000)
}
exports.fun59=async(req,res)=>{
    const collect = req.body.basicprice;
    res.json({ received: collect })
}
exports.fun60=async(req,res)=>{
    res.render("finally");
}
exports.fun61=async(req,res)=>{
    try{
        const data=req.body;
        const newForm = new Form(data);
       await newForm.save();
        res.json({message:"Data submitted successfully!"});
        const token=jwt.sign(newForm,createSecretKey,{expiresIn:'1h'});
        console.log("token",token);
    }
    catch(error){
        console.error("Error");
    }
}
exports.fun62=async(req,res)=>{
    setTimeout(()=>{
        res.redirect("/")
    },2000)
}
