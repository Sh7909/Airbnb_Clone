const express = require('express');
const bodyParser = require('body-parser');
const path = require('path');
const cookieparser = require('cookie-parser');
const app = express();
const router=require('./routes/UserRoutes.js')
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
app.use(express.json());
app.use(express.static("public"));
app.use(express.static(path.join(__dirname, 'public')));
app.use(cookieparser());
app.set("view engine", "ejs");
app.set('views', path.join(__dirname,'views'));
app.use(router);
module.exports=app;