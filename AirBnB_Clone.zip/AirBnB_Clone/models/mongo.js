
const mongoose = require('mongoose');
exports.connectDB = () =>{
    mongoose.connect('mongodb://127.0.0.1:27017/AirBnB_Clone')
    .then(() => {
        console.log("Database Connected")
    })
    .catch((err) => {
        console.log(err)
    })
}