const app=require('./app.js');
const {connectDB}=require('../AirBnB_Clone/models/mongo.js');
connectDB();
app.listen(3000, () => {
    console.log("Server Started Now")
});